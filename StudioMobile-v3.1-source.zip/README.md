# Studio Mobile 3.1

Application Android native de composition libre de photos et vidéos, projets `.studio` et export HTML autonome.

## Livraison GitHub Actions — méthode conservée

Cette version garde le dépôt GitHub existant et le même circuit manuel :

1. Déposer `StudioMobile-v3.1-source.zip` **à la racine** du dépôt.
2. Déposer `build-android-v3.1.yml` dans `.github/workflows/`.
3. Ne pas extraire le ZIP dans le dépôt, ne pas renommer le dépôt et ne pas supprimer les anciens fichiers.
4. Ouvrir GitHub Actions, choisir **Studio Mobile V3.1 Android** puis `Run workflow`.
5. Télécharger l'artefact `StudioMobile-v3.1-debug-apk`.

Le workflow extrait et compile exclusivement le ZIP V3.1 présent à la racine. Il ne reprend pas des fichiers Kotlin isolés ou une ancienne source du dépôt.

## Principales nouveautés V3.1

- Import avec lecture des dimensions réelles des images et vidéos, y compris orientation EXIF et rotation vidéo.
- Taille initiale des médias proportionnelle à leur ratio réel.
- `contain` par défaut pour les nouveaux médias. Les anciens projets conservent leur ancien cadrage `cover`.
- Modes Vue et Modifier.
- Sélection multiple par appui long dans la liste des calques.
- Déplacement groupé, rotation groupée et redimensionnement groupé, avec pivot commun ou individuel.
- Fusion rasterisée de plusieurs calques, avec conservation des originaux dans le projet `.studio`.
- Références de fusion aplaties vers les médias d'origine : les fusions intermédiaires sont supprimées lors d'une nouvelle fusion pour éviter les chaînes et les doublons de rendus.
- Lecteur vidéo Android intégré au canevas via Media3/ExoPlayer : lecteur unique, commandes intégrées, reprise après pause et capture d'une image de prévisualisation avant libération du média.
- Export HTML autonome conservé. Les vidéos sont chargées directement depuis leur URI `data:` à la demande, sans créer une seconde copie Blob/ObjectURL.
- Lecture séquentielle des vidéos dans l'export HTML, avec arrêt de la séquence et une seule vidéo active.
- Export PNG tenant compte des calques masqués, de leur rotation et du mode d'ajustement.

## Compatibilité des projets

Le format `.studio` reste en `schemaVersion: 1`. Les nouveaux champs sont facultatifs à la lecture. Les projets V2.2/V3.0 restent donc lisibles sans migration destructive. Les nouveaux projets enregistrent aussi les dimensions sources, le mode d'ajustement, la visibilité et les références de fusion.

Les médias sources restent intégrés une seule fois dans le ZIP `.studio`. Une fusion ajoute une image dérivée ; elle ne remplace pas les originaux. Le bouton **Dissocier** rend les sources de nouveau accessibles.

## Limites assumées

- Pas d'Undo/Redo ni d'autosave complexe dans cette version.
- Pas encore de panneau de pistes vidéo, de montage multitrack ou de playlist native indépendante de l'ordre des calques.
- Pas d'annotations collaboratives.
- L'export HTML reste un lecteur/visualiseur autonome, pas l'éditeur complet.
- Les fusions rasterisent les calques visibles sélectionnés à une résolution maximale de 2560 px par côté ; pour les vidéos, la fusion utilise une image représentative du média.
- La fusion ne constitue pas un historique Undo : les sources sont conservées et peuvent être restaurées avec **Dissocier**, mais les réglages de composition précédant la fusion ne sont pas enregistrés comme une session éditable complète.

## Validation

La source a été inspectée et l'export JavaScript a passé une vérification syntaxique. En revanche, cet environnement ne possède pas le SDK Android ni Gradle : **aucune compilation APK ni aucun test physique ne sont revendiqués ici**. La compilation doit être faite par le workflow GitHub, puis l'APK doit être testé sur le Redmi avant validation.
