# Studio Mobile V3.1 — plan de tests

## 0. Préparation

- [ ] Compiler le ZIP V3.1 via GitHub Actions.
- [ ] Télécharger l'artefact `StudioMobile-v3.1-debug-apk`.
- [ ] Installer l'APK sur le Redmi Note 12 Pro 5G (Android 13).
- [ ] Garder une copie d'un projet `.studio` V2.2/V3.0 avant les essais.

## 1. Compatibilité projet

- [ ] Ouvrir un ancien projet `.studio` V2.2.
- [ ] Vérifier médias, positions, tailles, rotations et ordre des calques.
- [ ] Vérifier que les anciens médias gardent le cadrage `cover`.
- [ ] Enregistrer sous un nouveau nom.
- [ ] Fermer puis rouvrir le nouveau projet.
- [ ] Vérifier que les SHA-256 passent et que les sources de fusion sont présentes.

## 2. Import et proportions

- [ ] Importer une photo paysage.
- [ ] Importer une photo portrait.
- [ ] Importer une photo carrée.
- [ ] Importer une photo avec orientation EXIF.
- [ ] Importer une vidéo paysage et une vidéo portrait.
- [ ] Vérifier que chaque élément garde son ratio initial et que rien n'est rogné par défaut.
- [ ] Importer une photo très haute résolution (ex. 12000 × 16000) et vérifier l'absence de blocage/crash.

## 3. Vue et Modifier

- [ ] À l'ouverture, vérifier le mode Vue.
- [ ] Glisser sur le fond : la caméra se déplace sans modifier les calques.
- [ ] Deux doigts : zoom, rotation et déplacement de la vue.
- [ ] Réinitialiser la vue : les calques retrouvent exactement leur position.
- [ ] Passer en Modifier : déplacer un calque avec un doigt.
- [ ] Tester rotation et redimensionnement avec les poignées.
- [ ] Repasser en Vue : les gestes ne doivent plus déplacer les médias.

## 4. Sélection multiple et pivots

- [ ] Faire un appui long sur un calque dans la liste.
- [ ] Ajouter un deuxième calque par appui long.
- [ ] Déplacer le groupe : les calques doivent conserver leurs écarts.
- [ ] Pivot commun : tourner le groupe autour de son centre moyen.
- [ ] Pivot commun : redimensionner le groupe en conservant les positions relatives.
- [ ] Pivots individuels : tourner chaque calque autour de son propre centre.
- [ ] Pivots individuels : redimensionner sans déplacer les centres.
- [ ] Vérifier que le changement de sélection par appui simple revient à un seul calque.

## 5. Fusion et restauration

- [ ] Sélectionner deux images puis Fusionner.
- [ ] Vérifier que le composite apparaît et que les originaux sont masqués dans la liste.
- [ ] Enregistrer le projet `.studio`, fermer et rouvrir.
- [ ] Vérifier que le composite et les sources sont toujours présents.
- [ ] Sélectionner un original masqué puis Dissocier.
- [ ] Vérifier que le composite est masqué et que les originaux réapparaissent.
- [ ] Fusionner à nouveau un composite avec un autre calque.
- [ ] Vérifier que le projet ne garde pas une chaîne de composites intermédiaires.
- [ ] Vérifier que supprimer un original encore référencé est bloqué.
- [ ] Tester une fusion avec une vidéo : l'image représentative doit apparaître.

## 6. Lecture vidéo native

- [ ] Toucher un calque vidéo en mode Vue.
- [ ] Vérifier que la vidéo apparaît à la place du poster, dans la zone du calque.
- [ ] Vérifier que les contrôles Play/Pause et la barre de progression sont intégrés.
- [ ] Mettre en pause : le poster doit se mettre à jour.
- [ ] Toucher le poster ou utiliser « Lire vidéo » : la lecture doit reprendre près de la position de pause.
- [ ] Laisser terminer : le poster de départ doit réapparaître.
- [ ] Lancer une deuxième vidéo : une seule vidéo doit être active.
- [ ] Sélectionner un autre calque : l'overlay vidéo doit se fermer et le poster rester visible.
- [ ] Passer en Modifier : l'overlay doit se fermer.
- [ ] Tester un codec courant (MP4/H.264) et noter tout format non pris en charge.

## 7. Export HTML

- [ ] Exporter un HTML avec photos et vidéos.
- [ ] Vérifier que les calques masqués ne sont pas exportés.
- [ ] Ouvrir le fichier depuis le gestionnaire Android (URL `content://`).
- [ ] Vérifier que le fichier fonctionne sans dossier de médias externe.
- [ ] Vérifier Play et Recentrer directement dans l'en-tête.
- [ ] Ouvrir Menu et tester zoom, rotation, réinitialisation et calques.
- [ ] Lire une vidéo puis une autre ; vérifier qu'elles ne jouent pas simultanément.
- [ ] Arrêter la lecture séquentielle avec le même bouton.
- [ ] Vérifier que les contrôles vidéo natifs restent utilisables.
- [ ] Ouvrir le même HTML dans Chrome/Edge desktop et tester souris.

## 8. Sauvegarde et robustesse

- [ ] Enregistrer `.studio` après import, déplacement, fusion et dissociation.
- [ ] Rouvrir et vérifier SHA-256.
- [ ] Ouvrir un ZIP avec un chemin `../` : il doit être refusé.
- [ ] Ouvrir un manifeste avec références de fusion invalides : il doit être refusé.
- [ ] Vérifier qu'un export interrompu n'est pas annoncé comme réussi.

## Résultats à me transmettre

Pour chaque anomalie, indique : étape du test, ce que tu as fait, ce qui s'est passé, ce que tu attendais, et si possible une capture d'écran ou le message affiché. Ne valide pas la V3.1 tant que les sections 1, 2, 6 et 7 ne sont pas satisfaisantes.
