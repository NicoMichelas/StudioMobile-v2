# Studio Mobile V3.1 — notice et choix techniques

## Objectif

La V3.1 améliore les fondations de création et fiabilise le traitement vidéo/export sans engager la refonte multiplateforme prévue plus tard. L'ordre de validation reste : Android (Redmi) d'abord, autre smartphone ensuite, ordinateur après.

## 1. Import et géométrie des médias

`ProjectArchive.importMedia()` lit maintenant les dimensions réelles :

- images : dimensions décodées sans charger les pixels, orientation EXIF prise en compte ;
- vidéos : largeur, hauteur et rotation via `MediaMetadataRetriever`.

La largeur initiale normalisée reste fixée à 0,24 du canevas ; la hauteur est calculée à partir du ratio source et des dimensions logiques du canevas. Cela évite de forcer les photos portrait, paysage et les vidéos dans un rectangle carré.

Les nouveaux médias utilisent `fitMode = contain`. Les projets V1 historiques qui ne possèdent pas ce champ sont lus en `cover` pour préserver leur apparence antérieure. Les modes `cover` et `stretch` restent représentables dans le modèle, mais le sélecteur d'ajustement n'est pas encore exposé dans l'interface.

## 2. Modes Vue et Modifier

- **Vue** : un doigt déplace la caméra lorsque l'on glisse, deux doigts zooment/tournent/déplacent la vue. Un appui sur une vidéo peut lancer sa lecture.
- **Modifier** : un doigt déplace le calque sélectionné ; les poignées servent à tourner et redimensionner.
- Les coordonnées du document restent indépendantes de la caméra.

## 3. Sélection multiple et pivots

Un appui long sur un élément de la liste des calques ajoute/retire ce calque de la sélection. Le déplacement agit sur le groupe.

Le bouton **Pivot commun** alterne entre :
- pivot commun : rotation autour du centre moyen du groupe et redimensionnement autour de ce même centre ;
- pivots individuels : rotation de chaque calque autour de son propre centre et redimensionnement de chaque calque sans déplacer son centre.

Les poignées restent attachées au calque actif. La sélection multiple ne crée pas de groupe permanent.

## 4. Fusion et conservation des sources

La fusion rasterise les calques visibles sélectionnés dans une nouvelle image PNG :

- l'image résultante est plafonnée à 2560 px sur son plus grand côté ;
- les images sources sont décodées à une résolution réduite adaptée à cette limite, sans charger une photo géante en pleine résolution ;
- les vidéos contribuent avec une image représentative ;
- les calques sources originaux sont conservés dans le `.studio`, masqués et référencés par identifiants ;
- les références sont aplaties vers les identifiants des sources originales, plutôt que de créer une chaîne de fusion sur fusion ;
- lors d'une nouvelle fusion incluant une fusion précédente, l'image dérivée intermédiaire est supprimée et remplacée par la nouvelle, tandis que les originaux restent ;
- **Dissocier** masque le composite et restaure les sources ;
- supprimer un média encore utilisé comme source d'un composite est bloqué tant que le composite existe.

Ce mécanisme évite de dupliquer les originaux. Il ne fournit pas encore un historique d'opérations complet ni un Undo/Redo.

## 5. Lecture vidéo native

Le lecteur natif est maintenant un `PlayerView` Media3/ExoPlayer placé au-dessus du canevas et positionné sur le rectangle du calque vidéo. Un seul lecteur est créé et réutilisé.

- Les commandes de lecture/pause et la barre de progression sont intégrées à la vidéo.
- La pause mémorise la position de lecture.
- À la pause, au changement de calque ou à la fin, une image représentative est extraite en arrière-plan, puis le média est retiré du lecteur afin de libérer son pipeline de décodage. Le lecteur disparaît alors et le poster mis à jour reste sur le canevas.
- Pour reprendre, toucher le poster ou utiliser le bouton « Lire vidéo » : la lecture repart à la position mémorisée ; après la fin, elle repart du début.
- La vignette du calque est mise à jour avec l'image capturée.

Le contrôle de volume, la vitesse, les points d'entrée/sortie et un panneau de pistes restent hors périmètre.

## 6. Export HTML autonome

Le HTML demeure un fichier unique, sans média externe, pour rester ouvrable depuis le gestionnaire de fichiers Android via `content://`.

- Les calques masqués ne sont pas intégrés au HTML de visualisation.
- Les images utilisent leur mode d'ajustement.
- Les vidéos sont chargées directement depuis leur URI `data:` lorsqu'une lecture est demandée. Le code n'effectue plus une conversion `fetch → Blob → ObjectURL`, qui aurait créé une copie mémoire supplémentaire.
- Une seule vidéo est active à la fois.
- La lecture séquentielle dispose d'un mécanisme d'arrêt.
- Les boutons Play et Recentrer sont accessibles dès l'ouverture ; les commandes avancées restent dans le menu.

Les vidéos étant intégrées en base64, le fichier HTML peut rester très volumineux. Cette version ne réencode pas les vidéos et ne promet pas une lecture de tous les codecs sur tous les navigateurs.

## 7. Format et sécurité du projet

Le schéma `.studio` reste en version 1. Les champs ajoutés sont optionnels à la lecture :
`sourceWidth`, `sourceHeight`, `fitMode`, `visible`, `sourceItemIds`.

L'ouverture vérifie les identifiants, les chemins média, les références de fusion et les SHA-256. Le manifeste est lu avec une limite de taille avant parsing.

## 8. Non inclus

- Undo/Redo, autosave avancé ;
- annotations, commentaires, contributions et collaboration ;
- édition complète dans le HTML ;
- synchronisation de configurations entre appareils ;
- interface iPhone/iPad et desktop complète ;
- panneau vidéo multitrack ;
- outil de recadrage non destructif et réglages image avancés.

Ces sujets pourront être traités progressivement dans les prochaines versions V3.x, après les tests de cette base.
