package org.studiomobile.v2

import android.app.Activity
import android.content.Intent
import android.graphics.*
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.exifinterface.media.ExifInterface
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.UUID
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min
import kotlin.math.atan2
import kotlin.math.hypot

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var canvasView: ProjectCanvasView
    private lateinit var canvasHost: FrameLayout
    private lateinit var playerView: PlayerView
    private var exoPlayer: ExoPlayer? = null
    private var playingItemId: String? = null
    private val videoPositions = mutableMapOf<String, Long>()
    private var suppressPauseCapture = false
    private val doc = ProjectDocument()
    private val mediaFiles = mutableMapOf<String, File>()
    private var selectedId: String? = null
    private val selectedIds = linkedSetOf<String>()
    private var editMode = false
    private var commonPivot = true
    private var resizeActive = false
    private var resizeStartWidth = 0f
    private var resizeStartHeight = 0f
    private var resizeStartX = 0f
    private var resizeStartY = 0f
    private var rotationActive = false
    private var rotateStartAngle = 0f
    private var rotateStartRotation = 0f

    private val exportPng = registerForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null) exportCanvasPng(uri)
    }
    private val exportHtmlPackage = registerForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { uri ->
        if (uri != null) exportInteractivePackage(uri)
    }

    private val importPicker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        status.text = "Importation de ${uris.size} fichier(s)…"
        thread {
            var done = 0
            val errors = mutableListOf<String>()
            uris.forEach { uri ->
                try {
                    val imported = ProjectArchive.importMedia(this, uri, contentResolver) { bytes ->
                        runOnUiThread { status.text = "Import : ${importedSafeName(uri)} — ${bytes / 1024} Ko" }
                    }
                    val duplicate = doc.items.firstOrNull { it.sha256 == imported.item.sha256 }
                    if (duplicate == null) {
                        val item = imported.item
                        item.x = (0.18f + (doc.items.size % 4) * 0.2f).coerceIn(0.1f, 0.9f)
                        item.y = (0.22f + (doc.items.size % 3) * 0.25f).coerceIn(0.1f, 0.9f)
                        val aspect = if (item.sourceWidth > 0 && item.sourceHeight > 0)
                            item.sourceWidth.toFloat() / item.sourceHeight.toFloat() else 1f
                        item.width = 0.24f
                        item.height = item.width * doc.canvasWidth / (aspect * doc.canvasHeight)
                        if (item.height > 1.2f) {
                            val shrink = 1.2f / item.height
                            item.width *= shrink
                            item.height = 1.2f
                        } else if (item.height < 0.02f) {
                            val enlarge = 0.02f / item.height
                            item.width *= enlarge
                            item.height = 0.02f
                        }
                        doc.items.add(item); mediaFiles[item.id] = imported.cachedFile
                    } else imported.cachedFile.delete()
                } catch (e: Exception) { errors.add("${uri.lastPathSegment}: ${e.message}") }
                done++
                runOnUiThread { status.text = "Importation : $done/${uris.size}" }
            }
            runOnUiThread {
                progress.visibility = View.GONE
                status.text = if (errors.isEmpty()) "Import terminé : ${doc.items.size} élément(s). Doublons ignorés." else "Import terminé avec ${errors.size} erreur(s) : ${errors.first()}"
                selectedId = doc.items.lastOrNull { it.visible }?.id
                selectedIds.clear()
                selectedId?.let { selectedIds.add(it) }
                canvasView.invalidate(); refreshLayerStrip()
            }
        }
    }

    private val openProject = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) openProjectUri(uri)
    }
    private val saveProject = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) saveProjectUri(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 6)
            setBackgroundColor(Color.rgb(24, 34, 37))
        }
        val title = TextView(this).apply {
            text = "STUDIO  ·  MOBILE"
            textSize = 20f
            setTextColor(Color.rgb(237, 238, 233))
            setTypeface(null, Typeface.BOLD)
            setPadding(8, 4, 8, 8)
        }
        root.addView(title)

        // Horizontal tool strips keep every action reachable on narrow phone screens.
        fun toolStrip(): Pair<HorizontalScrollView, LinearLayout> {
            val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            scroll.addView(row)
            root.addView(scroll, LinearLayout.LayoutParams(-1, -2))
            return scroll to row
        }
        val (_, actions) = toolStrip()
        actions.addView(makeButton("＋ Importer", 0) { importPicker.launch(arrayOf("image/*", "video/*")) })
        actions.addView(makeButton("Ouvrir .studio", 1) { openProject.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) })
        actions.addView(makeButton("Enregistrer", 2) { saveProject.launch("${safeDocName(doc.name)}.studio") })
        actions.addView(makeButton("Exporter HTML", 9) { exportHtmlPackage.launch("${safeDocName(doc.name)}-studio.html") })
        actions.addView(makeButton("Aperçu PNG", 3) { exportPng.launch("${safeDocName(doc.name)}-apercu.png") })

        val (_, tools) = toolStrip()
        tools.addView(makeButton("Calque ↑", 4) { moveSelectedLayer(1); refreshLayerStrip() })
        tools.addView(makeButton("Calque ↓", 5) { moveSelectedLayer(-1); refreshLayerStrip() })
        tools.addView(makeButton("Taille +", 6) { resizeSelected(1.1f) })
        tools.addView(makeButton("Taille −", 7) { resizeSelected(0.9f) })
        tools.addView(makeButton("Supprimer", 8) { deleteSelected(); refreshLayerStrip() })
        tools.addView(makeButton("▶ Lire vidéo", 10) { playSelectedVideo() })
        tools.addView(makeButton("Vue −", 11) { canvasView.adjustZoom(0.8f) })
        tools.addView(makeButton("Vue +", 12) { canvasView.adjustZoom(1.25f) })
        tools.addView(makeButton("Tourner vue", 13) { canvasView.rotateViewport(90f) })
        tools.addView(makeButton("Réinitialiser vue", 14) { canvasView.resetViewport() })
        tools.addView(makeButton("Vue", 15) { editMode = false; canvasView.setEditMode(false); status.text = "Mode Vue : navigation du canevas" })
        tools.addView(makeButton("Modifier", 16) { editMode = true; canvasView.setEditMode(true); stopInlineVideo(); status.text = "Mode Modifier : déplacement et transformation des calques" })
        tools.addView(makeButton("Pivot commun", 17) {
            commonPivot = !commonPivot
            status.text = if (commonPivot) "Pivot commun activé" else "Pivots individuels activés"
        })
        tools.addView(makeButton("Fusionner", 18) { mergeSelectedLayers() })
        tools.addView(makeButton("Dissocier", 19) { restoreSelectedSources() })

        layerStrip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(2, 5, 2, 5)
            setBackgroundColor(Color.rgb(31, 43, 47))
        }
        val layerScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(layerStrip)
        }
        root.addView(layerScroll, LinearLayout.LayoutParams(-1, 58))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        root.addView(progress, LinearLayout.LayoutParams(-1, 8))
        status = TextView(this).apply {
            text = "Prêt · importe des images ou vidéos pour composer"
            textSize = 12f
            setTextColor(Color.rgb(154, 172, 176))
            setPadding(8, 5, 8, 5)
        }
        root.addView(status)
        canvasHost = FrameLayout(this)
        canvasView = ProjectCanvasView()
        canvasHost.addView(canvasView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        playerView = PlayerView(this).apply {
            useController = true
            controllerAutoShow = true
            controllerShowTimeoutMs = 3000
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            visibility = View.GONE
        }
        canvasHost.addView(playerView, FrameLayout.LayoutParams(1, 1))
        root.addView(canvasHost, LinearLayout.LayoutParams(-1, 0, 1f))
        canvasView.onViewportChanged = { updateInlinePlayerOverlay() }
        val hint = TextView(this).apply {
            text = "Vue : glisser pour naviguer · Modifier : glisser/poignées · appui long sur un calque pour sélection multiple · Fusionner / Dissocier"
            textSize = 11f
            setTextColor(Color.rgb(154, 172, 176))
            setPadding(6, 6, 6, 2)
        }
        root.addView(hint)
        setContentView(root)
        refreshLayerStrip()
    }

    private lateinit var layerStrip: LinearLayout

    private fun refreshLayerStrip() {
        if (!::layerStrip.isInitialized) return
        layerStrip.removeAllViews()
        if (doc.items.isEmpty()) {
            layerStrip.addView(TextView(this).apply {
                text = "CALQUES  ·  aucun média"
                textSize = 12f; setTextColor(Color.rgb(154, 172, 176)); setPadding(10, 10, 10, 10)
            })
            return
        }
        doc.items.forEachIndexed { index, item ->
            val selected = item.id in selectedIds || item.id == selectedId
            val button = TextView(this).apply {
                text = "${if (!item.visible) "◌ " else ""}${if (item.kind == "video") "▶" else "▧"} ${index + 1}. ${item.displayName}${if (!item.visible) " [masqué]" else ""}"
                textSize = 11f
                maxWidth = 220
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
                gravity = Gravity.CENTER_VERTICAL
                setPadding(10, 6, 10, 6)
                setTextColor(if (!item.visible) Color.rgb(120, 135, 138) else if (selected) Color.rgb(24, 34, 37) else Color.rgb(237, 238, 233))
                setBackgroundColor(if (selected) Color.rgb(227, 168, 87) else Color.rgb(35, 48, 54))
                setOnClickListener {
                    selectedId = item.id
                    selectedIds.clear()
                    selectedIds.add(item.id)
                    canvasView.invalidate()
                    updateInlinePlayerOverlay()
                    refreshLayerStrip()
                }
                setOnLongClickListener {
                    if (item.id in selectedIds) selectedIds.remove(item.id) else selectedIds.add(item.id)
                    selectedId = item.id
                    canvasView.invalidate()
                    updateInlinePlayerOverlay()
                    refreshLayerStrip()
                    status.text = "${selectedIds.size} calque(s) sélectionné(s). Appui long pour ajouter/retirer."
                    true
                }
                layoutParams = LinearLayout.LayoutParams(-2, -1).apply { marginEnd = 5 }
            }
            layerStrip.addView(button)
        }
    }

    private fun makeButton(label: String, id: Int, action: () -> Unit): Button = Button(this).apply {
        text = label; textSize = 11f; isAllCaps = false; setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginEnd = 4 }
        setTextColor(Color.rgb(237, 238, 233))
        setBackgroundColor(Color.rgb(46, 111, 104))
        minWidth = 0
    }

    private fun saveProjectUri(uri: Uri) {
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        status.text = "Préparation de l'archive…"
        thread {
            try {
                contentResolver.openOutputStream(uri, "wt")?.use { out ->
                    ProjectArchive.save(this, doc, mediaFiles, out) { p ->
                        runOnUiThread { progress.isIndeterminate = false; progress.progress = p; status.text = "Enregistrement : $p%" }
                    }
                } ?: throw Exception("Impossible d'écrire le fichier choisi.")
                runOnUiThread { progress.visibility = View.GONE; status.text = "Projet enregistré : ${doc.items.size} élément(s)." }
            } catch (e: Exception) {
                runOnUiThread { progress.visibility = View.GONE; status.text = "Échec de sauvegarde : ${e.message}" }
            }
        }
    }

    private fun openProjectUri(uri: Uri) {
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        status.text = "Ouverture et vérification du projet…"
        thread {
            try {
                val (loaded, loadedFiles) = contentResolver.openInputStream(uri)?.use { input ->
                    ProjectArchive.open(this, input) { p -> runOnUiThread { status.text = "Lecture de l'archive…"; progress.progress = p } }
                } ?: throw Exception("Impossible de lire ce fichier.")
                runOnUiThread {
                    stopInlineVideo()
                    ThumbnailCache.clear()
                    doc.name = loaded.name; doc.canvasWidth = loaded.canvasWidth; doc.canvasHeight = loaded.canvasHeight
                    doc.items.clear(); doc.items.addAll(loaded.items)
                    mediaFiles.clear(); mediaFiles.putAll(loadedFiles)
                    selectedIds.clear()
                    selectedId = doc.items.lastOrNull { it.visible }?.id
                    selectedId?.let { selectedIds.add(it) }
                    progress.visibility = View.GONE
                    status.text = "Projet ouvert et vérifié : ${doc.items.size} élément(s)."
                    canvasView.invalidate(); refreshLayerStrip()
                }
            } catch (e: Exception) {
                runOnUiThread { progress.visibility = View.GONE; status.text = "Ouverture impossible : ${e.message}" }
            }
        }
    }

    private fun moveSelectedLayer(direction: Int) {
        val index = doc.items.indexOfFirst { it.id == selectedId }
        if (index < 0) { status.text = "Sélectionne d'abord un calque."; return }
        val target = (index + direction).coerceIn(0, doc.items.lastIndex)
        if (target != index) {
            val item = doc.items.removeAt(index)
            doc.items.add(target, item)
            canvasView.invalidate(); refreshLayerStrip()
        }
    }

    private fun resizeSelected(factor: Float) {
        val item = doc.items.firstOrNull { it.id == selectedId }
        if (item == null) { status.text = "Sélectionne d'abord un calque."; return }
        item.width = (item.width * factor).coerceIn(0.04f, 1.8f)
        item.height = (item.height * factor).coerceIn(0.04f, 1.8f)
        canvasView.invalidate()
    }

    private fun playSelectedVideo() {
        val item = doc.items.firstOrNull { it.id == selectedId && it.visible }
        if (item == null || item.kind != "video") {
            status.text = "Sélectionne d'abord un calque vidéo."
            return
        }
        val file = mediaFiles[item.id]
        if (file == null || !file.isFile) {
            status.text = "Fichier vidéo introuvable dans le projet."
            return
        }
        try {
            val player = exoPlayer ?: ExoPlayer.Builder(this).build().also { created ->
                exoPlayer = created
                playerView.player = created
                created.addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        if (playbackState == Player.STATE_ENDED) {
                            val endedId = playingItemId
                            if (endedId != null) {
                                videoPositions.remove(endedId)
                                releaseVideoAtFrame(endedId, 0L)
                            }
                            status.text = "Vidéo terminée · aperçu de départ restauré."
                        }
                    }
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        if (!isPlaying && !suppressPauseCapture &&
                            created.playbackState == Player.STATE_READY &&
                            !created.playWhenReady && playingItemId != null
                        ) {
                            val pausedId = playingItemId
                            val position = created.currentPosition
                            if (pausedId != null) {
                                videoPositions[pausedId] = position
                                releaseVideoAtFrame(pausedId, position)
                            }
                        }
                    }
                    override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                        status.text = "Lecture vidéo impossible : ${error.message ?: "format non pris en charge"}"
                        releaseVideoAtFrame(playingItemId, 0L)
                    }
                })
            }
            if (playingItemId == item.id && player.isPlaying) {
                player.pause()
                playerView.showController()
                return
            }
            if (playingItemId != null && playingItemId != item.id) {
                releaseVideoAtFrame(playingItemId, player.currentPosition)
            }
            playingItemId = item.id
            playerView.visibility = View.VISIBLE
            updateInlinePlayerOverlay()
            playerView.useController = true
            playerView.showController()
            suppressPauseCapture = true
            player.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)), videoPositions[item.id] ?: 0L)
            player.prepare()
            player.playWhenReady = true
            suppressPauseCapture = false
            status.text = "Lecture intégrée · contrôles sur la vidéo"
        } catch (e: Exception) {
            stopInlineVideo()
            status.text = "Lecture vidéo impossible : ${e.message}"
        }
    }

    private fun updateInlinePlayerOverlay() {
        if (!::playerView.isInitialized || playerView.visibility != View.VISIBLE) return
        val currentId = playingItemId
        val item = doc.items.firstOrNull { it.id == currentId && it.visible }
        if (item == null || editMode || selectedId != currentId) {
            if (currentId != null) releaseVideoAtFrame(currentId, exoPlayer?.currentPosition ?: 0L)
            return
        }
        val geometry = canvasView.videoOverlayGeometry(item) ?: return
        val rect = geometry.first
        val params = FrameLayout.LayoutParams(
            rect.width().toInt().coerceAtLeast(1),
            rect.height().toInt().coerceAtLeast(1)
        )
        params.leftMargin = rect.left.toInt()
        params.topMargin = rect.top.toInt()
        playerView.layoutParams = params
        playerView.rotation = geometry.second
    }

    private fun releaseVideoAtFrame(itemId: String?, positionMs: Long) {
        if (itemId == null) return
        videoPositions[itemId] = positionMs.coerceAtLeast(0L)
        val file = mediaFiles[itemId]
        val activePlayer = exoPlayer
        suppressPauseCapture = true
        activePlayer?.pause()
        suppressPauseCapture = false
        if (playingItemId == itemId) {
            playerView.visibility = View.GONE
            playerView.rotation = 0f
            playingItemId = null
        }
        if (file != null && file.isFile) {
            thread {
                ThumbnailCache.generateVideoFrameAt(itemId, file, positionMs)
                runOnUiThread {
                    // Do not clear a different video if the user started it while
                    // this poster frame was being decoded.
                    if (playingItemId == null) {
                        suppressPauseCapture = true
                        activePlayer?.clearMediaItems()
                        suppressPauseCapture = false
                    }
                    canvasView.invalidate()
                }
            }
        } else {
            if (playingItemId == null) activePlayer?.clearMediaItems()
        }
    }

    private fun stopInlineVideo() {
        val currentId = playingItemId
        if (currentId != null) {
            val position = exoPlayer?.currentPosition ?: videoPositions[currentId] ?: 0L
            videoPositions[currentId] = position
            releaseVideoAtFrame(currentId, position)
        } else {
            suppressPauseCapture = true
            exoPlayer?.pause()
            exoPlayer?.clearMediaItems()
            suppressPauseCapture = false
            if (::playerView.isInitialized) playerView.visibility = View.GONE
        }
    }

    override fun onDestroy() {
        suppressPauseCapture = true
        exoPlayer?.release()
        exoPlayer = null
        super.onDestroy()
    }

    private fun deleteSelected() {
        val ids = if (selectedIds.isNotEmpty()) selectedIds.toSet() else (selectedId?.let { setOf(it) } ?: emptySet())
        playingItemId?.let { if (it in ids) stopInlineVideo() }
        if (ids.isEmpty()) { status.text = "Sélectionne d'abord un calque."; return }
        val referenced = doc.items.filter { it.id !in ids && it.visible }.flatMap { it.sourceItemIds }.toSet()
        if (ids.any { it in referenced }) {
            status.text = "Ce média est conservé comme source d'une fusion. Supprime d'abord la fusion."
            return
        }
        val restoreIds = doc.items.filter { it.id in ids }.flatMap { it.sourceItemIds }.toSet()
        doc.items.filter { it.id in ids }.forEach { item ->
            mediaFiles.remove(item.id)?.let { it.delete() }
            ThumbnailCache.remove(item.id)
        }
        doc.items.removeAll { it.id in ids }
        doc.items.filter { it.id in restoreIds }.forEach { it.visible = true }
        selectedIds.clear()
        selectedId = null
        canvasView.invalidate(); refreshLayerStrip()
        status.text = "Calque(s) supprimé(s). Les sources d'une fusion ont été restaurées."
    }

    private fun restoreSelectedSources() {
        val hiddenSelected = doc.items.filter { it.id in selectedIds && !it.visible }
        if (hiddenSelected.isEmpty()) {
            status.text = "Sélectionne un calque masqué issu d'une fusion."
            return
        }
        val sourceIds = hiddenSelected.map { it.id }.toSet()
        val composites = doc.items.filter { it.visible && it.sourceItemIds.any { sourceId -> sourceId in sourceIds } }
        if (composites.isEmpty()) {
            hiddenSelected.forEach { it.visible = true }
        } else {
            composites.forEach { composite ->
                composite.visible = false
                doc.items.filter { it.id in composite.sourceItemIds }.forEach { it.visible = true }
            }
        }
        selectedIds.clear()
        val restored = doc.items.filter { it.visible && (it.id in sourceIds || composites.any { c -> it.id in c.sourceItemIds }) }
        restored.forEach { selectedIds.add(it.id) }
        selectedId = restored.lastOrNull()?.id
        canvasView.invalidate()
        refreshLayerStrip()
        status.text = "Fusion dissociée : les calques sources sont de nouveau accessibles."
    }

    private fun mergeSelectedLayers() {
        val selected = doc.items.filter { it.id in selectedIds && it.visible }
        if (selected.size < 2) {
            status.text = "Sélectionne au moins deux calques avec un appui long dans la liste."
            return
        }
        playingItemId?.let { if (it in selectedIds) stopInlineVideo() }
        val snapshot = selected.map { it.copy(sourceItemIds = it.sourceItemIds.toMutableList()) }
        val files = snapshot.associate { it.id to mediaFiles[it.id] }
        progress.visibility = View.VISIBLE
        progress.isIndeterminate = true
        status.text = "Fusion des calques…"
        thread {
            var output: File? = null
            try {
                val bounds = snapshot.map { item ->
                    val cx = item.x * doc.canvasWidth
                    val cy = item.y * doc.canvasHeight
                    val w = item.width * doc.canvasWidth
                    val h = item.height * doc.canvasHeight
                    val r = Math.toRadians(item.rotation.toDouble())
                    val ex = (kotlin.math.abs(kotlin.math.cos(r)) * w + kotlin.math.abs(kotlin.math.sin(r)) * h) / 2.0
                    val ey = (kotlin.math.abs(kotlin.math.sin(r)) * w + kotlin.math.abs(kotlin.math.cos(r)) * h) / 2.0
                    floatArrayOf((cx - ex).toFloat(), (cy - ey).toFloat(), (cx + ex).toFloat(), (cy + ey).toFloat())
                }
                val left = bounds.minOf { it[0] }.coerceAtLeast(0f)
                val top = bounds.minOf { it[1] }.coerceAtLeast(0f)
                val right = bounds.maxOf { it[2] }.coerceAtMost(doc.canvasWidth.toFloat())
                val bottom = bounds.maxOf { it[3] }.coerceAtMost(doc.canvasHeight.toFloat())
                val logicalW = (right - left).coerceAtLeast(1f)
                val logicalH = (bottom - top).coerceAtLeast(1f)
                val scale = minOf(1f, 2560f / max(logicalW, logicalH))
                val outW = (logicalW * scale).toInt().coerceAtLeast(1)
                val outH = (logicalH * scale).toInt().coerceAtLeast(1)
                val bitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)
                canvas.scale(scale, scale)
                canvas.translate(-left, -top)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                snapshot.forEach { item ->
                    val source = files[item.id] ?: throw IOException("Média absent : ${item.displayName}")
                    val mergeBitmap = decodeMergeBitmap(source, item.kind)
                        ?: throw IOException("Média illisible pour la fusion : ${item.displayName}")
                    val cx = item.x * doc.canvasWidth
                    val cy = item.y * doc.canvasHeight
                    val w = item.width * doc.canvasWidth
                    val h = item.height * doc.canvasHeight
                    val rect = RectF(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)
                    canvas.save()
                    canvas.rotate(item.rotation, cx, cy)
                    drawFittedBitmap(canvas, mergeBitmap, rect, paint, item.fitMode)
                    canvas.restore()
                    mergeBitmap.recycle()
                }
                output = File(filesDir, "project-media/imports/${UUID.randomUUID()}_fusion.png")
                output!!.parentFile?.mkdirs()
                FileOutputStream(output!!).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
                bitmap.recycle()
                val mergedId = UUID.randomUUID().toString()
                val merged = ProjectItem(
                    id = mergedId,
                    mediaPath = "media/${mergedId}_fusion.png",
                    displayName = "Fusion ${snapshot.size} calques",
                    mimeType = "image/png",
                    kind = "image",
                    x = (left + right) / (2f * doc.canvasWidth),
                    y = (top + bottom) / (2f * doc.canvasHeight),
                    width = logicalW / doc.canvasWidth,
                    height = logicalH / doc.canvasHeight,
                    sha256 = ProjectArchive.sha256(output!!),
                    sourceWidth = outW,
                    sourceHeight = outH,
                    fitMode = "contain",
                    sourceItemIds = snapshot.flatMap { if (it.sourceItemIds.isEmpty()) listOf(it.id) else it.sourceItemIds }.distinct().toMutableList()
                )
                runOnUiThread {
                    snapshot.forEach { original ->
                        val current = doc.items.firstOrNull { it.id == original.id } ?: return@forEach
                        if (current.sourceItemIds.isNotEmpty()) {
                            // A previous flattened bitmap is an intermediate derivative:
                            // discard it and keep only its original source assets.
                            doc.items.remove(current)
                            mediaFiles.remove(current.id)?.delete()
                            ThumbnailCache.remove(current.id)
                        } else {
                            current.visible = false
                        }
                    }
                    doc.items.add(merged)
                    mediaFiles[merged.id] = output!!
                    selectedIds.clear(); selectedIds.add(merged.id); selectedId = merged.id
                    canvasView.invalidate(); refreshLayerStrip()
                    progress.visibility = View.GONE
                    status.text = "Fusion créée. Originaux conservés dans le projet et référencés."
                }
            } catch (e: Exception) {
                output?.delete()
                runOnUiThread {
                    progress.visibility = View.GONE
                    status.text = "Fusion impossible : ${e.message}"
                }
            }
        }
    }

    private fun decodeMergeBitmap(file: File, kind: String): Bitmap? {
        return try {
            if (kind == "image") {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.absolutePath, bounds)
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
                var sample = 1
                while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 2560) sample *= 2
                var bitmap = BitmapFactory.decodeFile(
                    file.absolutePath,
                    BitmapFactory.Options().apply { inSampleSize = sample }
                ) ?: return null
                val maxSide = max(bitmap.width, bitmap.height)
                if (maxSide > 2560) {
                    val ratio = 2560f / maxSide
                    val scaled = Bitmap.createScaledBitmap(
                        bitmap,
                        (bitmap.width * ratio).toInt().coerceAtLeast(1),
                        (bitmap.height * ratio).toInt().coerceAtLeast(1),
                        true
                    )
                    if (scaled !== bitmap) { bitmap.recycle(); bitmap = scaled }
                }
                val orientation = try {
                    ExifInterface(file.absolutePath).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                    )
                } catch (_: Exception) { ExifInterface.ORIENTATION_NORMAL }
                val matrix = Matrix()
                when (orientation) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                    ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                    ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                    ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
                    ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
                    ExifInterface.ORIENTATION_TRANSPOSE -> { matrix.postScale(-1f, 1f); matrix.postRotate(90f) }
                    ExifInterface.ORIENTATION_TRANSVERSE -> { matrix.postScale(-1f, 1f); matrix.postRotate(270f) }
                }
                if (matrix.isIdentity()) bitmap else {
                    val oriented = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
                    if (oriented !== bitmap) bitmap.recycle()
                    oriented
                }
            } else if (kind == "video") {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(file.absolutePath)
                    var frame = retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: return null
                    val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                    if (rotation % 360 != 0) {
                        val rotated = Bitmap.createBitmap(
                            frame, 0, 0, frame.width, frame.height,
                            Matrix().apply { postRotate(rotation.toFloat()) }, true
                        )
                        if (rotated !== frame) { frame.recycle(); frame = rotated }
                    }
                    val maxSide = max(frame.width, frame.height)
                    if (maxSide <= 2560) frame else {
                        val ratio = 2560f / maxSide
                        Bitmap.createScaledBitmap(
                            frame,
                            (frame.width * ratio).toInt().coerceAtLeast(1),
                            (frame.height * ratio).toInt().coerceAtLeast(1),
                            true
                        ).also { if (it !== frame) frame.recycle() }
                    }
                } finally {
                    retriever.release()
                }
            } else null
        } catch (_: OutOfMemoryError) {
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun drawFittedBitmap(canvas: Canvas, bitmap: Bitmap, target: RectF, paint: Paint, mode: String) {
        if (mode == "stretch") {
            canvas.drawBitmap(bitmap, null, target, paint)
            return
        }
        val sourceAspect = bitmap.width.toFloat() / bitmap.height.coerceAtLeast(1)
        val targetAspect = target.width() / target.height().coerceAtLeast(1f)
        if (mode == "cover") {
            val src = if (sourceAspect > targetAspect) {
                val cropWidth = (bitmap.height * targetAspect).toInt().coerceIn(1, bitmap.width)
                val left = (bitmap.width - cropWidth) / 2
                Rect(left, 0, left + cropWidth, bitmap.height)
            } else {
                val cropHeight = (bitmap.width / targetAspect).toInt().coerceIn(1, bitmap.height)
                val top = (bitmap.height - cropHeight) / 2
                Rect(0, top, bitmap.width, top + cropHeight)
            }
            canvas.drawBitmap(bitmap, src, target, paint)
        } else {
            val fittedW: Float
            val fittedH: Float
            if (sourceAspect > targetAspect) {
                fittedW = target.width()
                fittedH = fittedW / sourceAspect
            } else {
                fittedH = target.height()
                fittedW = fittedH * sourceAspect
            }
            val dst = RectF(target.centerX() - fittedW / 2f, target.centerY() - fittedH / 2f,
                target.centerX() + fittedW / 2f, target.centerY() + fittedH / 2f)
            canvas.drawBitmap(bitmap, null, dst, paint)
        }
    }

    private fun exportCanvasPng(uri: Uri) {
        status.text = "Rendu de l'aperçu PNG…"
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        thread {
            var bitmap: Bitmap? = null
            try {
                // PNG export is intentionally an editor-preview export, not the
                // final-resolution renderer. It uses cached, bounded thumbnails.
                val exportScale = minOf(1f, 2560f / doc.canvasWidth.coerceAtLeast(1), 2560f / doc.canvasHeight.coerceAtLeast(1))
                val outW = (doc.canvasWidth * exportScale).toInt().coerceAtLeast(1)
                val outH = (doc.canvasHeight * exportScale).toInt().coerceAtLeast(1)
                val outputBitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
                bitmap = outputBitmap
                val canvas = Canvas(outputBitmap)
                canvas.drawColor(Color.WHITE)
                val snapshot = doc.items.filter { it.visible }.toList()
                // Try to prepare missing previews off the UI thread before rendering.
                snapshot.forEach { item ->
                    val file = mediaFiles[item.id]
                    if (file != null && ThumbnailCache.get(item.id) == null) ThumbnailCache.generate(item.id, file, item.kind)
                }
                val localPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                snapshot.forEach { item ->
                    val cx = item.x * outW; val cy = item.y * outH
                    val w = item.width * outW; val h = item.height * outH
                    val rect = RectF(cx-w/2, cy-h/2, cx+w/2, cy+h/2)
                    val thumb = ThumbnailCache.get(item.id)
                    if (thumb != null) {
                        canvas.save()
                        canvas.rotate(item.rotation, cx, cy)
                        drawFittedBitmap(canvas, thumb, rect, localPaint, item.fitMode)
                        canvas.restore()
                    }
                    else {
                        localPaint.color = Color.LTGRAY
                        canvas.drawRoundRect(rect, 8f, 8f, localPaint)
                        localPaint.color = Color.DKGRAY; localPaint.textSize = 22f
                        canvas.drawText(item.displayName.take(30), rect.left+8f, rect.centerY(), localPaint)
                    }
                }
                contentResolver.openOutputStream(uri)?.use { out ->
                    if (!outputBitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) throw IOException("La compression PNG a échoué.")
                } ?: throw IOException("Impossible d'écrire le PNG choisi.")
                runOnUiThread { status.text = "PNG d’aperçu exporté en ${outW} × ${outH} px (limité à 2560 px par côté, vignettes utilisées)." }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Export PNG échoué : ${e.message}" }
            } finally {
                bitmap?.recycle()
                runOnUiThread { progress.visibility = View.GONE }
            }
        }
    }

    private fun exportInteractivePackage(uri: Uri) {
        status.text = "Préparation du HTML autonome…"
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        thread {
            val prepared = mutableListOf<File>()
            val tempHtml = File(cacheDir, "studio_export_${UUID.randomUUID()}.html")
            try {
                val manifest = doc.toJson().toString().replace("</", "<\\/")
                // Build and close the complete HTML locally before touching the
                // Android document provider. This prevents a half-written file
                // from being reported as a successful export if media encoding
                // fails or the destination provider interrupts a long write.
                FileOutputStream(tempHtml).buffered(64 * 1024).use { raw ->
                    fun write(value: String) { raw.write(value.toByteArray(Charsets.UTF_8)) }
                    write("""<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,user-scalable=no">
<title>Studio Mobile — ${safeDocName(doc.name)}</title><style>
:root{--bg:#182225;--panel:#1f2b2f;--panel2:#233036;--line:#324046;--ink:#EDEEE9;--dim:#9AACB0;--accent:#E3A857}
*{box-sizing:border-box}html,body{margin:0;height:100%;font:14px system-ui,sans-serif;background:var(--bg);color:var(--ink)}body{display:flex;flex-direction:column;overflow:hidden}
header{display:flex;align-items:center;gap:10px;padding:10px 12px;background:var(--panel);border-bottom:1px solid var(--line);flex-shrink:0}header strong{letter-spacing:.04em}#menuToggle{background:var(--panel2);border:1px solid var(--line);color:var(--ink);border-radius:9px;padding:8px 11px}#dim{margin-left:auto;color:var(--dim);font-size:11px;white-space:nowrap}
.toolbar{display:flex;gap:6px;overflow-x:auto;padding:8px;background:var(--panel2);border-bottom:1px solid var(--line);flex-shrink:0}.toolbar button{background:var(--panel);border:1px solid var(--line);color:var(--ink);border-radius:7px;padding:7px 10px;white-space:nowrap;font-size:12px}
body.view-mode .toolbar,body.view-mode aside{display:none}main{display:flex;flex:1;min-height:0}.zone{flex:1;min-width:0;display:flex;align-items:center;justify-content:center;overflow:auto;padding:12px;background-color:var(--bg);background-image:linear-gradient(45deg,var(--panel2) 25%,transparent 25%),linear-gradient(-45deg,var(--panel2) 25%,transparent 25%),linear-gradient(45deg,transparent 75%,var(--panel2) 75%),linear-gradient(-45deg,transparent 75%,var(--panel2) 75%);background-size:16px 16px;background-position:0 0,0 8px,8px -8px,-8px 0}
#stage{position:relative;flex-shrink:0;transform-origin:center center;touch-action:none;background:#0f1517;border:1px solid var(--line);box-shadow:0 8px 30px #0007;overflow:hidden}.item{position:absolute;transform:translate(-50%,-50%) rotate(var(--rotation,0deg));overflow:hidden;background:#233036;outline:1px solid #324046;touch-action:none}.item.active{outline:2px solid var(--accent);z-index:999!important}.item img,.item video{width:100%;height:100%;object-fit:contain;display:block}.handle{position:absolute;right:0;bottom:0;width:20px;height:20px;background:var(--accent);border:2px solid #182225;border-radius:50%;touch-action:none}.rotate-handle{position:absolute;right:0;top:0;width:20px;height:20px;background:#75c5b4;border:2px solid #182225;border-radius:50%;touch-action:none}body.view-mode .item{outline:none}body.view-mode .handle,body.view-mode .rotate-handle{display:none}
aside{width:88px;flex-shrink:0;overflow:auto;padding:7px;background:var(--panel);border-left:1px solid var(--line)}.layer{width:100%;min-height:48px;margin-bottom:7px;border:2px solid transparent;border-radius:8px;background:#0f1517;color:var(--ink);font-size:10px;padding:6px;overflow:hidden}.layer.active{border-color:var(--accent)}footer{padding:7px 10px;background:var(--panel);border-top:1px solid var(--line);font-size:11px;color:var(--dim);flex-shrink:0}button:active{transform:translateY(1px)}
</style></head><body><header><strong>STUDIO · MOBILE</strong><button id="playMain" aria-label="Lire les vidéos">▶</button><button id="recenterMain" aria-label="Recentrer la vue">◎</button><button id="menuToggle" aria-expanded="false">☰ Menu</button><span id="dim"></span></header>
<div class="toolbar"><button id="up">Calque ↑</button><button id="down">Calque ↓</button><button id="bigger">Taille +</button><button id="smaller">Taille −</button><button id="reset">Centrer</button><button id="zoomOut">Vue −</button><button id="zoomIn">Vue +</button><button id="rotateView">Tourner vue</button><button id="resetView">Réinitialiser vue</button><button id="playAll">Lire les vidéos</button></div>
<main><section class="zone"><div id="stage"></div></section><aside id="layers"></aside></main><footer id="status">Projet autonome · médias intégrés à ce fichier HTML. Les photos sont plafonnées à 2560 px sur leur plus grand côté. Les vidéos sont chargées à la demande.</footer>
<script>
const doc = $manifest;
const mediaSources = {
""")
                    val exportItems = doc.items.filter { it.visible }
                    exportItems.forEachIndexed { index, item ->
                        val source = mediaFiles[item.id] ?: throw IOException("Média absent : ${item.displayName}")
                        val fileToEmbed = if (item.kind == "image") prepareHtmlImage(source, item.mimeType).also { if (it != source) prepared.add(it) } else source
                        val mime = if (item.kind == "image" && fileToEmbed != source && item.mimeType != "image/png") "image/jpeg" else item.mimeType
                        write(JSONObjectQuote(item.id) + ":\"data:$mime;base64,")
                        val expectedBytes = fileToEmbed.length()
                        val nonClosing = object : java.io.FilterOutputStream(raw) { override fun close() { flush() } }
                        val encodedInputBytes = java.util.Base64.getEncoder().wrap(nonClosing).use { encoded ->
                            fileToEmbed.inputStream().buffered().use { input -> input.copyTo(encoded, 64 * 1024) }
                        }
                        if (encodedInputBytes != expectedBytes) throw IOException("Média intégré partiellement : ${item.displayName} ($encodedInputBytes / $expectedBytes octets).")
                        write("\"")
                        if (index < exportItems.lastIndex) write(",")
                        val pct = ((index + 1) * 100) / exportItems.size.coerceAtLeast(1)
                        runOnUiThread { progress.isIndeterminate = false; progress.progress = pct; status.text = "Intégration des médias : $pct%" }
                    }
                    write("""
};
const stage=document.getElementById('stage'),rail=document.getElementById('layers'),status=document.getElementById('status');
const visibleItems=doc.items.filter(x=>x.visible!==false);let selected=visibleItems.length?visibleItems[visibleItems.length-1].id:null;
document.body.classList.add('view-mode');const menuToggle=document.getElementById('menuToggle');menuToggle.onclick=()=>{const viewing=document.body.classList.toggle('view-mode');menuToggle.setAttribute('aria-expanded',String(!viewing));menuToggle.textContent=viewing?'☰ Menu':'✕ Fermer';};
let camera={scale:1,rotation:0,x:0,y:0};function applyCamera(){stage.style.transform='translate('+camera.x+'px,'+camera.y+'px) scale('+camera.scale+') rotate('+camera.rotation+'deg)';status.textContent='Vue '+Math.round(camera.scale*100)+' % · gestes à deux doigts pour déplacer, zoomer et tourner la vue';}function fitStage(){const zone=document.querySelector('.zone');const scale=Math.min(1,(zone.clientWidth-24)/doc.canvas.width,(zone.clientHeight-24)/doc.canvas.height);stage.style.width=Math.max(1,doc.canvas.width*scale)+'px';stage.style.height=Math.max(1,doc.canvas.height*scale)+'px';applyCamera()}fitStage();window.addEventListener('resize',fitStage);document.getElementById('dim').textContent=doc.canvas.width+' × '+doc.canvas.height+' px';document.getElementById('zoomIn').onclick=()=>{camera.scale=Math.min(8,camera.scale*1.25);applyCamera()};document.getElementById('zoomOut').onclick=()=>{camera.scale=Math.max(.2,camera.scale/1.25);applyCamera()};document.getElementById('rotateView').onclick=()=>{camera.rotation=(camera.rotation+90)%360;applyCamera()};document.getElementById('resetView').onclick=()=>{camera={scale:1,rotation:0,x:0,y:0};applyCamera()};
function byId(id){return visibleItems.find(x=>x.id===id)}function sourceFor(item){return mediaSources[item.id]}
function screenToStage(x,y){const z=document.querySelector('.zone').getBoundingClientRect(),cx=z.left+z.width/2+camera.x,cy=z.top+z.height/2+camera.y,dx=(x-cx)/camera.scale,dy=(y-cy)/camera.scale,a=-camera.rotation*Math.PI/180;return{x:stage.clientWidth/2+dx*Math.cos(a)-dy*Math.sin(a),y:stage.clientHeight/2+dx*Math.sin(a)+dy*Math.cos(a)}}
let cameraGesture=null;stage.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'&&e.button!==0)return;if(!cameraGesture)cameraGesture={points:new Map(),start:{...camera},pointerType:e.pointerType,panAllowed:(document.body.classList.contains('view-mode')&&!e.target.closest('video'))||e.target===stage,origin:{x:e.clientX,y:e.clientY}};cameraGesture.points.set(e.pointerId,{x:e.clientX,y:e.clientY});});window.addEventListener('pointermove',e=>{if(!cameraGesture||!cameraGesture.points.has(e.pointerId))return;cameraGesture.points.set(e.pointerId,{x:e.clientX,y:e.clientY});if(cameraGesture.points.size===1&&cameraGesture.panAllowed&&Math.hypot(e.clientX-cameraGesture.origin.x,e.clientY-cameraGesture.origin.y)>4){camera.x=cameraGesture.start.x+e.clientX-cameraGesture.origin.x;camera.y=cameraGesture.start.y+e.clientY-cameraGesture.origin.y;applyCamera()}if(cameraGesture.points.size>=2){const pts=[...cameraGesture.points.values()],a=pts[0],b=pts[1],span=Math.hypot(b.x-a.x,b.y-a.y),ang=Math.atan2(b.y-a.y,b.x-a.x)*180/Math.PI;if(!cameraGesture.initial){cameraGesture.initial={span,ang,mid:{x:(a.x+b.x)/2,y:(a.y+b.y)/2},camera:{...camera}}}const z=cameraGesture.initial;camera.scale=Math.max(.2,Math.min(8,z.camera.scale*span/Math.max(1,z.span)));camera.rotation=z.camera.rotation+(ang-z.ang);camera.x=z.camera.x+((a.x+b.x)/2-z.mid.x);camera.y=z.camera.y+((a.y+b.y)/2-z.mid.y);applyCamera()}});function endCameraPointer(e){if(cameraGesture){cameraGesture.points.delete(e.pointerId);if(cameraGesture.points.size===0)cameraGesture=null;else{const p=[...cameraGesture.points.values()][0];cameraGesture.start={...camera};cameraGesture.origin={x:p.x,y:p.y};cameraGesture.initial=null}}}window.addEventListener('pointerup',endCameraPointer);window.addEventListener('pointercancel',endCameraPointer);
function loadVideo(video,item){if(video.dataset.ready==='1')return Promise.resolve(video);if(video._loadPromise)return video._loadPromise;video.dataset.loading='1';video._loadPromise=new Promise((resolve,reject)=>{const ready=()=>{video.dataset.ready='1';video.dataset.loading='';resolve(video)};const failed=()=>{video.dataset.loading='';reject(new Error('Lecture du média impossible'))};video.addEventListener('loadeddata',ready,{once:true});video.addEventListener('error',failed,{once:true});video.src=sourceFor(item);video.load()}).catch(err=>{status.textContent='Vidéo illisible : '+err.message;throw err});return video._loadPromise;}
function select(id){selected=id;renderSelection()}
function renderSelection(){document.querySelectorAll('.item').forEach(e=>e.classList.toggle('active',e.dataset.id===selected));document.querySelectorAll('.layer').forEach(e=>e.classList.toggle('active',e.dataset.id===selected))}
function render(){stage.innerHTML='';rail.innerHTML='';visibleItems.forEach((item,index)=>{const box=document.createElement('div');box.className='item';box.dataset.id=item.id;box.style.left=(item.x*100)+'%';box.style.top=(item.y*100)+'%';box.style.width=(item.width*100)+'%';box.style.height=(item.height*100)+'%';box.style.setProperty('--rotation',(item.rotation||0)+'deg');box.style.zIndex=String(index+1);let media;if(item.kind==='video'){media=document.createElement('video');media.controls=true;media.preload='none';media.playsInline=true;media.setAttribute('webkit-playsinline','');media.style.objectFit=item.fitMode||'cover';media.addEventListener('play',()=>{if(media.dataset.ready!=='1'){media.pause();loadVideo(media,item).then(()=>media.play()).catch(()=>{});return;}stage.querySelectorAll('video').forEach(other=>{if(other!==media)other.pause()});});media.addEventListener('error',()=>{status.textContent='Vidéo illisible dans ce navigateur ou format non pris en charge.'},{once:true})}else if(item.kind==='image'){media=document.createElement('img');media.loading='lazy';media.decoding='async';media.src=sourceFor(item);media.alt=item.displayName;media.style.objectFit=item.fitMode||'cover' }else{media=document.createElement('div');media.textContent=item.displayName}box.appendChild(media);const handle=document.createElement('div');handle.className='handle';box.appendChild(handle);const rotateHandle=document.createElement('div');rotateHandle.className='rotate-handle';box.appendChild(rotateHandle);box.addEventListener('pointerdown',e=>{if(document.body.classList.contains('view-mode'))return;if(e.target===media&&item.kind==='video')return;e.preventDefault();select(item.id);box.setPointerCapture(e.pointerId);const p0=screenToStage(e.clientX,e.clientY);const sx=doc.canvas.width/stage.clientWidth,sy=doc.canvas.height/stage.clientHeight;const x0=p0.x,y0=p0.y,ox=item.x,oy=item.y,ow=item.width,oh=item.height;const mode=e.target===handle?'resize':e.target===rotateHandle?'rotate':'move';const cx=item.x*stage.clientWidth,cy=item.y*stage.clientHeight;const a0=Math.atan2(y0-cy,x0-cx),rot0=item.rotation||0;function move(ev){if(cameraGesture&&cameraGesture.points.size>=2)return;const pp=screenToStage(ev.clientX,ev.clientY);if(mode==='rotate'){const a=Math.atan2(pp.y-cy,pp.x-cx);item.rotation=rot0+(a-a0)*180/Math.PI;box.style.setProperty('--rotation',item.rotation+'deg')}else if(mode==='resize'){const dx=pp.x-x0,dy=pp.y-y0,rad=-(item.rotation||0)*Math.PI/180,lx=dx*Math.cos(rad)-dy*Math.sin(rad),ly=dx*Math.sin(rad)+dy*Math.cos(rad);item.width=Math.max(.02,Math.min(2,ow+lx*sx/doc.canvas.width*2));item.height=Math.max(.02,Math.min(2,oh+ly*sy/doc.canvas.height*2));box.style.width=(item.width*100)+'%';box.style.height=(item.height*100)+'%'}else{item.x=Math.max(-.5,Math.min(1.5,ox+(pp.x-x0)*sx/doc.canvas.width));item.y=Math.max(-.5,Math.min(1.5,oy+(pp.y-y0)*sy/doc.canvas.height));box.style.left=(item.x*100)+'%';box.style.top=(item.y*100)+'%'}}function end(){box.removeEventListener('pointermove',move);box.removeEventListener('pointerup',end);box.removeEventListener('pointercancel',end)}box.addEventListener('pointermove',move);box.addEventListener('pointerup',end);box.addEventListener('pointercancel',end)});stage.appendChild(box);
const tile=document.createElement('button');tile.className='layer';tile.dataset.id=item.id;tile.textContent=(index+1)+'. '+(item.kind==='video'?'▶ ':'▧ ')+item.displayName;tile.onclick=()=>select(item.id);rail.prepend(tile)});renderSelection();if(!visibleItems.length){stage.innerHTML='<div style="color:#9AACB0;padding:20px">Projet vide</div>'}}
function moveLayer(d){const i=visibleItems.findIndex(x=>x.id===selected);if(i<0)return;const j=Math.max(0,Math.min(visibleItems.length-1,i+d));if(i!==j){const a=visibleItems.splice(i,1)[0];visibleItems.splice(j,0,a);render()}}
function scaleItem(f){const x=byId(selected);if(!x)return;x.width=Math.max(.04,Math.min(1.8,x.width*f));x.height=Math.max(.04,Math.min(1.8,x.height*f));render()}
document.getElementById('up').onclick=()=>moveLayer(1);document.getElementById('down').onclick=()=>moveLayer(-1);document.getElementById('bigger').onclick=()=>scaleItem(1.1);document.getElementById('smaller').onclick=()=>scaleItem(.9);document.getElementById('reset').onclick=()=>{const x=byId(selected);if(x){x.x=.5;x.y=.5;render()}};let playlistActive=false,stopPlaylist=null;document.getElementById('playAll').onclick=async()=>{if(playlistActive){stopPlaylist?.();return;}playlistActive=true;let stopResolve;const stopPromise=new Promise(resolve=>stopResolve=resolve);stopPlaylist=()=>{playlistActive=false;stage.querySelectorAll('video').forEach(v=>v.pause());stopResolve()};for(const item of visibleItems.filter(x=>x.kind==='video')){if(!playlistActive)break;const v=[...stage.querySelectorAll('.item')].find(e=>e.dataset.id===item.id)?.querySelector('video');if(!v)continue;try{await loadVideo(v,item);if(!playlistActive)break;await v.play();await Promise.race([new Promise(resolve=>v.addEventListener('ended',resolve,{once:true})),stopPromise]);v.pause();}catch(e){status.textContent='Lecture vidéo impossible : '+e.message;break;}}playlistActive=false;stopPlaylist=null;};document.getElementById('playMain').onclick=()=>document.getElementById('playAll').click();document.getElementById('recenterMain').onclick=()=>document.getElementById('resetView').click();render();
</script></body></html>""")
                }
                if (tempHtml.length() < 1000L) throw IOException("Le HTML généré est anormalement petit.")
                val tail = ByteArray(14)
                tempHtml.inputStream().use { input ->
                    var skipped = 0L
                    while (skipped < tempHtml.length() - tail.size) {
                        val n = input.skip(tempHtml.length() - tail.size - skipped)
                        if (n <= 0) break
                        skipped += n
                    }
                    var offset = 0
                    while (offset < tail.size) {
                        val n = input.read(tail, offset, tail.size - offset)
                        if (n < 0) break
                        offset += n
                    }
                    if (offset != tail.size || String(tail, Charsets.UTF_8) != "</body></html>") {
                        throw IOException("Le HTML temporaire est incomplet : fermeture du document absente.")
                    }
                }
                val copied = tempHtml.inputStream().buffered(64 * 1024).use { input ->
                    contentResolver.openOutputStream(uri, "wt")?.use { output -> input.copyTo(output, 64 * 1024) }
                        ?: throw IOException("Impossible d'écrire le fichier HTML.")
                }
                if (copied != tempHtml.length()) throw IOException("Copie HTML incomplète : $copied / ${tempHtml.length()} octets.")
                runOnUiThread { status.text = "HTML autonome créé et vérifié : ${tempHtml.length() / 1024} Ko. Médias intégrés." }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Export HTML échoué : ${e.message}" }
            } finally {
                prepared.forEach { it.delete() }
                tempHtml.delete()
                runOnUiThread { progress.visibility = View.GONE }
            }
        }
    }

    private fun JSONObjectQuote(value: String): String = org.json.JSONObject.quote(value)

    private fun prepareHtmlImage(source: File, mimeType: String): File {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(source.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IOException("Image illisible : ${source.name}")
        val largest = max(bounds.outWidth, bounds.outHeight)
        if (largest <= 2560) return source
        var sample = 1
        while (largest / (sample * 2) >= 2560) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
        var bitmap = BitmapFactory.decodeFile(source.absolutePath, options) ?: throw IOException("Impossible de réduire : ${source.name}")
        try {
            val maxSide = max(bitmap.width, bitmap.height)
            if (maxSide > 2560) {
                val scale = 2560f / maxSide
                val scaled = Bitmap.createScaledBitmap(bitmap, (bitmap.width * scale).toInt().coerceAtLeast(1), (bitmap.height * scale).toInt().coerceAtLeast(1), true)
                if (scaled !== bitmap) { bitmap.recycle(); bitmap = scaled }
            }
            val orientation = try { ExifInterface(source.absolutePath).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) } catch (_: Exception) { ExifInterface.ORIENTATION_NORMAL }
            val matrix = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
                ExifInterface.ORIENTATION_TRANSPOSE -> { matrix.postScale(-1f, 1f); matrix.postRotate(90f) }
                ExifInterface.ORIENTATION_TRANSVERSE -> { matrix.postScale(-1f, 1f); matrix.postRotate(270f) }
            }
            if (!matrix.isIdentity()) {
                val oriented = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
                if (oriented !== bitmap) { bitmap.recycle(); bitmap = oriented }
            }
            val output = File(cacheDir, "html_${UUID.randomUUID()}.media")
            FileOutputStream(output).buffered().use { stream ->
                val format = if (mimeType == "image/png") Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
                if (!bitmap.compress(format, 88, stream)) throw IOException("Compression image échouée : ${source.name}")
            }
            return output
        } finally { bitmap.recycle() }
    }

    private fun importedSafeName(uri: Uri) = uri.lastPathSegment?.takeLast(28) ?: "média"
    private fun safeDocName(s: String) = s.replace(Regex("[^A-Za-z0-9_-]"), "_").ifBlank { "MonProjet" }

    private inner class ProjectCanvasView : View(this@MainActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var active: ProjectItem? = null
        private var lastProjectX = 0f
        private var lastProjectY = 0f
        private var touchMoved = false
        private var touchDownX = 0f
        private var touchDownY = 0f
        private var resizeActive = false
        private var rotationActive = false
        private var resizeStartWidth = 0f
        private var resizeStartHeight = 0f
        private var resizeStartX = 0f
        private var resizeStartY = 0f
        private var rotateStartAngle = 0f
        private var rotateStartRotation = 0f
        private var zoom = 1f
        private var panX = 0f
        private var panY = 0f
        private var viewRotation = 0f
        private var gestureSpan = 0f
        private var gestureAngle = 0f
        private var gestureMidX = 0f
        private var gestureMidY = 0f
        private var gestureZoom = 1f
        private var gestureRotation = 0f
        private var gesturePanX = 0f
        private var gesturePanY = 0f
        private val viewMatrix = Matrix()
        private val inverseMatrix = Matrix()
        var onViewportChanged: (() -> Unit)? = null
        private var groupStart = emptyMap<String, FloatArray>()
        private var groupPivotX = 0f
        private var groupPivotY = 0f
        private var resizeStartDistance = 1f

        fun setEditMode(enabled: Boolean) { editMode = enabled; invalidate(); onViewportChanged?.invoke() }

        fun adjustZoom(factor: Float) { zoom = (zoom * factor).coerceIn(0.2f, 8f); invalidate(); onViewportChanged?.invoke(); status.text = "Zoom de la vue : ${(zoom * 100).toInt()} %" }
        fun rotateViewport(degrees: Float) { viewRotation = (viewRotation + degrees) % 360f; invalidate(); onViewportChanged?.invoke() }
        fun resetViewport() { zoom = 1f; panX = 0f; panY = 0f; viewRotation = 0f; invalidate(); onViewportChanged?.invoke(); status.text = "Vue réinitialisée · contenu inchangé" }

        fun videoOverlayGeometry(item: ProjectItem): Pair<RectF, Float>? {
            if (width <= 0 || height <= 0) return null
            updateMatrix()
            val center = itemCenter(item)
            val point = floatArrayOf(center.first, center.second)
            viewMatrix.mapPoints(point)
            val w = item.width * doc.canvasWidth * baseScale() * zoom
            val h = item.height * doc.canvasHeight * baseScale() * zoom
            val rect = RectF(point[0] - w / 2f, point[1] - h / 2f, point[0] + w / 2f, point[1] + h / 2f)
            return rect to (item.rotation + viewRotation)
        }

        private fun baseScale(): Float = min(width.toFloat() / doc.canvasWidth.coerceAtLeast(1), height.toFloat() / doc.canvasHeight.coerceAtLeast(1)).coerceAtLeast(0.0001f)
        private fun baseLeft(): Float = (width - doc.canvasWidth * baseScale()) / 2f
        private fun baseTop(): Float = (height - doc.canvasHeight * baseScale()) / 2f
        private fun updateMatrix() {
            val cx = width / 2f; val cy = height / 2f
            val radians = Math.toRadians(viewRotation.toDouble())
            val a = zoom * kotlin.math.cos(radians).toFloat()
            val b = -zoom * kotlin.math.sin(radians).toFloat()
            val d = zoom * kotlin.math.sin(radians).toFloat()
            val e = zoom * kotlin.math.cos(radians).toFloat()
            viewMatrix.setValues(floatArrayOf(a, b, cx + panX - a * cx - b * cy, d, e, cy + panY - d * cx - e * cy, 0f, 0f, 1f))
            viewMatrix.invert(inverseMatrix)
        }
        private fun toProjectSpace(x: Float, y: Float): Pair<Float, Float> {
            updateMatrix()
            val pts = floatArrayOf(x, y); inverseMatrix.mapPoints(pts)
            return pts[0] to pts[1]
        }
        private fun itemCenter(item: ProjectItem): Pair<Float, Float> {
            val scale = baseScale()
            return (baseLeft() + item.x * doc.canvasWidth * scale) to (baseTop() + item.y * doc.canvasHeight * scale)
        }
        private fun localPoint(x: Float, y: Float, item: ProjectItem): Pair<Float, Float> {
            val (px, py) = toProjectSpace(x, y)
            val (cx, cy) = itemCenter(item)
            val radians = Math.toRadians((-item.rotation).toDouble())
            val dx = px - cx; val dy = py - cy
            return (dx * kotlin.math.cos(radians).toFloat() - dy * kotlin.math.sin(radians).toFloat() + cx) to
                (dx * kotlin.math.sin(radians).toFloat() + dy * kotlin.math.cos(radians).toFloat() + cy)
        }
        private fun midpoint(event: MotionEvent): Pair<Float, Float> =
            ((event.getX(0) + event.getX(1)) / 2f) to ((event.getY(0) + event.getY(1)) / 2f)
        private fun span(event: MotionEvent): Float = hypot(event.getX(1)-event.getX(0), event.getY(1)-event.getY(0)).coerceAtLeast(1f)
        private fun angle(event: MotionEvent): Float = Math.toDegrees(atan2((event.getY(1)-event.getY(0)).toDouble(), (event.getX(1)-event.getX(0)).toDouble())).toFloat()
        private fun angleDelta(now: Float, before: Float): Float { var d = now-before; if (d > 180f) d-=360f; if (d < -180f) d+=360f; return d }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.rgb(24, 34, 37))
            val scale = baseScale()
            val left = baseLeft(); val top = baseTop()
            updateMatrix()
            canvas.save(); canvas.concat(viewMatrix)
            val projectRect = RectF(left, top, left + doc.canvasWidth * scale, top + doc.canvasHeight * scale)
            paint.color = Color.rgb(15, 21, 23); canvas.drawRect(projectRect, paint)
            doc.items.filter { it.visible }.forEach { item ->
                val (cx, cy) = itemCenter(item)
                // x/y/width/height are normalized against the PROJECT dimensions, never the phone View dimensions.
                val w = item.width * doc.canvasWidth * scale
                val h = item.height * doc.canvasHeight * scale
                val rect = RectF(cx-w/2, cy-h/2, cx+w/2, cy+h/2)
                canvas.save(); canvas.rotate(item.rotation, cx, cy)
                paint.color = if (item.id in selectedIds || item.id == selectedId) Color.rgb(35, 48, 54) else Color.rgb(31, 43, 47)
                canvas.drawRoundRect(rect, 8f, 8f, paint)
                val file = mediaFiles[item.id]
                if (file != null && (item.kind == "image" || item.kind == "video")) {
                    val thumb = ThumbnailCache.get(item.id)
                    if (thumb != null) {
                        paint.color = Color.WHITE
                        drawFittedBitmap(canvas, thumb, rect, paint, item.fitMode)
                    } else {
                        drawLabel(canvas, item, rect)
                        if (!ThumbnailCache.isPending(item.id)) requestThumbnail(item.id, file, item.kind)
                    }
                } else drawLabel(canvas, item, rect)
                val isSelected = item.id in selectedIds || item.id == selectedId
                paint.style = Paint.Style.STROKE; paint.strokeWidth = if (isSelected) 4f else 1.5f
                paint.color = if (isSelected) Color.rgb(227, 168, 87) else Color.rgb(50, 64, 70)
                canvas.drawRoundRect(rect, 8f, 8f, paint); paint.style = Paint.Style.FILL
                if (item.id == selectedId && editMode) {
                    paint.color = Color.rgb(227, 168, 87); canvas.drawCircle(rect.right, rect.bottom, 12f, paint)
                    paint.color = Color.rgb(24, 34, 37); canvas.drawCircle(rect.right, rect.bottom, 4f, paint)
                    paint.color = Color.rgb(117, 197, 180); canvas.drawCircle(rect.right, rect.top, 12f, paint)
                    paint.color = Color.rgb(24, 34, 37); canvas.drawCircle(rect.right, rect.top, 4f, paint)
                }
                canvas.restore()
            }
            if (doc.items.none { it.visible }) {
                paint.color = Color.rgb(154, 172, 176); paint.textSize = 18f
                canvas.drawText("Espace de composition", projectRect.left + 24f, projectRect.centerY(), paint)
                paint.textSize = 13f; canvas.drawText("Utilise « Importer » pour ajouter des médias", projectRect.left + 24f, projectRect.centerY()+26f, paint)
            }
            canvas.restore()
            paint.color = Color.rgb(154, 172, 176); paint.textSize = 11f
            canvas.drawText("${(zoom*100).toInt()} % · vue indépendante du projet", 12f, height-12f, paint)
        }
        private fun requestThumbnail(itemId: String, file: File, kind: String) {
            thread { ThumbnailCache.generate(itemId, file, kind); post { invalidate() } }
        }
        private fun coverSourceRect(bitmap: Bitmap, destination: RectF): Rect {
            val sourceAspect = bitmap.width.toFloat() / bitmap.height.coerceAtLeast(1)
            val targetAspect = destination.width() / destination.height().coerceAtLeast(1f)
            return if (sourceAspect > targetAspect) {
                val cropWidth = (bitmap.height * targetAspect).toInt().coerceIn(1, bitmap.width)
                val left = (bitmap.width - cropWidth) / 2
                Rect(left, 0, left + cropWidth, bitmap.height)
            } else {
                val cropHeight = (bitmap.width / targetAspect).toInt().coerceIn(1, bitmap.height)
                val top = (bitmap.height - cropHeight) / 2
                Rect(0, top, bitmap.width, top + cropHeight)
            }
        }
        private fun drawLabel(canvas: Canvas, item: ProjectItem, rect: RectF) {
            paint.color = Color.rgb(154, 172, 176); paint.textSize = 15f
            val label = (if (item.kind == "video") "▶ " else if (item.kind == "image") "▧ " else "▤ ") + item.displayName
            canvas.drawText(if (label.length > 22) label.take(19)+"…" else label, rect.left+8f, rect.centerY(), paint)
        }
        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    active = null; resizeActive = false; rotationActive = false; touchMoved = false
                    touchDownX = event.x; touchDownY = event.y
                    val (px, py) = toProjectSpace(event.x, event.y)
                    active = doc.items.asReversed().firstOrNull { item ->
                        if (!item.visible) return@firstOrNull false
                        val (lx, ly) = localPoint(event.x, event.y, item)
                        val (cx, cy) = itemCenter(item)
                        val w = item.width * doc.canvasWidth * baseScale(); val h = item.height * doc.canvasHeight * baseScale()
                        lx in (cx-w/2)..(cx+w/2) && ly in (cy-h/2)..(cy+h/2)
                    }
                    active?.let { item ->
                        selectedId = item.id
                        if (item.id !in selectedIds) {
                            selectedIds.clear()
                            selectedIds.add(item.id)
                        }
                    }
                    refreshLayerStrip()
                    onViewportChanged?.invoke()
                    val groupItems = doc.items.filter { it.visible && it.id in selectedIds }
                    groupStart = groupItems.associate { it.id to floatArrayOf(it.x, it.y, it.width, it.height, it.rotation) }
                    groupPivotX = if (groupItems.isNotEmpty()) groupItems.map { itemCenter(it).first }.average().toFloat() else 0f
                    groupPivotY = if (groupItems.isNotEmpty()) groupItems.map { itemCenter(it).second }.average().toFloat() else 0f
                    active?.let { item ->
                        val (lx, ly) = localPoint(event.x, event.y, item); val (cx, cy) = itemCenter(item)
                        val w = item.width * doc.canvasWidth * baseScale(); val h = item.height * doc.canvasHeight * baseScale()
                        val right = cx+w/2; val bottom = cy+h/2; val top = cy-h/2
                        if (editMode && hypot(lx-right, ly-top) <= 32f) {
                            rotationActive = true; rotateStartRotation = item.rotation
                            val (pointerX, pointerY) = toProjectSpace(event.x, event.y)
                            val (itemCenterX, itemCenterY) = itemCenter(item)
                            val pivotX = if (commonPivot) groupPivotX else itemCenterX
                            val pivotY = if (commonPivot) groupPivotY else itemCenterY
                            rotateStartAngle = Math.toDegrees(atan2((pointerY - pivotY).toDouble(), (pointerX - pivotX).toDouble())).toFloat()
                        } else if (editMode && hypot(lx-right, ly-bottom) <= 32f) {
                            resizeActive = true; resizeStartWidth=item.width; resizeStartHeight=item.height; resizeStartX=lx; resizeStartY=ly
                            val (px0, py0) = toProjectSpace(event.x, event.y)
                            val (itemCenterX, itemCenterY) = itemCenter(item)
                            val pivotX = if (commonPivot) groupPivotX else itemCenterX
                            val pivotY = if (commonPivot) groupPivotY else itemCenterY
                            resizeStartDistance = hypot(px0 - pivotX, py0 - pivotY).coerceAtLeast(1f)
                        }
                    }
                    val (sx, sy) = toProjectSpace(event.x,event.y); lastProjectX=sx; lastProjectY=sy
                    invalidate(); return true
                }
                MotionEvent.ACTION_POINTER_DOWN -> {
                    if (event.pointerCount >= 2) {
                        active = null; resizeActive = false; rotationActive = false
                        gestureSpan=span(event); gestureAngle=angle(event); val (mx,my)=midpoint(event)
                        gestureMidX=mx; gestureMidY=my; gestureZoom=zoom; gestureRotation=viewRotation; gesturePanX=panX; gesturePanY=panY
                    }
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (event.pointerCount >= 2) {
                        val (mx,my)=midpoint(event)
                        zoom=(gestureZoom*span(event)/gestureSpan).coerceIn(0.2f,8f)
                        viewRotation=gestureRotation+angleDelta(angle(event),gestureAngle)
                        panX=gesturePanX+(mx-gestureMidX); panY=gesturePanY+(my-gestureMidY)
                        touchMoved=true; invalidate(); onViewportChanged?.invoke(); return true
                    }
                    if (hypot(event.x-touchDownX,event.y-touchDownY)>8f) touchMoved=true
                    val item=active
                    if (item == null || !editMode) {
                        panX += event.x-touchDownX; panY += event.y-touchDownY
                        touchDownX=event.x; touchDownY=event.y
                    } else {
                        val (px,py)=toProjectSpace(event.x,event.y)
                        val group = doc.items.filter { it.visible && it.id in selectedIds }
                        if (rotationActive) {
                            val (itemCenterX, itemCenterY) = itemCenter(item)
                            val pivotX = if (commonPivot) groupPivotX else itemCenterX
                            val pivotY = if (commonPivot) groupPivotY else itemCenterY
                            val a = Math.toDegrees(atan2((py-pivotY).toDouble(),(px-pivotX).toDouble())).toFloat()
                            val delta = angleDelta(a, rotateStartAngle)
                            group.forEach { target ->
                                val start = groupStart[target.id] ?: return@forEach
                                if (commonPivot) {
                                    val startX = baseLeft() + start[0] * doc.canvasWidth * baseScale()
                                    val startY = baseTop() + start[1] * doc.canvasHeight * baseScale()
                                    val dx = startX - groupPivotX
                                    val dy = startY - groupPivotY
                                    val radians = Math.toRadians(delta.toDouble())
                                    val nx = groupPivotX + dx * kotlin.math.cos(radians).toFloat() - dy * kotlin.math.sin(radians).toFloat()
                                    val ny = groupPivotY + dx * kotlin.math.sin(radians).toFloat() + dy * kotlin.math.cos(radians).toFloat()
                                    target.x = ((nx - baseLeft()) / (doc.canvasWidth * baseScale())).coerceIn(-0.5f, 1.5f)
                                    target.y = ((ny - baseTop()) / (doc.canvasHeight * baseScale())).coerceIn(-0.5f, 1.5f)
                                }
                                target.rotation = start[4] + delta
                            }
                        } else if (resizeActive) {
                            val (itemCenterX, itemCenterY) = itemCenter(item)
                            val pivotX = if (commonPivot) groupPivotX else itemCenterX
                            val pivotY = if (commonPivot) groupPivotY else itemCenterY
                            val factor = (hypot(px-pivotX, py-pivotY) / resizeStartDistance).coerceIn(0.1f, 10f)
                            group.forEach { target ->
                                val start = groupStart[target.id] ?: return@forEach
                                target.width = (start[2] * factor).coerceIn(0.02f, 2f)
                                target.height = (start[3] * factor).coerceIn(0.02f, 2f)
                                if (commonPivot) {
                                    val startX = baseLeft() + start[0] * doc.canvasWidth * baseScale()
                                    val startY = baseTop() + start[1] * doc.canvasHeight * baseScale()
                                    val newX = groupPivotX + (startX - groupPivotX) * factor
                                    val newY = groupPivotY + (startY - groupPivotY) * factor
                                    target.x = ((newX - baseLeft()) / (doc.canvasWidth * baseScale())).coerceIn(-0.5f, 1.5f)
                                    target.y = ((newY - baseTop()) / (doc.canvasHeight * baseScale())).coerceIn(-0.5f, 1.5f)
                                }
                            }
                        } else {
                            val dx = (px-lastProjectX) / (doc.canvasWidth * baseScale())
                            val dy = (py-lastProjectY) / (doc.canvasHeight * baseScale())
                            group.forEach { target ->
                                target.x = (target.x + dx).coerceIn(-0.5f, 1.5f)
                                target.y = (target.y + dy).coerceIn(-0.5f, 1.5f)
                            }
                        }
                        lastProjectX=px; lastProjectY=py
                    }
                    invalidate(); onViewportChanged?.invoke(); return true
                }
                MotionEvent.ACTION_POINTER_UP -> { active=null; if(event.pointerCount>1){val remaining=if(event.actionIndex==0)1 else 0;touchDownX=event.getX(remaining);touchDownY=event.getY(remaining)}; return true }
                MotionEvent.ACTION_UP -> {
                    val tappedVideo=!editMode && active?.kind=="video" && !touchMoved && !resizeActive && !rotationActive
                    active=null; resizeActive=false; rotationActive=false
                    if(tappedVideo) playSelectedVideo()
                    return true
                }
                MotionEvent.ACTION_CANCEL -> { active=null; resizeActive=false; rotationActive=false; return true }
            }
            return true
        }
    }
}
