# Compilation GitHub Actions — V3.1

Fichiers à déposer manuellement dans le dépôt existant :

- `StudioMobile-v3.1-source.zip` à la racine ;
- `build-android-v3.1.yml` dans `.github/workflows/`.

Le workflow vérifie le ZIP, l'extrait dans un répertoire temporaire, contrôle les marqueurs de version et compile uniquement ce contenu avec Java 17, Gradle 8.11.1 et Android SDK 35. Il publie `app-debug.apk` sous l'artefact `StudioMobile-v3.1-debug-apk`.

Le ZIP n'a pas besoin de `gradlew` : le runner GitHub installe explicitement Gradle 8.11.1. Le workflow ne compile pas de sources Kotlin isolées présentes ailleurs dans le dépôt.
