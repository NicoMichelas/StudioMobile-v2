# Handoff technique — Studio Mobile V3.1

## Règles de dépôt

Conserver le dépôt GitHub existant. L'utilisateur travaille depuis Android uniquement et téléverse manuellement :

1. `StudioMobile-v3.1-source.zip` à la racine ;
2. `build-android-v3.1.yml` dans `.github/workflows/`.

Ne pas renommer le dépôt, supprimer les anciens fichiers ni changer le circuit. Les prochaines versions restent V3.2, V3.3… jusqu'à décision explicite de passer à V4.

## Périmètre V3.1

Priorités : géométrie réelle des médias, ratio d'affichage, modes Vue/Modifier, sélection multiple et fusion avec conservation des sources, lecteur natif intégré et export HTML autonome.

Non inclus : Undo/Redo, autosave complexe, annotations/collaboration, desktop complet, multitrack vidéo.

## Modèle de fusion

`sourceItemIds` doit rester une liste aplatie des identifiants de médias sources originaux. Ne pas créer de chaînes `fusion -> fusion -> fusion`. Les fichiers originaux sont conservés une seule fois dans l'archive. Les PNG fusionnés sont des dérivés ; un dérivé intermédiaire est supprimé lorsqu'il est refusionné.

## Compatibilité

Ne pas modifier `applicationId` ni `namespace` (`org.studiomobile.v2`). `schemaVersion` reste 1 ; les nouveaux champs sont optionnels et les anciens projets sont lus avec `fitMode=cover`.

## Vérifications indispensables

Compiler le ZIP V3.1 via son workflow. Installer sur le Redmi Note 12 Pro Android 13. Tester d'abord `.studio` ancien, import portrait/paysage, sélection multiple, fusion/dissociation, lecture vidéo intégrée, pause/reprise et export HTML depuis `content://`. Ne pas annoncer une validation physique avant retour utilisateur.
