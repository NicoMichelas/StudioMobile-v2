# Architecture — Studio Mobile V3.1

## Modules actuels

- `MainActivity` : orchestration UI, interactions et export. Elle reste volumineuse ; aucune refonte globale n'est mêlée à cette livraison.
- `ProjectDocument` : modèle de document et sérialisation JSON.
- `ProjectArchive` : import, stockage ZIP, streaming, SHA-256 et validation.
- `ThumbnailCache` : cache borné de vignettes et extraction de poster vidéo.
- Media3/ExoPlayer : lecteur vidéo natif unique, intégré au canevas.

## Modèle des calques

`ProjectItem` conserve les champs V1 et ajoute des métadonnées facultatives :

- `sourceWidth`, `sourceHeight` : dimensions physiques du média source ;
- `fitMode` : `contain`, `cover` ou `stretch` ;
- `visible` : visibilité du calque ;
- `sourceItemIds` : identifiants des sources originales d'une fusion.

Les coordonnées `x/y/width/height` restent normalisées par rapport aux dimensions logiques du canevas. Les nouvelles propriétés sont sérialisées dans le manifeste, sans changer `schemaVersion: 1`.

## Fusion

Une fusion crée un PNG dérivé et masque ses sources. Les originaux restent des éléments du document et leurs fichiers restent dans l'archive. `sourceItemIds` contient les identifiants des feuilles originales, pas une chaîne de références imbriquées.

Lorsqu'un composite est fusionné à nouveau, son fichier dérivé intermédiaire est supprimé ; les médias originaux demeurent. Une suppression de composite restaure les sources. L'ouverture valide que chaque référence pointe vers un élément existant et qu'aucun élément ne se référence lui-même.

La fusion utilise une sortie plafonnée à 2560 px sur le plus grand côté. Les médias originaux ne sont jamais remplacés.

## Caméra et groupe

La caméra native reste temporaire : zoom, pan et rotation ne sont pas sérialisés dans le projet. Le mode Vue manipule la caméra ; le mode Modifier manipule les calques.

La sélection multiple est gérée par identifiants. Les transformations de groupe s'appuient sur des instantanés de départ pour éviter l'accumulation d'erreurs. Le pivot commun est le centre moyen des calques sélectionnés ; le pivot individuel applique la rotation autour de chaque centre.

## Vidéo native

`PlayerView` est superposé au `ProjectCanvasView`, avec une géométrie calculée depuis le centre du calque et la matrice de caméra. Un seul `ExoPlayer` est utilisé.

À la pause, la position est mémorisée et `MediaMetadataRetriever` capture une image représentative en arrière-plan. Après capture, les éléments média du lecteur sont libérés. Le cache remplace la vignette du calque, ce qui permet de conserver une prévisualisation sans garder le décodeur actif.

## Export HTML

L'export reste autonome. Les médias visibles seulement sont intégrés. Les vidéos utilisent leur URI `data:` comme source et ne sont pas copiées dans un Blob/ObjectURL. Un seul élément vidéo peut jouer à la fois ; la séquence générale attend l'événement `ended` et peut être arrêtée.

## Construction

La compilation utilise AGP 8.9.1, Kotlin 2.1.20, Java 17, Gradle 8.11.1, compileSdk 35. Le workflow installe Gradle et le SDK Android sur le runner GitHub ; aucun wrapper Gradle n'est requis dans le ZIP source.

## Risques à surveiller

- L'overlay PlayerView doit être testé sur l'appareil pour valider position, rotation et contrôles tactiles.
- La capture d'image vidéo à la pause dépend des capacités de décodage du codec.
- La fusion est une opération rasterisée, limitée à 2560 px et non annulable.
- Les exports HTML intégrant de grosses vidéos restent lourds ; l'intégration base64 évite les fichiers externes mais ne supprime pas le coût de stockage/mémoire du navigateur.
