# Changelog

## 3.1.0 — 2026-11-14

- Lecture des dimensions des images et vidéos à l'import, avec EXIF et rotation vidéo.
- Ratio initial des médias respecté ; `contain` pour les nouveaux médias, `cover` conservé pour les anciens projets.
- Ajout des modes Vue et Modifier.
- Sélection multiple par appui long, déplacement et transformations groupées avec pivot commun ou individuel.
- Fusion PNG de calques sélectionnés, conservation des sources originales, références aplaties et commande Dissocier.
- Lecteur Android intégré au canevas basé sur Media3/ExoPlayer ; lecteur unique, pause/reprise et capture d'image avant libération du média.
- Export PNG : calques visibles, rotation et ajustement pris en compte.
- Export HTML : commandes Play/Recentrer visibles dès l'ouverture, vidéos chargées directement depuis leur URI `data:`, lecture séquentielle arrêtable et une seule vidéo active.
- Validation renforcée du manifeste `.studio` et des références de fusion.
- `versionCode 8`, `versionName 3.1.0`.

## 3.0.0 — 2026-11-06

- Correction du repère de rendu Android : échelle uniforme basée sur les dimensions du projet.
- Ajout d'une caméra de vue indépendante.
- Conservation du format `.studio` v1 et export HTML autonome.
