# Studio Mobile V3.4.0

Livraison source Android Kotlin de Studio Mobile V3.4.

- `StudioMobile-v3.4-source.zip` : archive source à déposer à la racine du dépôt GitHub.
- `build-android-v3.4.yml` : workflow à déposer dans `.github/workflows/`.
- `V3.4-NOTICE.md` : installation, portée et limites.
- `V3.4-CHANGELOG.md` : modifications principales.
- `V3.4-TESTS.md` : protocole de validation sur téléphone.
- `docs/CLAUDE_HANDOFF.md` : contexte technique pour la suite.

Package conservé : `org.studiomobile.v2` ; version Android : `3.4.0` (versionCode 11).
