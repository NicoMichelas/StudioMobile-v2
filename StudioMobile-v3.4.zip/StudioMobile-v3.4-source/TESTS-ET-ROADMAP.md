# Studio Mobile V3.3 — plan de tests terrain

Cocher uniquement après essai réel. La compilation seule n'est pas une validation fonctionnelle.

## A. Build et mise à jour
- [ ] ZIP source V3.3 placé à la racine du dépôt.
- [ ] Workflow V3.3 placé dans `.github/workflows/`.
- [ ] GitHub Actions termine sans erreur.
- [ ] Artefact `StudioMobile-v3.3-debug-apk` présent.
- [ ] APK identifié comme package `org.studiomobile.v2`, version `3.3.0`, code `10`.
- [ ] Installation/mise à jour sur Redmi Note 12 Pro 5G Android 13.
- [ ] Projet de sauvegarde conservé.

## B. Interface et orientation
- [ ] En-tête, barre de fichiers et barre d'outils lisibles en portrait.
- [ ] Barre d'outils défilante horizontalement si nécessaire.
- [ ] Panneau droit Calques/Vidéo.
- [ ] Languette centrale replie réellement le panneau et libère la largeur du canevas.
- [ ] Glisser la languette redimensionne le panneau.
- [ ] Boutons −/+ changent la taille des lignes de calques.
- [ ] Rotation portrait → paysage → portrait sans disparition des médias, groupes ou sélections.

## C. Importation et gros projets
- [ ] Importer un lot d'au moins 15 photos, dont une image 12 000 × 16 000 px.
- [ ] Les aperçus ne clignotent pas et ne superposent pas le nom de fichier à l'image une fois chargés.
- [ ] Les images restent visibles après suppression/réimportation d'un autre média.
- [ ] Importer au moins 5 vidéos, dont une vidéo longue et une vidéo 4K si disponible.
- [ ] L'import reste réactif ; progression visible ; pas de fermeture inattendue.
- [ ] Sélectionner, déplacer et redimensionner un média pendant que le projet contient plusieurs vidéos.

## D. Calques, ordre et groupes
- [ ] La liste affiche le calque le plus haut en premier.
- [ ] Appui long puis glisser-déposer place un calque au-dessus d'un autre.
- [ ] Glisser un calque dans un groupe.
- [ ] Glisser un groupe dans un autre groupe.
- [ ] Sélectionner un groupe sélectionne tous ses médias ; déplacer/transformer le groupe agit sur ses membres.
- [ ] Cocher plusieurs calques puis les grouper.
- [ ] Grouper un groupe sélectionné avec un autre calque crée un nouveau groupe parent et conserve l'ancien groupe.
- [ ] Dégrouper l'en-tête dissout le groupe et conserve les calques/sous-groupes.
- [ ] Sélectionner un membre puis Dégrouper ne sort que ce membre ; les autres restent groupés.
- [ ] Sélectionner une fusion puis Dissocier fonctionne sans ouvrir son dossier.
- [ ] Glisser un calque sur une fusion crée une nouvelle fusion ; le nom indique le nombre réel de sources.
- [ ] Enregistrer/rouvrir conserve l'ordre, les groupes imbriqués et les fusions.

## E. Enregistrement et intégrité
- [ ] Enregistrer ouvre le choix Écraser / Version X+1 / Enregistrer sous lorsque possible.
- [ ] Écraser remplace le fichier courant sans changer son nom.
- [ ] Version X+1 crée un nouveau fichier avec l'indice suivant.
- [ ] Enregistrer sous crée le nom demandé.
- [ ] Ouvrir un projet vérifie les empreintes SHA-256.
- [ ] Outils → Vérifier les médias (SHA-256) indique succès sur un projet sain.
- [ ] Supprimer/dupliquer un calque puis enregistrer/rouvrir.

## F. Dimensions et recadrage
- [ ] Modifier largeur/hauteur du canevas sans déformer les médias.
- [ ] Vérifier le verrouillage du ratio et les limites 64–16 384 px.
- [ ] Recadrer une photo en déplaçant la zone et ses quatre bords.
- [ ] Valider, annuler et réinitialiser un recadrage.
- [ ] Recadrer une vidéo et vérifier le cadre pendant la lecture.
- [ ] Enregistrer/rouvrir et exporter HTML ; même cadrage attendu.

## G. Vue / Modifier et poignées
- [ ] Vue : glisser le fond déplace la caméra, pas les médias.
- [ ] Double toucher un média en Vue passe en Modifier.
- [ ] En Modifier, déplacer le calque sélectionné.
- [ ] En Modifier, toucher une fois un autre média ne vole pas la sélection.
- [ ] Double toucher un autre média change le calque actif sans quitter Modifier.
- [ ] Double toucher le média actif ou le fond revient en Vue et désélectionne.
- [ ] Deux doigts sur le média sélectionné transforment le calque/groupe ; hors média, ils naviguent dans le canevas.
- [ ] Les quatre coins redimensionnent en conservant le ratio.
- [ ] Les côtés redimensionnent uniquement l'axe saisi, sans ratio, dans le bon sens.
- [ ] Poignée de rotation indépendante fonctionnelle.

## H. Vidéo native
- [ ] Poster paysage et portrait dans le bon sens.
- [ ] Lecture, pause, reprise, fin.
- [ ] Pas d'écran noir prolongé au démarrage ; poster visible pendant le chargement.
- [ ] Une seule vidéo native active.
- [ ] Changer de calque ferme proprement le lecteur.
- [ ] Pause prolongée 30 s : retour au poster et libération du lecteur.
- [ ] Recadrage/rotation respectés pendant la lecture.
- [ ] Une image placée au-dessus d'une vidéo masque bien cette vidéo pendant la lecture.

## I. Panneau Vidéo et HTML
- [ ] Réordonner les vidéos avec ↑/↓ dans le panneau droit.
- [ ] Régler le volume de chaque vidéo indépendamment.
- [ ] Définir le poster par seconde et réexporter.
- [ ] HTML : poster visible, ordre respecté, volume respecté.
- [ ] HTML : bouton Lire devient Stop pendant la lecture ; Stop remet la séquence au début.
- [ ] HTML : Pause puis reprise.
- [ ] Ouvrir depuis le gestionnaire Android via `content://`.
- [ ] Tester Chrome et Edge Android.
- [ ] Tester Safari sur iPhone : premier toucher (préparation Blob URL), puis second toucher explicite pour démarrer la vidéo.

## J. Robustesse
- [ ] Fermer/rouvrir après import, réorganisation, groupe, fusion et recadrage.
- [ ] Vérifier absence de médias manquants.
- [ ] Tester un export interrompu (par exemple annuler le sélecteur de destination ou simuler un manque d'espace) : aucun succès ne doit être annoncé si le fichier final n'est pas écrit.
- [ ] Vérifier le message d'erreur pour un média absent ou un codec non pris en charge.
- [ ] Répéter les tests après rotation et après une longue session.

## Critère de validation

Ne pas valider V3.3 avant satisfaction des sections C, D, E, G, H et I. Les fonctions annoncées dans le changelog sont des modifications de code à tester, pas des résultats de tests déjà obtenus.
