# Studio Mobile V3.3.0

## Refonte de l'interface
- Remplacement des deux anciennes bandes de boutons par un en-tête de projet, une barre de fichiers, une barre d'outils compacte et un menu Outils.
- Thème sombre unifié, boutons cohérents et panneau droit à onglets Calques/Vidéo.
- Panneau de calques réellement repliable, redimensionnable par sa languette et lignes agrandissables/réductibles.

## Calques et groupes
- Ordre visuel du plus haut au plus bas ; glisser-déposer pour réordonner.
- Glisser un calque dans un groupe ou sur une fusion ; glisser un groupe dans un autre ; créer un nouveau groupe en réunissant un groupe et un calque.
- Sélection multiple par cases à cocher ; sélectionner l'en-tête d'un groupe sélectionne tous ses descendants pour les transformer ensemble.
- Dégrouper un groupe entier ou sortir uniquement les calques sélectionnés du groupe.
- Dissocier une fusion directement depuis le calque fusionné sélectionné.

## Sauvegarde et robustesse
- Menu Enregistrer : écraser la version courante lorsque le fournisseur de fichiers autorise l'écriture, enregistrer une version X+1, ou Enregistrer sous.
- Importation atomique afin d'éviter les modifications concurrentes du document pendant le dessin.
- Traitement séquentiel des aperçus pour éviter de lancer plusieurs extracteurs vidéo en parallèle.
- Cache disque des vignettes, cache mémoire borné et génération des posters vidéo à résolution réduite.
- Rotation de l'écran sans recréer l'activité et perdre le document en mémoire.
- Outil de vérification SHA-256.

## Canevas, recadrage et vidéo
- Recadrage manipulable directement sur le média avec grille et poignées.
- Changement de dimensions du canevas en conservant les dimensions physiques des médias.
- Quatre poignées d'angle avec ratio conservé ; poignées latérales indépendantes avec déplacement dans le bon sens.
- Poster vidéo orienté selon les dimensions d'affichage détectées.
- Lecteur basé sur TextureView, contenu recadré dans son cadre, transparence du volet d'attente et calques supérieurs redessinés au-dessus.
- Pause/reprise conservée ; libération du décodeur après 30 secondes sans reprise.
- Panneau vidéo à droite avec ordre, volume par vidéo et poster.

## Export HTML
- Le bouton de lecture passe visuellement à Stop pendant la séquence.
- Chargement vidéo iOS par Blob URL à la demande comme voie de compatibilité supplémentaire.

## Correctifs d'audit avant diffusion de la candidate
- Décodage des posters vidéo dans l'orientation encodée avant application de la rotation, pour éviter les ratios inversés sur les vidéos 90°/270°.
- Pendant la lecture native, les calques supérieurs sans vignette affichent un masque provisoire et déclenchent leur décodage : la vidéo ne transparaît plus sous un calque en attente.
- Sur Safari iOS, le premier toucher prépare la Blob URL ; un second toucher explicite lance la lecture afin de respecter la politique d'activation utilisateur du navigateur.
- Le libellé d’une fusion imbriquée compte les sources originales réelles, pas seulement les éléments fusionnés à l’étape courante.
