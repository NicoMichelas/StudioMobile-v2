# Studio Mobile V3.3 — notice et plan de validation

## Installation

1. Conserver une copie des projets `.studio` avant toute mise à jour.
2. Ajouter `StudioMobile-v3.3-source.zip` à la racine du dépôt `StudioMobile-v2`.
3. Ajouter `build-android-v3.3.yml` dans `.github/workflows/` sous le nom `build-android-v3.3.yml`.
4. Lancer le workflow **Studio Mobile V3.3 Android (source ZIP only)**.
5. Vérifier que l'artefact `StudioMobile-v3.3-debug-apk` est présent et télécharger `StudioMobile-v3.3-debug.apk`.
6. Installer l'APK sur le Redmi Note 12 Pro 5G. Le package reste `org.studiomobile.v2`, ce qui permet une mise à jour de l'application existante.

Ne pas supprimer le ZIP V3.3 après le build : il constitue la source exacte de l'APK.

## Utilisation de l'interface

- **Vue** : glisser le fond pour déplacer le canevas ; zoom, rotation et recentrage dans le menu Vue.
- **Modifier** : double-toucher un média pour entrer ; glisser le média sélectionné pour le déplacer ; glisser hors média pour naviguer dans le canevas.
- **Changer de calque en Modifier** : double-toucher un autre média ; un seul toucher ne vole pas la sélection courante.
- **Sélection multiple** : cocher les cases à gauche des calques. L'appui long sur une ligne sert maintenant au glisser-déposer.
- **Groupes** : toucher l'en-tête sélectionne le groupe entier ; toucher la flèche replie/déplie. Dégrouper l'en-tête dissout le groupe ; sélectionner seulement un membre puis Dégrouper le sort du groupe sans dissoudre les autres membres.
- **Recadrage** : Outils → Commencer le recadrage ; déplacer la zone ou ses bords ; Outils → Valider le recadrage. Réinitialiser ou annuler est disponible dans le même menu.
- **Vidéo** : onglet Vidéo du panneau droit pour modifier l'ordre avec ↑/↓, le volume et le poster. Pendant la lecture native, les calques placés au-dessus de la vidéo restent dessinés par-dessus.
- **Safari iPhone/iPad** : le premier toucher prépare le média ; toucher une seconde fois ▶ après le message « Vidéo préparée » pour démarrer la lecture.
- **Enregistrer** : choisir écraser, version suivante ou Enregistrer sous. L'écrasement n'est proposé que si Android accorde l'accès en écriture au fichier ouvert ou créé.

## Vérification SHA-256

Deux contrôles sont prévus :

- À l'ouverture d'un `.studio`, l'application recalcule et compare les empreintes SHA-256 de tous les médias. Une empreinte incorrecte bloque l'ouverture.
- Dans Outils → Vérifier les médias (SHA-256), l'application vérifie les fichiers du projet actuellement ouvert et indique le nombre d'erreurs éventuelles.

## Ce qui n'est pas encore prouvé

La génération de l'APK par GitHub Actions ne valide pas le comportement réel. Les tests sur téléphone ci-dessous restent obligatoires, notamment pour la lecture vidéo, les gros projets, les gestes et la rotation.
