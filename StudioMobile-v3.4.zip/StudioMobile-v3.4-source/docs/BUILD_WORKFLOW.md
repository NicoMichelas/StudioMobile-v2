# Construction Android V3.3

Le workflow `build-android-v3.3.yml` attend `StudioMobile-v3.3-source.zip` à la racine du dépôt.

Il vérifie l'intégrité du ZIP, extrait le projet dans un répertoire temporaire du runner et compile exclusivement ce répertoire. Aucun fallback vers des sources Kotlin déposées directement à la racine du dépôt n'est autorisé.

Environnement : Java 17, Android SDK platform-tools + platforms;android-35 + build-tools;35.0.0, Gradle 8.11.1.

Artefact attendu : `StudioMobile-v3.3-debug-apk`, fichier `StudioMobile-v3.3-debug.apk`. Le workflow vérifie également le package `org.studiomobile.v2`, `versionCode=10`, `versionName=3.3.0` et le libellé `Studio Mobile 3.3`.
