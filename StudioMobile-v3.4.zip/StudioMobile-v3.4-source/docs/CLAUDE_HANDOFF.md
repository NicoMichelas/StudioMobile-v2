# Studio Mobile V3.4 — handoff technique

## Dépôt et méthode

- Dépôt conservé : `NicoMichelas/StudioMobile-v2`.
- Package conservé : `org.studiomobile.v2`.
- Source compilée exclusivement depuis `StudioMobile-v3.4-source.zip` à la racine.
- Workflow à déposer dans `.github/workflows/build-android-v3.4.yml`.
- Ne pas supprimer les anciennes archives ni les workflows existants.

## Référence d'interface

L'image fournie par l'utilisateur `1000041700.jpg` définit la disposition à suivre : barre principale simple avec Vue, Modifier, Vidéo, Visualisation, puis Annuler/Rétablir à droite ; barre secondaire compacte et contextuelle. Ne pas réinventer le thème ni créer une interface chargée.

## V3.4

- Version `3.4.0`, versionCode `11`.
- Menus d'actions contextuels et barre secondaire par mode.
- Historique Undo/Redo borné à 40 états JSON du document.
- Incrémentation déplacement/rotation, poignées compensées par le zoom.
- Modifications non destructives de crop, symétries et limites de lecture vidéo.
- Lecture séquentielle selon `videoOrder`, frise de lecture, volume et poster réglable.
- Les nouvelles propriétés JSON sont facultatives ; `schemaVersion` reste à 1 pour lecture des projets antérieurs.

## Points à vérifier sans les déclarer acquis

- L'Undo/Redo couvre les gestes et les actions explicitement enregistrées, pas nécessairement chaque réglage de chaque panneau.
- Le rendu du cadre collectif et l'ancrage exact des poignées doivent être testés sur appareil.
- La frise générale est une première implémentation ; vérifier la proportion des segments, l'avancement et le passage d'une vidéo à l'autre.
- Le poster est réglé par pas de 10 ms ; la précision effective dépend de l'indexation du fichier vidéo et du décodeur.
- Les performances HTML sur gros projets, le plein écran et la compatibilité Chrome/Edge/Safari restent à valider.
- Pas de compilation Android locale disponible dans l'environnement de préparation ; seul GitHub Actions pourra confirmer la compilation réelle.
