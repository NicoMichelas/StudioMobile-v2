# Architecture — Studio Mobile V3.3

## Interface

- `MainActivity` construit une interface sombre compacte : en-tête projet, barre fichiers, barre d'outils défilante, zone de travail et panneau latéral droit.
- Le panneau latéral contient deux vues : calques et pistes vidéo. Sa largeur est réglable par une languette ; son repli masque réellement le panneau.
- Le canevas reste une vue native personnalisée. Les transformations de caméra sont indépendantes des coordonnées logiques du projet.

## Document et groupes

- `ProjectDocument` conserve les dimensions du canevas et les calques.
- `ProjectGroup.parentGroupId` permet des groupes imbriqués. Les éléments gardent leur `groupId` direct.
- Les groupes sont sérialisés dans le manifeste. La lecture vérifie l'existence des parents et refuse les cycles.
- Les fusions restent des composites rasterisés avec références aplaties vers les sources originales.

## Import et aperçus

- L'import copie et calcule les empreintes en arrière-plan, puis ajoute tous les éléments au document en une seule mise à jour UI.
- Un seul exécuteur `StudioMediaWorker` traite les vignettes et posters, afin d'éviter plusieurs `MediaMetadataRetriever` simultanés.
- `ThumbnailCache` utilise un cache mémoire LRU borné et des PNG de prévisualisation dans `.studio-thumbnails` à côté des médias copiés.
- Les images sont décodées par échantillonnage ; les posters vidéo utilisent `getScaledFrameAtTime` quand l'API Android le permet, puis sont corrigés selon l'aspect d'affichage détecté.

## Lecteur vidéo

- Un seul `ExoPlayer` et un `PlayerView` basé sur `TextureView`.
- `playerClipFrame` sert de fenêtre de clipping ; les transformations de recadrage sont appliquées au contenu du lecteur dans cette fenêtre.
- `occlusionView` redessine les aperçus des calques situés au-dessus de la vidéo en lecture.
- La pause conserve temporairement le lecteur pour permettre la reprise ; après 30 secondes, la position est mémorisée, le lecteur est libéré et le poster est régénéré.

## Sauvegarde et export

- La sauvegarde travaille sur une copie sérialisée du document et une copie de la table de fichiers pour éviter les modifications concurrentes.
- L'ouverture vérifie SHA-256 et les références de groupes/fusions.
- L'export HTML travaille sur un instantané ; le fichier temporaire est vérifié avant copie vers le fournisseur Android.
- Sur iOS, le lecteur HTML convertit les sources vidéo `data:` en Blob URL à la demande. Le premier toucher prépare la vidéo ; un second toucher explicite démarre la lecture pour respecter la politique d'activation utilisateur de Safari. Cette voie doit être testée sur Safari réel.

## Construction

- AGP 8.9.1, Kotlin 2.1.20, Java 17, Gradle 8.11.1, compileSdk 35.
- Le ZIP source ne contient pas `gradlew`. Le workflow installe Gradle et le SDK Android, extrait le ZIP dans `$RUNNER_TEMP` et compile exclusivement ce dossier.
