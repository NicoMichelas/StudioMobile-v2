package org.studiomobile.v2

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import androidx.exifinterface.media.ExifInterface
import android.graphics.Matrix
import java.io.FileOutputStream
import android.util.LruCache
import java.io.File
import java.util.Collections

/**
 * Bounded, background-safe thumbnail cache for canvas rendering.
 *
 * Why this exists: the original ProjectCanvasView.onDraw() called
 * BitmapFactory.decodeFile() directly, at full source resolution, on every
 * single frame redrawn (i.e. on every touch-move event, for every item).
 * For a normal photo this was wasteful; for a 12000x16000 photo it could
 * require ~768 MB for a single decode, repeated dozens of times per second,
 * which is consistent with the crashes/freezes reported on device.
 *
 * Rule enforced by this file: nothing in onDraw() ever touches a file or
 * calls BitmapFactory directly again. onDraw() only reads from this cache;
 * generation always happens on a background thread, once per item, at a
 * fixed small target size - never at source resolution.
 */
object ThumbnailCache {
    /** Longest side of a generated thumbnail, in pixels. */
    const val TARGET_SIZE = 512

    // Cap the cache at an eighth of the app's available heap, measured in KB
    // (matches the standard Android LruCache-for-bitmaps pattern).
    private val maxMemoryKb = (Runtime.getRuntime().maxMemory() / 1024).toInt()
    private val cache = object : LruCache<String, Bitmap>((maxMemoryKb / 4).coerceAtLeast(16 * 1024)) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    // Items currently being generated in the background, so we never queue
    // the same item twice while it's already in progress.
    private val inProgress: MutableSet<String> = Collections.synchronizedSet(mutableSetOf())

    fun get(itemId: String): Bitmap? = cache.get(itemId)

    fun isPending(itemId: String): Boolean = inProgress.contains(itemId)

    /**
     * Must be called from a background thread. Decodes a safe, capped-size
     * thumbnail regardless of the source file's actual resolution, and
     * stores it in the cache. Returns the thumbnail, or null on failure
     * (e.g. unsupported/corrupt file) - callers should keep showing the
     * existing label fallback in that case, not crash.
     */
    fun generate(itemId: String, file: File, kind: String): Bitmap? {
        if (!inProgress.add(itemId)) return null
        try {
            val disk = thumbnailFile(file, itemId, if (kind == "video") "video_0" else "image")
            val fromDisk = if (disk.isFile) BitmapFactory.decodeFile(disk.absolutePath) else null
            val bitmap = fromDisk ?: when (kind) {
                "image" -> decodeSampledImage(file)
                "video" -> extractVideoFrame(file)
                else -> null
            }
            if (bitmap != null) {
                cache.put(itemId, bitmap)
                if (fromDisk == null) writeThumbnail(disk, bitmap)
            }
            return bitmap
        } finally {
            inProgress.remove(itemId)
        }
    }

    fun remove(itemId: String, source: File? = null) {
        cache.remove(itemId)
        if (source != null) {
            val folder = File(source.parentFile, ".studio-thumbnails")
            val safe = itemId.replace(Regex("[^A-Za-z0-9_-]"), "_")
            folder.listFiles()?.filter { it.name.startsWith("${safe}_") }?.forEach { it.delete() }
        }
    }
    fun put(itemId: String, bitmap: Bitmap) { cache.put(itemId, bitmap) }
    fun clear() { cache.evictAll(); inProgress.clear() }

    /** Capture a paused video frame without keeping a decoder alive. Call from a background thread. */
    fun generateVideoFrameAt(itemId: String, file: File, timeMs: Long, expectedWidth: Int = 0, expectedHeight: Int = 0): Bitmap? {
        if (!inProgress.add(itemId)) return cache.get(itemId)
        try {
            val disk = thumbnailFile(file, itemId, "video_${timeMs.coerceAtLeast(0L)}")
            val fromDisk = if (disk.isFile) BitmapFactory.decodeFile(disk.absolutePath) else null
            if (fromDisk != null) { cache.put(itemId, fromDisk); return fromDisk }
            val retriever = MediaMetadataRetriever()
            val bitmap = try {
                retriever.setDataSource(file.absolutePath)
                val timeUs = timeMs.coerceAtLeast(0L) * 1000L
                val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                val fallbackRawWidth = if (rotation % 180 != 0) expectedHeight else expectedWidth
                val fallbackRawHeight = if (rotation % 180 != 0) expectedWidth else expectedHeight
                val metaWidth = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: fallbackRawWidth
                val metaHeight = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: fallbackRawHeight
                // getScaledFrameAtTime scales the encoded frame before we apply
                // its rotation metadata. Request the RAW encoded aspect here;
                // using the display aspect for a 90/270-degree video can squash
                // the decoded frame before rotating it.
                val rawAspect = if (metaWidth > 0 && metaHeight > 0) metaWidth.toFloat() / metaHeight else 1f
                val targetW = if (rawAspect >= 1f) TARGET_SIZE else (TARGET_SIZE * rawAspect).toInt().coerceAtLeast(1)
                val targetH = if (rawAspect >= 1f) (TARGET_SIZE / rawAspect).toInt().coerceAtLeast(1) else TARGET_SIZE
                val frame = (if (Build.VERSION.SDK_INT >= 27) {
                    retriever.getScaledFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, targetW, targetH)
                        ?: retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                } else retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)) ?: return null
                var oriented = applyVideoRotation(frame, retriever)
                oriented = orientToExpectedAspect(oriented, expectedWidth, expectedHeight)
                downscaleIfNeeded(oriented)
            } catch (_: OutOfMemoryError) { null } catch (_: Exception) { null } finally { retriever.release() }
            if (bitmap != null) { cache.put(itemId, bitmap); writeThumbnail(disk, bitmap) }
            return bitmap
        } finally { inProgress.remove(itemId) }
    }

    private fun thumbnailFile(source: File, itemId: String, variant: String): File {
        val folder = File(source.parentFile, ".studio-thumbnails")
        val safe = itemId.replace(Regex("[^A-Za-z0-9_-]"), "_")
        return File(folder, "${safe}_${variant}.png")
    }

    private fun writeThumbnail(file: File, bitmap: Bitmap) {
        try {
            file.parentFile?.mkdirs()
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 90, it) }
        } catch (_: Exception) { file.delete() }
    }

    private fun orientToExpectedAspect(bitmap: Bitmap, expectedWidth: Int, expectedHeight: Int): Bitmap {
        if (expectedWidth <= 0 || expectedHeight <= 0) return bitmap
        val expectedLandscape = expectedWidth >= expectedHeight
        val actualLandscape = bitmap.width >= bitmap.height
        if (expectedLandscape == actualLandscape) return bitmap
        val matrix = Matrix().apply { postRotate(90f) }
        val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        if (rotated !== bitmap) bitmap.recycle()
        return rotated
    }

    // --- Image path -----------------------------------------------------
    // Classic two-pass Android decode: first read only the bounds (no pixel
    // data allocated at all), compute a power-of-two sample size, then
    // decode once directly at that reduced size. A 12000x16000 source never
    // causes a full-resolution allocation at any point.
    private fun decodeSampledImage(file: File): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sampleSize = 1
        // Bound the longest side, including panoramas where the short side is
        // already below TARGET_SIZE. The old AND condition could decode a
        // 12000x1000 image at full resolution (~46 MiB).
        while (maxOf(bounds.outWidth, bounds.outHeight) / sampleSize > TARGET_SIZE) {
            sampleSize *= 2
        }
        val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sampleSize }
        return try {
            val decoded = BitmapFactory.decodeFile(file.absolutePath, decodeOptions) ?: return null
            val orientation = try {
                ExifInterface(file.absolutePath).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                )
            } catch (_: Exception) { ExifInterface.ORIENTATION_NORMAL }
            val matrix = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
                ExifInterface.ORIENTATION_TRANSPOSE -> { matrix.postScale(-1f, 1f); matrix.postRotate(90f) }
                ExifInterface.ORIENTATION_TRANSVERSE -> { matrix.postScale(-1f, 1f); matrix.postRotate(270f) }
            }
            if (matrix.isIdentity()) decoded else Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true).also {
                if (it !== decoded) decoded.recycle()
            }
        } catch (_: OutOfMemoryError) {
            null // extreme edge case even after sampling; fail soft, never crash the app
        }
    }

    // --- Video path -------------------------------------------------------
    // MediaMetadataRetriever is the native Android API for pulling a single
    // representative frame out of a video file without playing it - the
    // direct equivalent of the "poster frame" approach used in the earlier
    // web prototype, and the reason video items had zero preview until now.
    private fun extractVideoFrame(file: File): Bitmap? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: TARGET_SIZE
            val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: TARGET_SIZE
            val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            // Decode in the encoded orientation, then apply the rotation tag.
            // Asking for display orientation here distorts 90/270-degree clips.
            val rawAspect = if (width > 0 && height > 0) width.toFloat() / height else 1f
            val targetW = if (rawAspect >= 1f) TARGET_SIZE else (TARGET_SIZE * rawAspect).toInt().coerceAtLeast(1)
            val targetH = if (rawAspect >= 1f) (TARGET_SIZE / rawAspect).toInt().coerceAtLeast(1) else TARGET_SIZE
            val frame = (if (Build.VERSION.SDK_INT >= 27) retriever.getScaledFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, targetW, targetH)
                ?: retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            else retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)) ?: return null
            downscaleIfNeeded(applyVideoRotation(frame, retriever))
        } catch (_: OutOfMemoryError) {
            null
        } catch (_: Exception) {
            null
        } finally {
            retriever.release()
        }
    }

    private fun applyVideoRotation(bitmap: Bitmap, retriever: MediaMetadataRetriever): Bitmap {
        val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        if (rotation % 360 == 0) return bitmap
        val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
        val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        if (rotated !== bitmap) bitmap.recycle()
        return rotated
    }

    private fun downscaleIfNeeded(bitmap: Bitmap): Bitmap {
        val maxDim = maxOf(bitmap.width, bitmap.height)
        if (maxDim <= TARGET_SIZE) return bitmap
        val scale = TARGET_SIZE.toFloat() / maxDim
        val scaled = Bitmap.createScaledBitmap(
            bitmap,
            (bitmap.width * scale).toInt().coerceAtLeast(1),
            (bitmap.height * scale).toInt().coerceAtLeast(1),
            true
        )
        if (scaled !== bitmap) bitmap.recycle()
        return scaled
    }
}
