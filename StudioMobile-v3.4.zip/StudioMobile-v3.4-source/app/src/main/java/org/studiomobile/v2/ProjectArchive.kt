package org.studiomobile.v2

import android.content.ContentResolver
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import androidx.exifinterface.media.ExifInterface
import android.content.Context
import android.net.Uri
import org.json.JSONObject
import java.io.*
import java.security.MessageDigest
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object ProjectArchive {
    data class ImportedMedia(val item: ProjectItem, val cachedFile: File)

    fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n <= 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    fun importMedia(context: Context, uri: Uri, resolver: ContentResolver, progress: (Long) -> Unit): ImportedMedia {
        val name = queryName(context, uri) ?: "media_${System.currentTimeMillis()}"
        val mime = resolver.getType(uri) ?: "application/octet-stream"
        val kind = if (mime.startsWith("video/")) "video" else if (mime.startsWith("image/")) "image" else "file"
        val target = File(context.filesDir, "project-media/imports/${UUID.randomUUID()}_${safeName(name)}")
        target.parentFile?.mkdirs()
        var total = 0L
        resolver.openInputStream(uri)?.use { input ->
            FileOutputStream(target).buffered().use { output ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    output.write(buf, 0, n); total += n; progress(total)
                }
            }
        } ?: throw IOException("Impossible de lire le fichier sélectionné.")
        val hash = sha256(target)
        val id = UUID.randomUUID().toString()
        val path = "media/${id}_${safeName(name)}"
        val dimensions = readDimensions(target, kind)
        val item = ProjectItem(
            id = id,
            mediaPath = path,
            displayName = name,
            mimeType = mime,
            kind = kind,
            sha256 = hash,
            sourceWidth = dimensions.first,
            sourceHeight = dimensions.second,
            fitMode = "contain"
        )
        return ImportedMedia(item, target)
    }

    fun save(context: Context, doc: ProjectDocument, mediaFiles: Map<String, File>, output: OutputStream, progress: (Int) -> Unit) {
        ZipOutputStream(BufferedOutputStream(output)).use { zip ->
            val manifest = doc.toJson().toString(2).toByteArray(Charsets.UTF_8)
            zip.putNextEntry(ZipEntry("manifest.json")); zip.write(manifest); zip.closeEntry()
            val total = doc.items.size.coerceAtLeast(1)
            doc.items.forEachIndexed { index, item ->
                val file = mediaFiles[item.id] ?: throw IOException("Média absent du stockage : ${item.displayName}")
                zip.putNextEntry(ZipEntry(item.mediaPath))
                file.inputStream().buffered().use { it.copyTo(zip, 64 * 1024) }
                zip.closeEntry()
                progress(((index + 1) * 100) / total)
            }
        }
    }

    fun open(context: Context, input: InputStream, progress: (Int) -> Unit): Pair<ProjectDocument, Map<String, File>> {
        val cacheRoot = File(context.filesDir, "project-media/opened/${UUID.randomUUID()}")
        cacheRoot.mkdirs()
        var manifestText: String? = null
        val extracted = mutableMapOf<String, File>()
        ZipInputStream(BufferedInputStream(input)).use { zip ->
            var entry: ZipEntry?
            var count = 0
            while (zip.nextEntry.also { entry = it } != null) {
                val e = entry!!
                val normalized = e.name.replace('\\', '/')
                require(!normalized.startsWith("/") && normalized.split("/").none { it == ".." }) {
                    "Archive refusée : chemin non sûr."
                }
                if (!e.isDirectory) {
                    if (normalized == "manifest.json") {
                        val out = ByteArrayOutputStream()
                        val buffer = ByteArray(16 * 1024)
                        var manifestBytes = 0
                        while (true) {
                            val n = zip.read(buffer)
                            if (n < 0) break
                            manifestBytes += n
                            require(manifestBytes <= 5 * 1024 * 1024) { "Manifeste trop volumineux." }
                            out.write(buffer, 0, n)
                        }
                        manifestText = out.toString("UTF-8")
                    } else if (normalized.startsWith("media/")) {
                        val dest = File(cacheRoot, normalized)
                        dest.parentFile?.mkdirs()
                        FileOutputStream(dest).buffered().use { zip.copyTo(it, 64 * 1024) }
                        extracted[normalized] = dest
                    }
                }
                count++
                progress((count % 100) + 1)
                zip.closeEntry()
            }
        }
        val manifest = manifestText ?: throw IOException("Le fichier ne contient pas manifest.json.")
        val doc = ProjectDocument.fromJson(JSONObject(manifest))
        require(doc.canvasWidth in 1..32768 && doc.canvasHeight in 1..32768) { "Dimensions de canevas invalides." }
        val ids = doc.items.map { it.id }
        require(ids.size == ids.toSet().size) { "Identifiants de calques dupliqués." }
        val groupIds = doc.groups.map { it.id }
        require(groupIds.size == groupIds.toSet().size && doc.items.all { it.groupId.isBlank() || it.groupId in groupIds } &&
            doc.groups.all { it.parentGroupId.isBlank() || it.parentGroupId in groupIds && it.parentGroupId != it.id }) {
            "Référence de dossier de calques invalide."
        }
        doc.groups.forEach { group ->
            val visited = mutableSetOf<String>()
            var cursor: ProjectGroup? = group
            while (cursor != null && cursor.parentGroupId.isNotBlank()) {
                val current = cursor
                require(visited.add(current.id)) { "Cycle détecté dans les groupes de calques." }
                val parentId = current.parentGroupId
                cursor = doc.groups.firstOrNull { it.id == parentId }
            }
        }
        doc.items.forEach { item ->
            val normalizedPath = item.mediaPath.replace('\\', '/')
            require(normalizedPath.startsWith("media/") && normalizedPath.split("/").none { it == ".." }) {
                "Chemin média non sûr : ${item.displayName}"
            }
            require(
                item.sourceItemIds.size == item.sourceItemIds.toSet().size &&
                item.sourceItemIds.none { it == item.id } &&
                item.sourceItemIds.all { ref -> doc.items.any { it.id == ref && it.sourceItemIds.isEmpty() } }
            ) {
                "Références de fusion invalides ou non aplaties : ${item.displayName}"
            }
            val file = extracted[item.mediaPath] ?: throw IOException("Média manquant : ${item.displayName}")
            if (sha256(file) != item.sha256) throw IOException("Vérification SHA-256 échouée : ${item.displayName}")
        }
        return doc to doc.items.associate { it.id to extracted.getValue(it.mediaPath) }
    }

    private fun readDimensions(file: File, kind: String): Pair<Int, Int> {
        if (kind == "image") {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            var width = bounds.outWidth
            var height = bounds.outHeight
            if (width <= 0 || height <= 0) return 0 to 0
            try {
                val orientation = ExifInterface(file.absolutePath).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                )
                if (orientation in setOf(
                        ExifInterface.ORIENTATION_ROTATE_90,
                        ExifInterface.ORIENTATION_ROTATE_270,
                        ExifInterface.ORIENTATION_TRANSPOSE,
                        ExifInterface.ORIENTATION_TRANSVERSE
                    )
                ) {
                    val swap = width
                    width = height
                    height = swap
                }
            } catch (_: Exception) { }
            return width to height
        }
        if (kind == "video") {
            val retriever = MediaMetadataRetriever()
            return try {
                retriever.setDataSource(file.absolutePath)
                var width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                var height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                if (rotation == 90 || rotation == 270) {
                    val swap = width
                    width = height
                    height = swap
                }
                width to height
            } catch (_: Exception) {
                0 to 0
            } finally {
                retriever.release()
            }
        }
        return 0 to 0
    }

    private fun queryName(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        } catch (_: Exception) { null }
    }
    private fun safeName(value: String) = value.replace(Regex("[^A-Za-z0-9._-]"), "_").take(100).ifBlank { "media.bin" }
}
