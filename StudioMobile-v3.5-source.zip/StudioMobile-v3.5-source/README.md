# Studio Mobile V3.5

Projet Android natif Kotlin. Package conservé : `org.studiomobile.v2`.

## Build
Le dépôt doit contenir `StudioMobile-v3.5-source.zip` à sa racine et le workflow `.github/workflows/build-android-v3.5.yml`. Le workflow extrait et compile exclusivement le contenu de cette archive.

## Documents
- `V3.5-CHANGELOG.md` : changements réels et limites connues.
- `V3.5-TESTS.md` : suivi des tests et retours terrain.
- `docs/ARCHITECTURE.md` : architecture héritée de V3.4 ; à compléter après intégration du pipeline vidéo.

Ne considérer aucune fonction comme validée sur appareil avant les essais terrain.
