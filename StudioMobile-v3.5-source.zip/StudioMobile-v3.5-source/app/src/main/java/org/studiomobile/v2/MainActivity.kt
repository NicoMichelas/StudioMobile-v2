package org.studiomobile.v2

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.*
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.*
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.exifinterface.media.ExifInterface
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.UUID
import org.json.JSONObject
import java.util.Collections
import java.util.concurrent.Executors
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min
import kotlin.math.atan2
import kotlin.math.hypot

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var canvasView: ProjectCanvasView
    private lateinit var canvasHost: FrameLayout
    private lateinit var playerView: PlayerView
    private lateinit var playerClipFrame: FrameLayout
    private lateinit var occlusionView: View
    // UI references are kept as activity fields because the panels are rebuilt
    // and refreshed independently of the canvas document.
    private lateinit var layerPanel: LinearLayout
    private lateinit var layerStrip: LinearLayout
    private lateinit var layerScrollView: ScrollView
    private lateinit var videoStrip: LinearLayout
    private lateinit var videoScrollView: ScrollView
    private lateinit var viewModeButton: Button
    private lateinit var editModeButton: Button
    private lateinit var layersTabButton: Button
    private lateinit var videosTabButton: Button
    private lateinit var secondaryToolbar: LinearLayout
    private lateinit var modeButtons: List<Button>
    private var groupActionButton: Button? = null
    private var activeMainMode: String? = null
    private var incrementEnabled = false
    private var sequencePlaying = false
    private var sequenceIds: List<String> = emptyList()
    private var sequenceIndex = 0
    private var sequenceListenerAttached = false
    private lateinit var sequenceTimeline: LinearLayout
    private lateinit var sequenceTimelineScroll: HorizontalScrollView
    private val undoStates = ArrayDeque<String>()
    private val redoStates = ArrayDeque<String>()
    private var gestureHistoryBefore: String? = null
    private var rightPanelTab: String = "layers"
    private var layerPanelOpen: Boolean = true
    private val expandedFusionIds = mutableSetOf<String>()
    private var lastViewTapId: String? = null
    private var lastViewTapAt: Long = 0L
    private var exoPlayer: ExoPlayer? = null
    private var playingItemId: String? = null
    private val videoPositions = mutableMapOf<String, Long>()
    private var suppressPauseCapture = false
    private val pauseReleaseHandler = Handler(Looper.getMainLooper())
    private var pauseReleaseRunnable: Runnable? = null
    private val doc = ProjectDocument()
    private val mediaFiles = mutableMapOf<String, File>()
    private val thumbnailExecutor = Executors.newSingleThreadExecutor { runnable -> Thread(runnable, "StudioMediaWorker").apply { isDaemon = true } }
    private val queuedThumbnailIds: MutableSet<String> = Collections.synchronizedSet(mutableSetOf())
    private var selectedId: String? = null
    private val selectedIds = linkedSetOf<String>()
    private var editMode = false
    private var commonPivot = true
    private var resizeActive = false
    private var resizeAxis = "both"
    private var resizeSignX = 1f
    private var resizeSignY = 1f
    private var resizeStartWidth = 0f
    private var resizeStartHeight = 0f
    private var resizeStartX = 0f
    private var resizeStartY = 0f
    private var rotationActive = false
    private var rotateStartAngle = 0f
    private var rotateStartRotation = 0f

    private val exportPng = registerForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null) exportCanvasPng(uri)
    }
    private enum class HtmlExportProfile(val label: String, val photoMaxSide: Int, val jpegQuality: Int) {
        ORIGINAL("Volumineux · originaux", Int.MAX_VALUE, 95),
        OPTIMIZED("Optimisé · photos 3 840 px", 3840, 90),
        VERY_OPTIMIZED("Très optimisé · photos 1 920 px", 1920, 84),
        ULTRA("Ultra optimisé · photos 1 280 px", 1280, 76)
    }
    private var pendingHtmlProfile: HtmlExportProfile = HtmlExportProfile.OPTIMIZED
    private val exportHtmlPackage = registerForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { uri ->
        if (uri != null) exportInteractivePackage(uri, pendingHtmlProfile)
    }

    private val importPicker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        if (isOpeningProject) { status.text = "Attends la fin de l'ouverture du projet avant d'importer."; return@registerForActivityResult }
        if (isImporting) { status.text = "Une importation est déjà en cours."; return@registerForActivityResult }
        isImporting = true
        val knownHashes = doc.items.map { it.sha256 }.toMutableSet()
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        status.text = "Préparation de ${uris.size} média(s)…"
        thread {
            val completed = mutableListOf<ProjectArchive.ImportedMedia>()
            val errors = mutableListOf<String>()
            uris.forEachIndexed { index, uri ->
                try {
                    val imported = ProjectArchive.importMedia(this, uri, contentResolver) { bytes ->
                        runOnUiThread { status.text = "Import ${index + 1}/${uris.size} · ${importedSafeName(uri)} · ${bytes / (1024 * 1024)} Mo" }
                    }
                    if (knownHashes.add(imported.item.sha256)) completed.add(imported)
                    else imported.cachedFile.delete()
                } catch (e: Exception) { errors.add("${uri.lastPathSegment}: ${e.message}") }
                runOnUiThread { status.text = "Importation · ${index + 1}/${uris.size}" }
            }
            runOnUiThread {
                completed.forEach { imported ->
                    val item = imported.item
                    val index = doc.items.size
                    item.x = (0.18f + (index % 4) * 0.2f).coerceIn(0.1f, 0.9f)
                    item.y = (0.22f + (index % 3) * 0.25f).coerceIn(0.1f, 0.9f)
                    val aspect = if (item.sourceWidth > 0 && item.sourceHeight > 0) item.sourceWidth.toFloat() / item.sourceHeight.toFloat() else 1f
                    item.width = 0.24f
                    item.height = item.width * doc.canvasWidth / (aspect * doc.canvasHeight)
                    if (item.height > 1.2f) { val shrink = 1.2f / item.height; item.width *= shrink; item.height = 1.2f }
                    else if (item.height < 0.02f) { val enlarge = 0.02f / item.height; item.width *= enlarge; item.height = 0.02f }
                    doc.items.add(item); mediaFiles[item.id] = imported.cachedFile
                }
                isImporting = false; progress.visibility = View.GONE
                selectedId = completed.lastOrNull()?.item?.id ?: doc.items.lastOrNull { it.visible }?.id
                selectedIds.clear(); selectedGroupId = null; selectedId?.let { selectedIds.add(it) }
                canvasView.invalidate(); refreshLayerStrip()
                status.text = if (errors.isEmpty()) "Import terminé · ${completed.size} nouveau(x) média(s) · doublons ignorés" else "Import terminé avec ${errors.size} erreur(s) : ${errors.first()}"
            }
        }
    }
    private var isImporting = false
    @Volatile private var isOpeningProject = false

    private val openProject = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uri = result.data?.data
        if (result.resultCode == Activity.RESULT_OK && uri != null) {
            val granted = result.data?.flags ?: 0
            val writable = (granted and Intent.FLAG_GRANT_WRITE_URI_PERMISSION) != 0
            try { contentResolver.takePersistableUriPermission(uri, granted and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)) } catch (_: Exception) { }
            openProjectUri(uri, writable)
        }
    }
    private val saveProject = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) saveProjectUri(uri)
    }

    private var currentProjectUri: Uri? = null
    private var currentProjectBaseName: String = ""
    private var layerPanelWidth = 148
    private var layerRowScale = 1f

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
    private lateinit var panelDock: LinearLayout
    private lateinit var panelHandle: TextView
    private lateinit var workspace: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(17, 25, 28)
        window.navigationBarColor = Color.rgb(17, 25, 28)
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(7), dp(8), dp(6))
            setBackgroundColor(Color.rgb(18, 27, 30))
        }
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(5), dp(3), dp(5), dp(3))
            background = android.graphics.drawable.GradientDrawable().apply { setColor(Color.rgb(29,42,46)); cornerRadius=dp(10).toFloat() }
        }
        val brand = TextView(this).apply {
            text = "Studio Mobile 3.4"; textSize = 13f; setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(240,242,237)); setPadding(dp(5),0,dp(4),0)
        }
        topBar.addView(brand, LinearLayout.LayoutParams(0,dp(42),1f))
        topBar.addView(makeButton("✨",101) { newProject() }.apply { contentDescription="Nouveau projet" })
        topBar.addView(makeButton("📂",102) { launchOpenProject() }.apply { contentDescription="Ouvrir un projet" })
        topBar.addView(makeButton("＋",103) { importPicker.launch(arrayOf("image/*","video/*")) }.apply { contentDescription="Importer" })
        topBar.addView(makeButton("💾",104) { showSaveOptions() }.apply { contentDescription="Enregistrer" })
        topBar.addView(makeButton("↗",105) { showExportOptions() }.apply { contentDescription="Exporter" })
        root.addView(topBar, LinearLayout.LayoutParams(-1,-2))

        val toolBar = LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(4),dp(3),dp(4),dp(3))
            background=android.graphics.drawable.GradientDrawable().apply { setColor(Color.rgb(29,42,46)); cornerRadius=dp(10).toFloat() }
        }
        val viewButton = makeButton("Vue",110) { activateMainMode("view") }
        val editButton = makeButton("Modifier",111) { activateMainMode("edit") }
        val videoButton = makeButton("Vidéo",112) { activateMainMode("video") }
        val previewButton = makeButton("Visualisation",113) { activateMainMode("preview") }
        modeButtons = listOf(viewButton,editButton,videoButton,previewButton)
        modeButtons.forEach { toolBar.addView(it, LinearLayout.LayoutParams(0,dp(44),1f).apply { marginEnd=dp(2) }) }
        toolBar.addView(makeButton("↶",114) { undo() }.apply { contentDescription="Annuler" })
        toolBar.addView(makeButton("↷",115) { redo() }.apply { contentDescription="Rétablir" })
        root.addView(toolBar,LinearLayout.LayoutParams(-1,-2))

        secondaryToolbar = LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(4),dp(3),dp(4),dp(3))
            background=android.graphics.drawable.GradientDrawable().apply { setColor(Color.rgb(29,42,46)); cornerRadius=dp(10).toFloat() }
            visibility=View.GONE
        }
        val secondaryScroll=HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled=false; addView(secondaryToolbar) }
        root.addView(secondaryScroll,LinearLayout.LayoutParams(-1,-2))
        sequenceTimeline=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(4),dp(3),dp(4),dp(3)) }
        sequenceTimelineScroll=HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled=true; visibility=View.GONE
            background=android.graphics.drawable.GradientDrawable().apply { setColor(Color.rgb(24,35,39)); cornerRadius=dp(8).toFloat() }
            addView(sequenceTimeline)
        }
        root.addView(sequenceTimelineScroll,LinearLayout.LayoutParams(-1,dp(76)))
        activeMainMode=null

        layerPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(29, 42, 46)); cornerRadius = dp(12).toFloat()
            }
        }
        val layerHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        layerHeader.addView(TextView(this).apply {
            text = "CALQUES"; textSize = 11f; letterSpacing = .1f
            setTypeface(null, Typeface.BOLD); setTextColor(Color.rgb(206, 220, 216)); setPadding(dp(5),dp(7),0,dp(7))
        }, LinearLayout.LayoutParams(0,-2,1f))
        layersTabButton = makeButton("▤ Calques", 31) { setRightPanelTab("layers") }
        videosTabButton = makeButton("▶ Vidéo", 32) { setRightPanelTab("videos") }
        layerHeader.addView(layersTabButton)
        layerHeader.addView(videosTabButton)
        layerHeader.addView(makeButton("A+", 30) { layerRowScale = (layerRowScale + .1f).coerceAtMost(1.6f); refreshLayerStrip() })
        layerPanel.addView(layerHeader)
        layerStrip = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(2), dp(4), dp(2), dp(4)) }
        layerScrollView = ScrollView(this).apply { isFillViewport = true; addView(layerStrip) }
        layerPanel.addView(layerScrollView, LinearLayout.LayoutParams(-1, 0, 1f))
        videoStrip = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(2), dp(4), dp(2), dp(4)) }
        videoScrollView = ScrollView(this).apply { isFillViewport = true; addView(videoStrip); visibility = View.GONE }
        layerPanel.addView(videoScrollView, LinearLayout.LayoutParams(-1, 0, 1f))

        panelHandle = TextView(this).apply {
            text = "▤"; gravity = Gravity.CENTER; textSize = 18f
            setTextColor(Color.rgb(231, 184, 111))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(38, 56, 60)); cornerRadius = dp(9).toFloat()
            }
            setOnClickListener { setLayerPanelOpen(!layerPanelOpen) }
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { panelDragStartX = event.rawX; panelDragStartWidth = layerPanelWidth; panelDragMoved = false; true }
                    MotionEvent.ACTION_MOVE -> {
                        if (layerPanelOpen && kotlin.math.abs(event.rawX - panelDragStartX) > dp(6)) {
                            panelDragMoved = true
                            val delta = ((panelDragStartX - event.rawX) / resources.displayMetrics.density).toInt()
                            layerPanelWidth = (panelDragStartWidth + delta).coerceIn(112, 280)
                            applyLayerPanelWidth()
                        }
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        if (!panelDragMoved && event.actionMasked == MotionEvent.ACTION_UP) setLayerPanelOpen(!layerPanelOpen)
                        true
                    }
                    else -> true
                }
            }
        }
        panelDock = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        panelDock.addView(panelHandle, LinearLayout.LayoutParams(dp(24), dp(72)).apply { marginEnd = dp(3) })
        panelDock.addView(layerPanel, LinearLayout.LayoutParams(dp(layerPanelWidth), -1))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(4)))
        status = TextView(this).apply {
            text = "Prêt · importe des médias pour composer"
            textSize = 11f; setTextColor(Color.rgb(145, 169, 169)); setPadding(dp(5), dp(5), dp(5), dp(5))
        }
        root.addView(status)

        canvasHost = FrameLayout(this).apply {
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(13, 19, 21)); cornerRadius = dp(12).toFloat()
            }
            clipToPadding = true; clipChildren = true
        }
        canvasView = ProjectCanvasView()
        canvasHost.addView(canvasView, FrameLayout.LayoutParams(-1, -1))
        playerClipFrame = FrameLayout(this).apply {
            clipChildren = true; clipToPadding = true; visibility = View.GONE
            setBackgroundColor(Color.TRANSPARENT)
        }
        playerView = layoutInflater.inflate(R.layout.player_view, playerClipFrame, false) as PlayerView
        playerView.apply {
            useController = true; controllerAutoShow = true; controllerShowTimeoutMs = 3000
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            setShutterBackgroundColor(Color.TRANSPARENT)
        }
        playerClipFrame.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        canvasHost.addView(playerClipFrame, FrameLayout.LayoutParams(1, 1))
        occlusionView = object : View(this) {
        override fun onDraw(canvas: Canvas) {
                super.onDraw(canvas)
                val id = playingItemId ?: return
                if (::canvasView.isInitialized) canvasView.drawLayersAbove(canvas, id)
            }
        }.apply { isClickable = false; setBackgroundColor(Color.TRANSPARENT) }
        canvasHost.addView(occlusionView, FrameLayout.LayoutParams(-1, -1))
        workspace = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        workspace.addView(canvasHost, LinearLayout.LayoutParams(0, -1, 1f))
        workspace.addView(panelDock, LinearLayout.LayoutParams(-2, -1))
        root.addView(workspace, LinearLayout.LayoutParams(-1, 0, 1f))
        canvasView.onViewportChanged = { updateInlinePlayerOverlay(); if (::occlusionView.isInitialized) occlusionView.invalidate() }
        setContentView(root)
        refreshModeButtons()
        setRightPanelTab("layers")
        refreshLayerStrip(); refreshVideoStrip()
    }

    private var panelDragStartX = 0f
    private var panelDragStartWidth = 164
    private var panelDragMoved = false
    private var selectedGroupId: String? = null
    private var cropMode = false
    private var cropStart: Pair<Float, Float>? = null
    private var cropOriginal: FloatArray? = null
    private var cropDragMode: String = ""
    private var cropLastX = 0f
    private var cropLastY = 0f
    private var cropStartX = 0f
    private var cropStartY = 0f

    private fun launchOpenProject() {
        val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type="*/*"
            putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("application/zip","application/octet-stream"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        openProject.launch(intent)
    }

    private fun newProject() {
        AlertDialog.Builder(this).setTitle("Nouveau projet")
            .setMessage("Enregistrer le projet actuel avant de le fermer ?")
            .setNeutralButton("Annuler",null)
            .setNegativeButton("Sans enregistrer") { _,_ -> resetToNewProject() }
            .setPositiveButton("Enregistrer") { _,_ ->
                showSaveOptions()
                status.text="Enregistre le projet, puis appuie à nouveau sur Nouveau projet pour en créer un autre."
            }.show()
    }
    private fun resetToNewProject() {
        stopSequencePlayback(); stopInlineVideo(); doc.items.clear(); doc.groups.clear(); mediaFiles.clear()
        doc.name="Sans titre"; doc.canvasWidth=1920; doc.canvasHeight=1080
        selectedId=null; selectedIds.clear(); selectedGroupId=null; currentProjectUri=null; currentProjectBaseName=""
        undoStates.clear(); redoStates.clear(); canvasView.resetViewport(); canvasView.invalidate(); refreshLayerStrip(); refreshVideoStrip()
        status.text="Nouveau projet"
    }

    private fun showExportOptions() {
        AlertDialog.Builder(this).setTitle("Exporter le projet")
            .setItems(arrayOf("HTML interactif", "Image PNG")) { _,which ->
                if(which==0) showHtmlProfileOptions()
                else exportPng.launch("${safeDocName(doc.name)}-apercu.png")
            }.setNegativeButton("Annuler",null).show()
    }

    private fun showHtmlProfileOptions() {
        val profiles = HtmlExportProfile.values()
        pendingHtmlProfile = HtmlExportProfile.OPTIMIZED
        AlertDialog.Builder(this)
            .setTitle("Profil HTML autonome")
            .setSingleChoiceItems(profiles.map { it.label }.toTypedArray(), 1) { dialog, which ->
                pendingHtmlProfile = profiles[which]
            }
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Continuer") { _, _ ->
                exportHtmlPackage.launch("${safeDocName(doc.name)}-studio-${pendingHtmlProfile.name.lowercase()}.html")
            }
            .show()
    }

    private fun activateMainMode(mode:String) {
        if(activeMainMode==mode) {
            activeMainMode=null; secondaryToolbar.removeAllViews(); secondaryToolbar.visibility=View.GONE
            if(mode=="edit") { editMode=false; canvasView.setEditMode(false) }
            if(mode=="preview") stopSequencePlayback()
            return
        }
        if(activeMainMode=="preview" && mode!="preview") stopSequencePlayback()
        activeMainMode=mode
        when(mode) {
            "view" -> { editMode=false; cropMode=false; canvasView.setEditMode(false); stopInlineVideo() }
            "edit" -> { editMode=true; canvasView.setEditMode(true); stopInlineVideo() }
            "video" -> { setRightPanelTab("videos"); setLayerPanelOpen(true) }
            "preview" -> { editMode=false; canvasView.setEditMode(false); startSequencePlayback() }
        }
        modeButtons.forEachIndexed { i,b ->
            val active=listOf("view","edit","video","preview")[i]==mode
            b.background=android.graphics.drawable.GradientDrawable().apply {
                setColor(if(active) Color.rgb(0,48,105) else Color.rgb(29,42,46)); cornerRadius=dp(9).toFloat()
                setStroke(dp(1),if(active) Color.rgb(39,104,190) else Color.rgb(65,83,85))
            }
            b.setTextColor(if(active) Color.rgb(112,174,255) else Color.rgb(239,243,238))
        }
        rebuildSecondaryToolbar(mode)
        status.text=when(mode){"view"->"Vue · navigation du canvas";"edit"->"Modifier · déplacement et transformation des calques";"video"->"Vidéo · outils de lecture et de réglage";else->"Visualisation"}
    }

    private fun addSecondary(label:String, action:()->Unit) { secondaryToolbar.addView(makeButton(label,120+secondaryToolbar.childCount,action)) }

    private fun rebuildSecondaryToolbar(mode:String) {
        secondaryToolbar.removeAllViews(); secondaryToolbar.visibility=View.VISIBLE
        when(mode) {
            "view" -> {
                addSecondary("Déplacer") { editMode=false; canvasView.setEditMode(false); status.text="Déplacement du canvas : glisse le fond." }
                addSecondary("Canvas ▧") { showCanvasDimensionsDialog() }
                addSecondary("Rotation") { canvasView.rotateViewport(90f) }
                addSecondary("Zoom +") { canvasView.adjustZoom(1.25f) }
                addSecondary("Recentrer") { canvasView.resetViewport() }
            }
            "edit" -> {
                addSecondary("Modifier le calque") { showLayerModifyMenu(itAnchor = secondaryToolbar.getChildAt(0)) }
                addSecondary(if(incrementEnabled) "Incr. ✓ · 5°" else "Incr. —") { incrementEnabled=!incrementEnabled; rebuildSecondaryToolbar("edit") }
                groupActionButton=makeButton(if(selectedGroupId!=null || selectedItems().any { it.groupId.isNotBlank() }) "Dégrouper" else "Grouper", 125) { showGroupMenu() }
                secondaryToolbar.addView(groupActionButton)
                addSecondary("Fusionner") { showMergeMenu() }
                addSecondary("Dupliquer/Suppr.") { showDuplicateDeleteMenu() }
            }
            "video" -> {
                addSecondary("Lire la suite") { activateMainMode("preview") }
                addSecondary("Début / Fin") { configureVideoTrim() }
                addSecondary("Volume") { configureVideoVolume() }
                addSecondary("Poster") { configureVideoPoster() }
            }
            "preview" -> {
                addSecondary("Play / Pause") { toggleSequencePlayback() }
                addSecondary("Stop") { stopSequencePlayback() }
                addSecondary("Recentrer") { canvasView.resetViewport() }
            }
        }
    }

    private fun showLayerModifyMenu(itAnchor:View?) {
        val anchor=itAnchor ?: return
        PopupMenu(this,anchor).apply {
            menu.add("Tourner 90°").setOnMenuItemClickListener { recordUndo(); selectedItems().forEach { it.rotation=(it.rotation+90f)%360f }; canvasView.invalidate(); true }
            menu.add("Symétrie horizontale").setOnMenuItemClickListener { recordUndo(); selectedItems().forEach { it.flipHorizontal=!it.flipHorizontal }; canvasView.invalidate(); true }
            menu.add("Symétrie verticale").setOnMenuItemClickListener { recordUndo(); selectedItems().forEach { it.flipVertical=!it.flipVertical }; canvasView.invalidate(); true }
            menu.add("Recadrer / redimensionner").setOnMenuItemClickListener { beginCropMode(); showCropDialog(); true }
            show()
        }
    }

    private fun selectedItems()=doc.items.filter { it.id in selectedIds || it.id==selectedId }

    private fun showGroupMenu() {
        val items=selectedItems(); val grouped=items.any { it.groupId.isNotBlank() }
        AlertDialog.Builder(this).setItems(if(grouped) arrayOf("Grouper la sélection", "Dégrouper") else arrayOf("Grouper")) { _,which ->
            recordUndo(); if(grouped && which==1) ungroupSelectedLayers() else groupSelectedLayers()
        }.show()
    }

    private fun showMergeMenu() {
        val hasFusion=selectedItems().any { it.sourceItemIds.isNotEmpty() }
        AlertDialog.Builder(this).setItems(if(hasFusion) arrayOf("Fusionner la sélection", "Défusionner") else arrayOf("Fusionner")) { _,which ->
            if(hasFusion && which==1) { recordUndo(); restoreSelectedSources() } else { recordUndo(); mergeSelectedLayers() }
        }.show()
    }

    private fun showDuplicateDeleteMenu() {
        AlertDialog.Builder(this).setItems(arrayOf("Dupliquer", "Supprimer")) { _,which ->
            recordUndo(); if(which==0) duplicateSelectedLayer() else deleteSelected(); refreshLayerStrip(); canvasView.invalidate()
        }.show()
    }

    private fun recordUndo() {
        val snap=doc.toJson().toString(); if(undoStates.lastOrNull()!=snap) undoStates.addLast(snap)
        while(undoStates.size>40) undoStates.removeFirst(); redoStates.clear()
    }
    private fun applyHistory(json:String) {
        val restored=ProjectDocument.fromJson(JSONObject(json))
        doc.name=restored.name; doc.canvasWidth=restored.canvasWidth; doc.canvasHeight=restored.canvasHeight
        doc.items.clear(); doc.items.addAll(restored.items); doc.groups.clear(); doc.groups.addAll(restored.groups)
        val keep=doc.items.map { it.id }.toSet(); mediaFiles.keys.retainAll(keep)
        selectedId=null; selectedIds.clear(); selectedGroupId=null; canvasView.invalidate(); refreshLayerStrip(); refreshVideoStrip()
    }
    private fun undo() {
        if(undoStates.isEmpty()) { status.text="Rien à annuler."; return }
        redoStates.addLast(doc.toJson().toString()); applyHistory(undoStates.removeLast()); status.text="Action annulée."
    }
    private fun redo() {
        if(redoStates.isEmpty()) { status.text="Rien à rétablir."; return }
        undoStates.addLast(doc.toJson().toString()); applyHistory(redoStates.removeLast()); status.text="Action rétablie."
    }

    private fun startSequencePlayback() {
        sequenceIds=doc.items.filter { it.visible && it.kind=="video" }.sortedBy { it.videoOrder }.map { it.id }
        if(sequenceIds.isEmpty()) { status.text="Aucune vidéo à lire."; return }
        sequenceIndex=0; sequencePlaying=true; sequenceTimelineScroll.visibility=View.VISIBLE
        refreshSequenceTimeline(); playSequenceAtCurrent()
    }
    private fun videoDurationMs(item:ProjectItem):Long {
        val file=mediaFiles[item.id] ?: return 1000L
        return try { val retriever=MediaMetadataRetriever(); retriever.setDataSource(file.absolutePath); val d=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 1000L; retriever.release(); d.coerceAtLeast(1000L) } catch (_:Exception) { 1000L }
    }
    private fun refreshSequenceTimeline() {
        if(!::sequenceTimeline.isInitialized) return
        sequenceTimeline.removeAllViews()
        val videos=sequenceIds.mapNotNull { id -> doc.items.firstOrNull { it.id==id } }
        val durations=videos.map { videoDurationMs(it) }; val total=durations.sum().coerceAtLeast(1L)
        videos.forEachIndexed { index,item ->
            val w=(dp(300)*durations[index].toFloat()/total).toInt().coerceIn(dp(74),dp(300))
            val frame=FrameLayout(this).apply {
                background=android.graphics.drawable.GradientDrawable().apply { setColor(if(index==sequenceIndex) Color.rgb(55,116,106) else Color.rgb(42,58,62)); cornerRadius=dp(6).toFloat(); setStroke(dp(1),Color.rgb(85,112,112)) }
                setOnClickListener { sequenceIndex=index; if(sequencePlaying) playSequenceAtCurrent() }
            }
            val poster=ImageView(this).apply { scaleType=ImageView.ScaleType.CENTER_CROP; ThumbnailCache.get(item.id)?.let { setImageBitmap(it) } }
            frame.addView(poster,FrameLayout.LayoutParams(-1,-1))
            frame.addView(TextView(this).apply { text="${index+1} · ${item.displayName}"; textSize=9f; setTextColor(Color.WHITE); setPadding(dp(4),dp(2),dp(4),dp(2)); setBackgroundColor(0x99000000.toInt()); maxLines=1 },FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM))
            sequenceTimeline.addView(frame,LinearLayout.LayoutParams(w,dp(62)).apply { marginEnd=dp(4) })
        }
    }
    private fun playSequenceAtCurrent() {
        if(!sequencePlaying || sequenceIndex !in sequenceIds.indices) { stopSequencePlayback(); return }
        val id=sequenceIds[sequenceIndex]; val item=doc.items.firstOrNull { it.id==id } ?: return
        selectedId=id; selectedIds.clear(); selectedIds.add(id); selectedGroupId=null
        refreshSequenceTimeline()
        val file=mediaFiles[id] ?: return
        val player=exoPlayer ?: ExoPlayer.Builder(this).build().also { created -> exoPlayer=created; playerView.player=created }
        if(!sequenceListenerAttached) {
            player.addListener(object:Player.Listener {
                override fun onPlaybackStateChanged(state:Int) { if(state==Player.STATE_ENDED && sequencePlaying) { sequenceIndex++; playSequenceAtCurrent() } }
            })
            sequenceListenerAttached=true
        }
        playingItemId=id
        playerClipFrame.visibility=View.VISIBLE; updateInlinePlayerOverlay(); player.volume=item.volume
        val clipping=MediaItem.ClippingConfiguration.Builder().setStartPositionMs(item.trimStartMs.coerceAtLeast(0L)).apply {
            if(item.trimEndMs>item.trimStartMs) setEndPositionMs(item.trimEndMs)
        }.build()
        player.setMediaItem(MediaItem.Builder().setUri(Uri.fromFile(file)).setClippingConfiguration(clipping).build())
        player.prepare(); player.playWhenReady=true; refreshLayerStrip(); canvasView.invalidate()
    }
    private fun toggleSequencePlayback() { if(!sequencePlaying) startSequencePlayback() else if(exoPlayer?.isPlaying==true) exoPlayer?.pause() else exoPlayer?.play() }
    private fun stopSequencePlayback() { sequencePlaying=false; sequenceIds=emptyList(); if(::sequenceTimelineScroll.isInitialized) sequenceTimelineScroll.visibility=View.GONE; stopInlineVideo(); canvasView.invalidate() }

    private fun configureVideoTrim() {
        val item=doc.items.firstOrNull { it.id==selectedId && it.kind=="video" } ?: run { status.text="Sélectionne une vidéo dans le panneau Vidéo."; return }
        val start=EditText(this).apply { inputType=8194; setText((item.trimStartMs/1000.0).toString()); hint="Début (secondes)" }
        val end=EditText(this).apply { inputType=8194; setText((item.trimEndMs/1000.0).toString()); hint="Fin (secondes, 0 = durée complète)" }
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(8),dp(18),0); addView(start); addView(end) }
        AlertDialog.Builder(this).setTitle("Début / Fin de lecture").setView(box).setNegativeButton("Annuler",null).setPositiveButton("Appliquer") { _,_ ->
            val a=(start.text.toString().toDoubleOrNull()?:0.0).coerceAtLeast(0.0)*1000
            val b=(end.text.toString().toDoubleOrNull()?:0.0).coerceAtLeast(0.0)*1000
            if(b>0 && b<=a) { status.text="La fin doit être après le début."; return@setPositiveButton }
            recordUndo(); item.trimStartMs=a.toLong(); item.trimEndMs=b.toLong(); canvasView.invalidate(); status.text="Portion de lecture mise à jour · source conservée."
        }.show()
    }

    private fun refreshModeButtons() {
        if (!::viewModeButton.isInitialized || !::editModeButton.isInitialized) return
        fun style(button: Button, active: Boolean) {
            button.background = android.graphics.drawable.GradientDrawable().apply {
                setColor(if (active) Color.rgb(55, 116, 106) else Color.rgb(43, 61, 65))
                cornerRadius = dp(8).toFloat(); setStroke(dp(1), Color.rgb(65, 83, 85))
            }
        }
        style(viewModeButton, !editMode); style(editModeButton, editMode)
    }

    private fun setRightPanelTab(tab: String) {
        rightPanelTab = tab
        layerScrollView.visibility = if (tab == "layers") View.VISIBLE else View.GONE
        videoScrollView.visibility = if (tab == "videos") View.VISIBLE else View.GONE
        fun styleTab(button: Button, active: Boolean) {
            button.background = android.graphics.drawable.GradientDrawable().apply {
                setColor(if (active) Color.rgb(55, 116, 106) else Color.rgb(43, 61, 65))
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), if (active) Color.rgb(117, 197, 180) else Color.rgb(65, 83, 85))
            }
        }
        if (::layersTabButton.isInitialized) styleTab(layersTabButton, tab == "layers")
        if (::videosTabButton.isInitialized) styleTab(videosTabButton, tab == "videos")
        refreshVideoStrip()
    }

    private fun refreshVideoStrip() {
        if (!::videoStrip.isInitialized) return
        videoStrip.removeAllViews()
        val videos = doc.items.filter { it.kind == "video" }.sortedBy { it.videoOrder }
        if (videos.isEmpty()) {
            videoStrip.addView(TextView(this).apply { text = "Aucune vidéo"; textSize = 10f; setTextColor(Color.LTGRAY); setPadding(dp(8),dp(12),dp(8),dp(12)) })
            return
        }
        videos.forEachIndexed { index, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(6),dp(5),dp(6),dp(5))
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(if (item.id == selectedId) Color.rgb(65,88,80) else Color.rgb(36,52,56)); cornerRadius = dp(7).toFloat()
                }
                tag = item.id
            }
            val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            head.addView(TextView(this).apply {
                text = "${index+1}.  ${item.displayName}"; textSize = 10f; maxLines = 2; setTextColor(Color.WHITE)
                setOnClickListener { selectedId=item.id; selectedIds.clear(); selectedIds.add(item.id); selectedGroupId=null; canvasView.invalidate(); updateInlinePlayerOverlay(); refreshLayerStrip(); refreshVideoStrip() }
            }, LinearLayout.LayoutParams(0, dp(34), 1f))
            head.addView(makeButton("↑", 33) { moveVideoOrder(item.id, -1) })
            head.addView(makeButton("↓", 34) { moveVideoOrder(item.id, 1) })
            row.addView(head)
            val volumeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            volumeRow.addView(TextView(this).apply { text = "Vol."; textSize = 9f; setTextColor(Color.LTGRAY) })
            volumeRow.addView(SeekBar(this).apply {
                max = 100; progress = (item.volume*100).toInt()
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) { item.volume = progress/100f; if (playingItemId == item.id) exoPlayer?.volume = item.volume } }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar?) { status.text = "Volume de ${item.displayName} : ${(item.volume*100).toInt()} %" }
                })
            }, LinearLayout.LayoutParams(0, dp(32), 1f))
            volumeRow.addView(makeButton("Poster", 35) { selectedId=item.id; selectedIds.clear(); selectedIds.add(item.id); configureVideoPoster() })
            row.addView(volumeRow)
            videoStrip.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
        }
    }

    private fun moveVideoOrder(itemId: String, direction: Int) {
        recordUndo()
        val videos = doc.items.filter { it.kind == "video" }.sortedBy { it.videoOrder }.toMutableList()
        val index = videos.indexOfFirst { it.id == itemId }
        val target = (index + direction).coerceIn(0, videos.lastIndex)
        if (index >= 0 && target != index) {
            val item = videos.removeAt(index); videos.add(target, item)
            videos.forEachIndexed { i, video -> video.videoOrder = i }
            refreshVideoStrip(); status.text = "Ordre de lecture des vidéos mis à jour."
        }
    }

    private fun setLayerPanelOpen(open: Boolean) {
        layerPanelOpen = open
        layerPanel.visibility = if (open) View.VISIBLE else View.GONE
        val lp = panelDock.layoutParams as? LinearLayout.LayoutParams
        lp?.width = if (open) dp(layerPanelWidth + 27) else dp(24)
        if (lp != null) panelDock.layoutParams = lp
        panelHandle.text = if (open) "▤" else "▥"
        workspace.requestLayout()
    }

    private fun applyLayerPanelWidth() {
        val lp = layerPanel.layoutParams as LinearLayout.LayoutParams
        lp.width = dp(layerPanelWidth)
        layerPanel.layoutParams = lp
        val dock = panelDock.layoutParams as LinearLayout.LayoutParams
        dock.width = dp(layerPanelWidth + 27)
        panelDock.layoutParams = dock
    }

    private fun showSaveOptions() {
        if (isImporting || isOpeningProject) { status.text = "Attends la fin de l'importation ou de l'ouverture avant d'enregistrer."; return }
        val options = mutableListOf<String>()
        if (currentProjectUri != null) options.add("Écraser la version actuelle")
        options.add("Enregistrer une version suivante (X+1)")
        options.add("Enregistrer sous…")
        AlertDialog.Builder(this).setTitle("Enregistrer le projet")
            .setItems(options.toTypedArray()) { _, which ->
                val choice = options[which]
                when {
                    choice.startsWith("Écraser") -> currentProjectUri?.let { saveProjectUri(it) }
                    choice.startsWith("Enregistrer une version") -> {
                        val base = currentProjectBaseName.ifBlank { safeDocName(doc.name) }
                        val current = Regex("(?i)_v(\\d+)$").find(base)?.groupValues?.getOrNull(1)?.toIntOrNull()
                            ?: if (currentProjectBaseName.isBlank()) 0 else 1
                        saveProject.launch("${base.replace(Regex("(?i)_v\\d+$"), "")}_v${current + 1}.studio")
                    }
                    else -> {
                        val input = EditText(this).apply { setText(currentProjectBaseName.ifBlank { safeDocName(doc.name) }); hint = "Nom du projet" }
                        AlertDialog.Builder(this).setTitle("Enregistrer sous") .setView(input)
                            .setNegativeButton("Annuler", null).setPositiveButton("Continuer") { _, _ ->
                                val name = safeDocName(input.text.toString())
                                saveProject.launch("$name.studio")
                            }.show()
                    }
                }
            }.setNegativeButton("Annuler", null).show()
    }

    private fun verifyMediaIntegrity() {
        if (doc.items.isEmpty()) { status.text = "Projet vide : rien à vérifier."; return }
        val snapshot = doc.items.map { it.copy(sourceItemIds = it.sourceItemIds.toMutableList()) }
        val files = mediaFiles.toMap()
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        status.text = "Vérification SHA-256 des médias…"
        thread {
            val errors = mutableListOf<String>()
            snapshot.forEachIndexed { index, item ->
                val file = files[item.id]
                if (file == null || !file.isFile) errors.add("Média absent : ${item.displayName}")
                else if (ProjectArchive.sha256(file) != item.sha256) errors.add("Empreinte différente : ${item.displayName}")
                runOnUiThread { status.text = "SHA-256 · ${index + 1}/${snapshot.size}" }
            }
            runOnUiThread {
                progress.visibility = View.GONE
                status.text = if (errors.isEmpty()) "Vérification réussie · ${snapshot.size} média(s) intègres." else "Vérification échouée · ${errors.size} problème(s) : ${errors.first()}"
            }
        }
    }

    private fun duplicateSelectedLayer() {
        recordUndo()
        val source = doc.items.firstOrNull { it.id == selectedId && it.visible }
        if (source == null) { status.text = "Sélectionne un calque à dupliquer."; return }
        val sourceSnapshot = source.copy(sourceItemIds = source.sourceItemIds.toMutableList())
        val sourceFile = mediaFiles[source.id]
        if (sourceFile == null || !sourceFile.isFile) { status.text = "Fichier source introuvable."; return }
        val id = UUID.randomUUID().toString()
        val copyFile = File(filesDir, "project-media/imports/${id}_${sourceFile.name}")
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        status.text = "Duplication de ${source.displayName}…"
        thread {
            try {
                copyFile.parentFile?.mkdirs(); sourceFile.copyTo(copyFile, overwrite = false)
                val copy = sourceSnapshot.copy(
                    id = id,
                    displayName = "${sourceSnapshot.displayName} — copie",
                    mediaPath = "media/${id}_${sourceSnapshot.displayName.replace(Regex("[^A-Za-z0-9._-]"), "_")}",
                    sha256 = ProjectArchive.sha256(copyFile),
                    x = (sourceSnapshot.x + .025f).coerceAtMost(1.4f),
                    y = (sourceSnapshot.y + .025f).coerceAtMost(1.4f),
                    sourceItemIds = sourceSnapshot.sourceItemIds.toMutableList()
                )
                runOnUiThread {
                    doc.items.add(doc.items.indexOfFirst { it.id == sourceSnapshot.id }.coerceAtLeast(0), copy)
                    mediaFiles[id] = copyFile
                    selectedId = id; selectedIds.clear(); selectedIds.add(id); selectedGroupId = null
                    progress.visibility = View.GONE; canvasView.invalidate(); refreshLayerStrip()
                    status.text = "Calque dupliqué."
                }
            } catch (e: Exception) {
                copyFile.delete()
                runOnUiThread { progress.visibility = View.GONE; status.text = "Duplication impossible : ${e.message}" }
            }
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        canvasHost.post { canvasView.requestLayout(); canvasView.invalidate(); updateInlinePlayerOverlay(); workspace.requestLayout() }
    }

    private fun refreshLayerStrip() {
        groupActionButton?.text = if(selectedGroupId!=null || selectedItems().any { it.groupId.isNotBlank() }) "Dégrouper" else "Grouper"
        if (!::layerStrip.isInitialized) return
        layerStrip.removeAllViews()
        if (doc.items.isEmpty() && doc.groups.isEmpty()) {
            layerStrip.addView(TextView(this).apply { text = "Aucun calque"; textSize = 11f; setTextColor(Color.LTGRAY); setPadding(8,10,8,10) })
            updatePivotButtonVisibility(); return
        }
        val sourceOwner = doc.items.filter { it.visible && it.sourceItemIds.isNotEmpty() }
            .flatMap { composite -> composite.sourceItemIds.map { it to composite.id } }.toMap()

        fun descendants(groupId: String): Set<String> {
            val childGroups = doc.groups.filter { it.parentGroupId == groupId }.map { it.id }
            return doc.items.filter { it.groupId == groupId }.map { it.id }.toSet() + childGroups.flatMap { descendants(it) }
        }
        fun styleRow(row: View, selected: Boolean = false) {
            row.setBackgroundColor(if (selected) Color.rgb(69, 92, 82) else Color.rgb(36, 52, 56))
        }
        fun addItemRow(item: ProjectItem, indent: Int) {
            val selected = item.id in selectedIds || item.id == selectedId
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(indent, dp(2), dp(3), dp(2)); tag = "item:${item.id}"
                styleRow(this, selected)
            }
            val check = CheckBox(this).apply {
                buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(219, 174, 104))
                isChecked = item.id in selectedIds
                setOnClickListener {
                    if (isChecked) selectedIds.add(item.id) else selectedIds.remove(item.id)
                    selectedId = item.id; canvasView.invalidate(); refreshLayerStrip()
                }
                setOnLongClickListener { startLayerDrag(it, item.id) }
            }
            row.addView(check, LinearLayout.LayoutParams(dp(25), dp((30 * layerRowScale).toInt().coerceAtLeast(24))))
            val label = TextView(this).apply {
                text = "${if (!item.visible) "◌ " else ""}${if (item.kind == "video") "▶" else "▧"}  ${item.displayName}"
                textSize = 10f * layerRowScale; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
                gravity = Gravity.CENTER_VERTICAL; setPadding(dp(3), dp(5), dp(3), dp(5))
                setTextColor(if (!item.visible) Color.rgb(135,145,148) else Color.rgb(236,241,235))
                setOnClickListener {
                    selectedId = item.id; selectedGroupId = null; selectedIds.clear(); selectedIds.add(item.id)
                    canvasView.invalidate(); updateInlinePlayerOverlay(); refreshLayerStrip()
                }
                setOnLongClickListener { startLayerDrag(it, item.id) }
            }
            row.addView(label, LinearLayout.LayoutParams(0, dp((38 * layerRowScale).toInt().coerceAtLeast(30)), 1f))
            row.setOnLongClickListener {
                val clip = android.content.ClipData.newPlainText("studio-layer", item.id)
                it.startDragAndDrop(clip, View.DragShadowBuilder(it), null, 0)
                true
            }
            row.setOnDragListener { target, event ->
                when (event.action) {
                    DragEvent.ACTION_DRAG_ENTERED -> { target.alpha = .65f; true }
                    DragEvent.ACTION_DRAG_EXITED -> { target.alpha = 1f; true }
                    DragEvent.ACTION_DROP -> {
                        target.alpha = 1f
                        val raw = event.clipData.getItemAt(0).text.toString()
                        val dragged = doc.items.firstOrNull { it.id == raw }
                        if (raw.startsWith("group:")) reorderGroupRelativeToItem(raw.removePrefix("group:"), item.id)
                        else if (dragged != null && dragged.id != item.id) {
                            if (item.sourceItemIds.isNotEmpty()) {
                                selectedIds.clear(); selectedIds.add(item.id); selectedIds.add(dragged.id)
                                selectedId = item.id; mergeSelectedLayers()
                            } else reorderLayerBefore(dragged.id, item.id)
                        }
                        true
                    }
                    DragEvent.ACTION_DRAG_ENDED -> { target.alpha = 1f; true }
                    else -> true
                }
            }
            layerStrip.addView(row)
        }
        fun addGroup(group: ProjectGroup, depth: Int) {
            val members = doc.items.filter { it.groupId == group.id }
            val childGroups = doc.groups.filter { it.parentGroupId == group.id }
            val allIds = descendants(group.id)
            val isSelected = selectedGroupId == group.id
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(4 + depth * 10), dp(4), dp(3), dp(4)); tag = "group:${group.id}"
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(if (isSelected) Color.rgb(67, 91, 82) else Color.rgb(43, 61, 65)); cornerRadius = dp(6).toFloat()
                }
            }
            row.addView(TextView(this).apply {
                text = if (group.collapsed) "▸" else "▾"; textSize = 16f; setTextColor(Color.rgb(235, 194, 128)); gravity = Gravity.CENTER
                setOnClickListener { group.collapsed = !group.collapsed; refreshLayerStrip() }
            }, LinearLayout.LayoutParams(dp(26), dp(32)))
            row.addView(TextView(this).apply {
                text = "▰  ${group.name} (${allIds.size})"; textSize = 10.5f; setTextColor(Color.WHITE); gravity = Gravity.CENTER_VERTICAL
                setOnClickListener {
                    selectedGroupId = group.id; selectedIds.clear(); selectedIds.addAll(allIds)
                    selectedId = doc.items.lastOrNull { it.id in allIds && it.visible }?.id
                    canvasView.invalidate(); updateInlinePlayerOverlay(); refreshLayerStrip()
                }
                setOnLongClickListener { startLayerDrag(it, "group:${group.id}") }
            }, LinearLayout.LayoutParams(0, dp(32), 1f))
            row.setOnLongClickListener {
                val clip = android.content.ClipData.newPlainText("studio-layer", "group:${group.id}")
                it.startDragAndDrop(clip, View.DragShadowBuilder(it), null, 0); true
            }
            row.setOnDragListener { target, event ->
                when (event.action) {
                    DragEvent.ACTION_DRAG_ENTERED -> { target.alpha = .65f; true }
                    DragEvent.ACTION_DRAG_EXITED -> { target.alpha = 1f; true }
                    DragEvent.ACTION_DROP -> {
                        target.alpha = 1f
                        val raw = event.clipData.getItemAt(0).text.toString()
                        if (raw.startsWith("group:")) moveGroupIntoGroup(raw.removePrefix("group:"), group.id)
                        else moveLayerIntoGroup(raw, group.id)
                        true
                    }
                    DragEvent.ACTION_DRAG_ENDED -> { target.alpha = 1f; true }
                    else -> true
                }
            }
            layerStrip.addView(row)
            if (!group.collapsed) {
                members.filter { it.id !in sourceOwner }.sortedByDescending { doc.items.indexOf(it) }.forEach { addItemRow(it, dp(8 + depth * 10)) }
                childGroups.sortedByDescending { child -> descendantGroupIds(child.id).map { id -> doc.items.indexOfFirst { it.id == id } }.maxOrNull() ?: -1 }.forEach { addGroup(it, depth + 1) }
            }
        }
        val rootRows = mutableListOf<Pair<Int, () -> Unit>>()
        doc.groups.filter { it.parentGroupId.isBlank() }.forEach { group ->
            val z = descendantGroupIds(group.id).mapNotNull { id -> doc.items.indexOfFirst { it.id == id }.takeIf { it >= 0 } }.maxOrNull() ?: -1
            rootRows.add(z to { addGroup(group, 0) })
        }
        doc.items.forEachIndexed { index, item ->
            if (item.groupId.isNotBlank() || item.id in sourceOwner) return@forEachIndexed
            if (item.sourceItemIds.isNotEmpty()) {
                rootRows.add(index to {
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                        setPadding(dp(4), dp(3), dp(3), dp(3)); tag = "item:${item.id}"
                        background = android.graphics.drawable.GradientDrawable().apply { setColor(if (item.id in selectedIds) Color.rgb(67,91,82) else Color.rgb(40,56,60)); cornerRadius = dp(6).toFloat() }
                    }
                    row.addView(TextView(this).apply {
                        text = if (item.id in expandedFusionIds) "▾" else "▸"; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                        setOnClickListener { if (!expandedFusionIds.add(item.id)) expandedFusionIds.remove(item.id); refreshLayerStrip() }
                    }, LinearLayout.LayoutParams(dp(24), dp(34)))
                    row.addView(TextView(this).apply {
                        text = "▧  ${item.displayName} (${item.sourceItemIds.size})"; textSize = 10.5f; setTextColor(Color.WHITE); gravity = Gravity.CENTER_VERTICAL
                        setOnClickListener { selectedId=item.id; selectedGroupId=null; selectedIds.clear(); selectedIds.add(item.id); canvasView.invalidate(); refreshLayerStrip() }
                        setOnLongClickListener { startLayerDrag(it, item.id) }
                    }, LinearLayout.LayoutParams(0, dp(34), 1f))
                    row.setOnLongClickListener { val clip = android.content.ClipData.newPlainText("studio-layer", item.id); it.startDragAndDrop(clip, View.DragShadowBuilder(it), null, 0); true }
                    row.setOnDragListener { target, event ->
                        if (event.action == DragEvent.ACTION_DROP) {
                            val raw = event.clipData.getItemAt(0).text.toString()
                            val dragged = doc.items.firstOrNull { it.id == raw }
                            if (raw.startsWith("group:")) reorderGroupRelativeToItem(raw.removePrefix("group:"), item.id)
                            else if (dragged != null && dragged.id != item.id) { selectedIds.clear(); selectedIds.add(item.id); selectedIds.add(dragged.id); selectedId=item.id; mergeSelectedLayers() }
                            true
                        } else true
                    }
                    layerStrip.addView(row)
                    if (item.id in expandedFusionIds) item.sourceItemIds.mapNotNull { id -> doc.items.firstOrNull { it.id == id } }.forEach { addItemRow(it, dp(20)) }
                })
            } else rootRows.add(index to { addItemRow(item, dp(2)) })
        }
        rootRows.sortedByDescending { it.first }.forEach { it.second.invoke() }
        updatePivotButtonVisibility(); refreshVideoStrip()
    }

    private fun startLayerDrag(view: View, payload: String): Boolean {
        val clip = android.content.ClipData.newPlainText("studio-layer", payload)
        return view.startDragAndDrop(clip, View.DragShadowBuilder(view), null, 0)
    }

    private fun reorderLayerBefore(draggedId: String, targetId: String) {
        val from = doc.items.indexOfFirst { it.id == draggedId }; val to = doc.items.indexOfFirst { it.id == targetId }
        if (from < 0 || to < 0 || from == to) return
        val item = doc.items[from]
        val target = doc.items[to]
        val oldGroupId = item.groupId
        item.groupId = target.groupId // dropping onto a grouped row joins that group; dropping onto root exits its old group
        val moved = doc.items.removeAt(from)
        val targetAfterRemoval = doc.items.indexOfFirst { it.id == targetId }
        doc.items.add((targetAfterRemoval + 1).coerceIn(0, doc.items.size), moved)
        if (oldGroupId.isNotBlank() && oldGroupId != item.groupId) pruneEmptyGroups()
        selectedId = draggedId; selectedIds.clear(); selectedIds.add(draggedId); selectedGroupId = null
        canvasView.invalidate(); refreshLayerStrip(); status.text = "Ordre des calques modifié · calque placé au-dessus de la cible."
    }

    private fun moveLayerIntoGroup(itemId: String, groupId: String) {
        val item = doc.items.firstOrNull { it.id == itemId } ?: return
        if (descendantGroupIds(groupId).contains(itemId)) return
        val oldGroupId = item.groupId
        item.groupId = groupId
        if (oldGroupId.isNotBlank() && oldGroupId != groupId) pruneEmptyGroups()
        selectedGroupId = groupId
        selectedIds.clear(); selectedIds.addAll(descendantGroupIds(groupId)); selectedId = item.id
        refreshLayerStrip(); canvasView.invalidate(); status.text = "Calque déplacé dans le groupe."
    }

    private fun pruneEmptyGroups() {
        var changed = true
        while (changed) {
            val empty = doc.groups.filter { group -> doc.items.none { it.groupId == group.id } && doc.groups.none { it.parentGroupId == group.id } }
            changed = empty.isNotEmpty()
            doc.groups.removeAll(empty.toSet())
        }
    }

    private fun descendantGroupIds(groupId: String): Set<String> {
        val childGroups = doc.groups.filter { it.parentGroupId == groupId }.map { it.id }
        return doc.items.filter { it.groupId == groupId }.map { it.id }.toSet() + childGroups.flatMap { descendantGroupIds(it) }
    }

    private fun reorderGroupRelativeToItem(groupId: String, targetItemId: String) {
        val group = doc.groups.firstOrNull { it.id == groupId } ?: return
        val target = doc.items.firstOrNull { it.id == targetItemId } ?: return
        val descendants = descendantGroupIds(groupId)
        if (targetItemId in descendants || target.groupId == groupId || descendants.contains(target.groupId)) return
        val blockIds = doc.items.filter { it.id in descendants }.map { it.id }.toSet()
        if (blockIds.isEmpty()) return
        val block = doc.items.filter { it.id in blockIds }
        val oldParent = group.parentGroupId
        group.parentGroupId = target.groupId
        doc.items.removeAll { it.id in blockIds }
        val targetIndex = doc.items.indexOfFirst { it.id == targetItemId }
        doc.items.addAll((targetIndex + 1).coerceIn(0, doc.items.size), block)
        if (oldParent.isNotBlank() && oldParent != group.parentGroupId) pruneEmptyGroups()
        selectedGroupId = groupId; selectedIds.clear(); selectedIds.addAll(descendantGroupIds(groupId))
        selectedId = block.lastOrNull()?.id
        refreshLayerStrip(); canvasView.invalidate()
        status.text = "Groupe déplacé dans la pile des calques."
    }

    private fun combineGroupAndLayer(groupId: String, itemId: String) {
        val group = doc.groups.firstOrNull { it.id == groupId } ?: return
        val item = doc.items.firstOrNull { it.id == itemId && it.visible } ?: return
        val parentId = UUID.randomUUID().toString()
        doc.groups.add(ProjectGroup(parentId, "Groupe ${doc.groups.size + 1}"))
        group.parentGroupId = parentId
        item.groupId = parentId
        pruneEmptyGroups()
        selectedGroupId = parentId; selectedIds.clear(); selectedIds.addAll(descendantGroupIds(parentId))
        selectedId = item.id; refreshLayerStrip(); canvasView.invalidate()
        status.text = "Groupe et calque réunis dans un nouveau dossier, sans supprimer le groupe d'origine."
    }

    private fun moveGroupIntoGroup(childId: String, parentId: String) {
        if (childId == parentId || descendantGroupIds(childId).contains(parentId)) return
        val child = doc.groups.firstOrNull { it.id == childId } ?: return
        child.parentGroupId = parentId
        pruneEmptyGroups()
        selectedGroupId = parentId; selectedIds.clear(); selectedIds.addAll(descendantGroupIds(parentId))
        refreshLayerStrip(); status.text = "Groupe imbriqué dans le dossier cible."
    }

    private fun updatePivotButtonVisibility() { /* multi-pivot reserved for a later gesture refinement */ }

    private fun groupSelectedLayers() {
        recordUndo()
        val selectedGroup = selectedGroupId?.let { id -> doc.groups.firstOrNull { it.id == id } }
        val selectedGroupDescendants = selectedGroup?.let { descendantGroupIds(it.id) } ?: emptySet()
        val selectedItems = doc.items.filter { it.id in selectedIds && it.visible && it.id !in selectedGroupDescendants }
        if (selectedItems.isEmpty() && selectedGroup == null) { status.text = "Sélectionne plusieurs calques ou un groupe et un calque."; return }
        val id = UUID.randomUUID().toString()
        val newGroup = ProjectGroup(id, "Groupe ${doc.groups.size + 1}")
        doc.groups.add(newGroup)
        selectedGroup?.parentGroupId = id
        selectedItems.forEach { it.groupId = id }
        doc.groups.removeAll { candidate -> candidate.id != id && doc.items.none { item -> item.groupId == candidate.id } && doc.groups.none { child -> child.parentGroupId == candidate.id } }
        selectedGroupId = id; selectedIds.clear(); selectedIds.addAll(descendantGroupIds(id))
        selectedId = doc.items.lastOrNull { it.id in selectedIds && it.visible }?.id
        refreshLayerStrip(); canvasView.invalidate(); status.text = "Nouveau groupe créé sans aplatir les groupes existants."
    }

    private fun ungroupSelectedLayers() {
        recordUndo()
        if (selectedGroupId != null) {
            val group = doc.groups.firstOrNull { it.id == selectedGroupId } ?: run { selectedGroupId = null; return }
            val parentId = group.parentGroupId
            doc.items.filter { it.groupId == group.id }.forEach { it.groupId = parentId }
            doc.groups.filter { it.parentGroupId == group.id }.forEach { it.parentGroupId = parentId }
            doc.groups.remove(group)
            selectedGroupId = parentId.takeIf { it.isNotBlank() }
            selectedIds.clear()
            if (selectedGroupId != null) selectedIds.addAll(descendantGroupIds(selectedGroupId!!))
            else doc.items.filter { it.groupId.isBlank() && it.visible }.takeLast(1).forEach { selectedIds.add(it.id); selectedId = it.id }
            pruneEmptyGroups(); refreshLayerStrip(); canvasView.invalidate()
            status.text = "Groupe dissous · calques et sous-groupes conservés individuellement."
            return
        }
        val selectedItems = doc.items.filter { it.id in selectedIds && it.groupId.isNotBlank() }
        if (selectedItems.isEmpty()) { status.text = "Sélectionne un groupe ou un calque appartenant à un groupe."; return }
        selectedItems.forEach { item ->
            val group = doc.groups.firstOrNull { it.id == item.groupId }
            item.groupId = group?.parentGroupId.orEmpty()
        }
        pruneEmptyGroups(); refreshLayerStrip(); canvasView.invalidate()
        status.text = "Calque(s) sorti(s) de leur groupe · les autres membres restent groupés."
    }

    private fun configureVideoPoster() {
        val item=doc.items.firstOrNull { it.id==selectedId && it.kind=="video" }
        if(item==null) { status.text="Sélectionne une vidéo."; return }
        val file=mediaFiles[item.id] ?: run { status.text="Fichier vidéo introuvable."; return }
        val duration=try { val r=MediaMetadataRetriever(); r.setDataSource(file.absolutePath); val d=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L; r.release(); d } catch (_:Exception) { 0L }
        val maxMs=duration.coerceAtLeast(1000L)
        val preview=ImageView(this).apply { adjustViewBounds=true; scaleType=ImageView.ScaleType.FIT_CENTER; layoutParams=LinearLayout.LayoutParams(-1,dp(150)) }
        val timeLabel=TextView(this).apply { setTextColor(Color.WHITE); textSize=12f; gravity=Gravity.CENTER }
        val slider=SeekBar(this).apply { max=(maxMs/10L).toInt().coerceAtLeast(1); progress=(item.posterTimeMs/10L).toInt().coerceIn(0,max) }
        fun timeText(ms:Long)="${ms/1000}.${((ms%1000)/10).toString().padStart(2,'0')} s"
        fun showFrame(ms:Long) {
            timeLabel.text=timeText(ms)
            thumbnailExecutor.execute {
                val bmp=try { val r=MediaMetadataRetriever(); r.setDataSource(file.absolutePath); val frame=r.getFrameAtTime(ms*1000L,MediaMetadataRetriever.OPTION_CLOSEST); r.release(); frame } catch (_:Exception) { null }
                runOnUiThread { if(bmp!=null) preview.setImageBitmap(bmp) }
            }
        }
        slider.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar:SeekBar?,progress:Int,fromUser:Boolean) { if(fromUser) timeLabel.text=timeText(progress*10L) }
            override fun onStartTrackingTouch(seekBar:SeekBar?) {}
            override fun onStopTrackingTouch(seekBar:SeekBar?) { showFrame(seekBar?.progress?.toLong()?.times(10L) ?: 0L) }
        })
        val filmstrip=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        val filmScroll=HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled=true; addView(filmstrip) }
        val panel=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(8),dp(16),0); addView(preview); addView(filmScroll,LinearLayout.LayoutParams(-1,dp(76))); addView(timeLabel); addView(slider) }
        showFrame(item.posterTimeMs)
        thumbnailExecutor.execute {
            val frames=mutableListOf<Pair<Long,Bitmap>>()
            try {
                val retriever=MediaMetadataRetriever(); retriever.setDataSource(file.absolutePath)
                for(i in 0..9) {
                    val ms=maxMs*i/9L
                    val raw=retriever.getFrameAtTime(ms*1000L,MediaMetadataRetriever.OPTION_CLOSEST) ?: continue
                    val thumb=Bitmap.createScaledBitmap(raw,120,68,true)
                    if(thumb!==raw) raw.recycle()
                    frames.add(ms to thumb)
                }
                retriever.release()
            } catch (_:Exception) { }
            runOnUiThread {
                frames.forEach { (ms,bmp) ->
                    val tile=ImageView(this).apply { setImageBitmap(bmp); scaleType=ImageView.ScaleType.CENTER_CROP; setPadding(dp(1),dp(1),dp(1),dp(1)); setOnClickListener { slider.progress=(ms/10L).toInt().coerceIn(0,slider.max); showFrame(ms) } }
                    filmstrip.addView(tile,LinearLayout.LayoutParams(dp(78),dp(64)).apply { marginEnd=dp(3) })
                }
            }
        }
        AlertDialog.Builder(this).setTitle("Choisir le poster vidéo").setMessage("Fais glisser le curseur pour choisir l'image initiale.")
            .setView(panel).setNegativeButton("Annuler",null).setPositiveButton("Définir le poster") { _,_ ->
                recordUndo(); item.posterTimeMs=slider.progress*10L
                thumbnailExecutor.execute { ThumbnailCache.generateVideoFrameAt(item.id,file,item.posterTimeMs,item.sourceWidth,item.sourceHeight); runOnUiThread { canvasView.invalidate(); refreshVideoStrip(); status.text="Poster défini à ${timeText(item.posterTimeMs)}." } }
            }.show()
    }

    private fun configureVideoOrder() {
        if (doc.items.none { it.kind == "video" }) { status.text = "Aucune vidéo dans le projet."; return }
        setRightPanelTab("videos"); setLayerPanelOpen(true)
        status.text = "Panneau Vidéo · réorganise avec ↑ / ↓ et règle le volume de chaque vidéo."
    }

    private fun configureVideoVolume() {
        val item=doc.items.firstOrNull { it.id==selectedId && it.kind=="video" }
        if(item==null) { status.text="Sélectionne une vidéo."; return }
        val seek=SeekBar(this).apply { max=100; progress=(item.volume*100).toInt() }
        AlertDialog.Builder(this).setTitle("Volume de la vidéo").setView(seek)
            .setNegativeButton("Annuler",null).setPositiveButton("Appliquer") { _,_ -> recordUndo(); item.volume=seek.progress/100f; if (playingItemId == item.id) exoPlayer?.volume=item.volume; refreshVideoStrip(); status.text="Volume réglé à ${seek.progress} %." }.show()
    }

    private fun beginCropMode() {
        val item = doc.items.firstOrNull { it.id == selectedId && it.visible && it.kind in setOf("image", "video") }
        if (item == null) { status.text = "Sélectionne une image ou une vidéo en mode Modifier."; return }
        editMode = true; canvasView.setEditMode(true); cropMode = true
        cropOriginal = floatArrayOf(item.cropLeft, item.cropTop, item.cropRight, item.cropBottom, item.width, item.height, item.x, item.y)
        status.text = "Modifier le calque · coins = recadrage non destructif ; côtés = compression sur un axe."
        canvasView.invalidate()
    }

    private fun resetCropMode() {
        val item = doc.items.firstOrNull { it.id == selectedId } ?: return
        item.cropLeft = 0f; item.cropTop = 0f; item.cropRight = 1f; item.cropBottom = 1f
        canvasView.invalidate(); status.text = "Zone de recadrage réinitialisée."
    }

    private fun finishCropMode(apply: Boolean) {
        if (!cropMode) { status.text = "Aucun recadrage en cours."; return }
        val item = doc.items.firstOrNull { it.id == selectedId }
        if (apply) recordUndo()
        if (!apply && item != null) cropOriginal?.let { item.cropLeft=it[0]; item.cropTop=it[1]; item.cropRight=it[2]; item.cropBottom=it[3]; if(it.size>=8){item.width=it[4];item.height=it[5];item.x=it[6];item.y=it[7]} }
        cropMode = false; cropOriginal = null; cropDragMode = ""; canvasView.invalidate()
        status.text = if (apply) "Recadrage validé." else "Recadrage annulé."
    }

    private fun showCropDialog() {
        val item = doc.items.firstOrNull { it.id == selectedId }
        if (item == null || item.kind !in setOf("image", "video")) { status.text = "Sélectionne une image ou une vidéo pour régler son recadrage."; return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20,8,20,4) }
        fun field(label: String, value: Float): EditText {
            box.addView(TextView(this).apply { text = label })
            return EditText(this).apply { inputType = 8194; setText((value * 100f).toInt().toString()); hint = "0 à 100 %" }.also { box.addView(it) }
        }
        val l=field("Gauche (%)",item.cropLeft); val t=field("Haut (%)",item.cropTop)
        val r=field("Droite (%)",item.cropRight); val b=field("Bas (%)",item.cropBottom)
        AlertDialog.Builder(this).setTitle("Recadrage non destructif") .setView(box)
            .setNegativeButton("Annuler",null).setNeutralButton("Réinitialiser") { _,_ -> item.cropLeft=0f; item.cropTop=0f; item.cropRight=1f; item.cropBottom=1f; canvasView.invalidate(); status.text="Recadrage réinitialisé." }
            .setPositiveButton("Appliquer") { _,_ ->
                val values=listOf(l,t,r,b).map { it.text.toString().toFloatOrNull()?.div(100f) }
                if(values.any { it==null }) { status.text="Valeurs de recadrage invalides."; return@setPositiveButton }
                val (left,top,right,bottom)=values.map { it!!.coerceIn(0f,1f) }
                if(right-left<0.05f || bottom-top<0.05f) { status.text="Le cadre doit conserver au moins 5 % de largeur et de hauteur."; return@setPositiveButton }
                recordUndo(); item.cropLeft=left; item.cropTop=top; item.cropRight=right; item.cropBottom=bottom
                canvasView.invalidate(); status.text="Recadrage appliqué sans modifier le fichier original."
            }.show()
    }

    private fun showCanvasDimensionsDialog() {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20,8,20,4) }
        val widthInput = EditText(this).apply { inputType = 2; setText(doc.canvasWidth.toString()); hint = "Largeur en pixels" }
        val heightInput = EditText(this).apply { inputType = 2; setText(doc.canvasHeight.toString()); hint = "Hauteur en pixels" }
        val lock = CheckBox(this).apply { text = "Conserver le ratio du canevas (hauteur recalculée)"; isChecked = false }
        layout.addView(TextView(this).apply { text = "Largeur (px)" }); layout.addView(widthInput)
        layout.addView(TextView(this).apply { text = "Hauteur (px)" }); layout.addView(heightInput); layout.addView(lock)
        AlertDialog.Builder(this).setTitle("Dimensions du canevas").setView(layout)
            .setNegativeButton("Annuler", null).setPositiveButton("Appliquer") { _, _ ->
                val w = widthInput.text.toString().toIntOrNull(); val h = heightInput.text.toString().toIntOrNull()
                if (w == null || h == null || w !in 64..16384 || h !in 64..16384) { status.text = "Dimensions invalides (64 à 16384 px)."; return@setPositiveButton }
                recordUndo()
                val oldW=doc.canvasWidth.toFloat(); val oldH=doc.canvasHeight.toFloat()
                val finalHeight = if (lock.isChecked) (w * oldH / oldW).toInt().coerceIn(64,16384) else h
                doc.items.forEach { item ->
                    item.x = (item.x * oldW / w).coerceIn(-0.5f, 1.5f)
                    item.y = (item.y * oldH / finalHeight).coerceIn(-0.5f, 1.5f)
                    item.width = (item.width * oldW / w).coerceIn(0.001f, 4f)
                    item.height = (item.height * oldH / finalHeight).coerceIn(0.001f, 4f)
                }
                doc.canvasWidth=w; doc.canvasHeight=finalHeight
                canvasView.invalidate(); status.text = "Canevas : ${w} × ${finalHeight} px. Les dimensions physiques des médias sont conservées."
            }.show()
    }

    private fun makeButton(label: String, id: Int, action: () -> Unit): Button = Button(this).apply {
        text = label; textSize = 10.5f; isAllCaps = false; setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-2, dp(36)).apply { marginEnd = dp(4) }
        setTextColor(Color.rgb(239, 243, 238))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(if (id == 15 || id == 2) Color.rgb(55, 116, 106) else Color.rgb(43, 61, 65))
            cornerRadius = dp(8).toFloat()
            setStroke(dp(1), Color.rgb(65, 83, 85))
        }
        minWidth = dp(34); minHeight = dp(32); setPadding(dp(5), 0, dp(5), 0)
        stateListAnimator = null
    }

    private fun makeAnchorButton(label: String, id: Int, action: (View) -> Unit): Button = Button(this).apply {
        text = label; textSize = 10.5f; isAllCaps = false; setOnClickListener { action(this) }
        layoutParams = LinearLayout.LayoutParams(-2, dp(36)).apply { marginEnd = dp(4) }
        setTextColor(Color.rgb(239, 243, 238))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.rgb(43, 61, 65)); cornerRadius = dp(8).toFloat()
            setStroke(dp(1), Color.rgb(65, 83, 85))
        }
        minWidth = dp(34); minHeight = dp(32); setPadding(dp(5), 0, dp(5), 0)
        stateListAnimator = null
    }

    private fun saveProjectUri(uri: Uri) {
        val saveSnapshot = ProjectDocument.fromJson(doc.toJson())
        val saveFiles = mediaFiles.toMap()
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        status.text = "Préparation de l'archive…"
        thread {
            try {
                contentResolver.openOutputStream(uri, "wt")?.use { out ->
                    ProjectArchive.save(this, saveSnapshot, saveFiles, out) { p ->
                        runOnUiThread { progress.isIndeterminate = false; progress.progress = p; status.text = "Enregistrement : $p%" }
                    }
                } ?: throw Exception("Impossible d'écrire le fichier choisi.")
                runOnUiThread {
                    currentProjectUri = uri
                    currentProjectBaseName = queryDisplayName(uri)?.substringBeforeLast(".")?.ifBlank { safeDocName(doc.name) } ?: safeDocName(doc.name)
                    progress.visibility = View.GONE; status.text = "Projet enregistré : ${saveSnapshot.items.size} élément(s)."
                }
            } catch (e: Exception) {
                runOnUiThread { progress.visibility = View.GONE; status.text = "Échec de sauvegarde : ${e.message}" }
            }
        }
    }

    private fun openProjectUri(uri: Uri, canOverwrite: Boolean) {
        if (isImporting) { status.text = "Attends la fin de l'importation avant d'ouvrir un autre projet."; return }
        if (isOpeningProject) { status.text = "Une ouverture est déjà en cours."; return }
        isOpeningProject = true
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        status.text = "Ouverture et vérification du projet…"
        thread {
            try {
                val (loaded, loadedFiles) = contentResolver.openInputStream(uri)?.use { input ->
                    ProjectArchive.open(this, input) { p -> runOnUiThread { status.text = "Lecture de l'archive…"; progress.progress = p } }
                } ?: throw Exception("Impossible de lire ce fichier.")
                // Drain thumbnail work from the previous document before clearing its cache.
                val drainThumbnails = java.util.concurrent.FutureTask<Unit> { Unit }
                thumbnailExecutor.execute(drainThumbnails)
                drainThumbnails.get()
                runOnUiThread {
                    isOpeningProject = false
                    currentProjectUri = if (canOverwrite) uri else null
                    currentProjectBaseName = queryDisplayName(uri)?.substringBeforeLast(".")?.ifBlank { safeDocName(loaded.name) } ?: safeDocName(loaded.name)
                    stopInlineVideo()
                    ThumbnailCache.clear()
                    doc.name = loaded.name; doc.canvasWidth = loaded.canvasWidth; doc.canvasHeight = loaded.canvasHeight
                    doc.items.clear(); doc.items.addAll(loaded.items)
                    doc.groups.clear(); doc.groups.addAll(loaded.groups)
                    mediaFiles.clear(); mediaFiles.putAll(loadedFiles)
                    selectedIds.clear(); selectedGroupId = null
                    selectedId = doc.items.lastOrNull { it.visible }?.id
                    selectedId?.let { selectedIds.add(it) }
                    progress.visibility = View.GONE
                    status.text = "Projet ouvert et vérifié : ${doc.items.size} élément(s)."
                    canvasView.invalidate(); refreshLayerStrip()
                }
            } catch (e: Exception) {
                runOnUiThread { isOpeningProject = false; progress.visibility = View.GONE; status.text = "Ouverture impossible : ${e.message}" }
            }
        }
    }

    private fun moveSelectedLayer(direction: Int) {
        val index = doc.items.indexOfFirst { it.id == selectedId }
        if (index < 0) { status.text = "Sélectionne d'abord un calque."; return }
        val target = (index + direction).coerceIn(0, doc.items.lastIndex)
        if (target != index) {
            val item = doc.items.removeAt(index)
            doc.items.add(target, item)
            canvasView.invalidate(); refreshLayerStrip()
        }
    }

    private fun resizeSelected(factor: Float) {
        val item = doc.items.firstOrNull { it.id == selectedId }
        if (item == null) { status.text = "Sélectionne d'abord un calque."; return }
        item.width = (item.width * factor).coerceIn(0.04f, 1.8f)
        item.height = (item.height * factor).coerceIn(0.04f, 1.8f)
        canvasView.invalidate()
    }

    private fun playSelectedVideo() {
        val item = doc.items.firstOrNull { it.id == selectedId && it.visible }
        if (item == null || item.kind != "video") {
            status.text = "Sélectionne d'abord un calque vidéo."
            return
        }
        val file = mediaFiles[item.id]
        if (file == null || !file.isFile) {
            status.text = "Fichier vidéo introuvable dans le projet."
            return
        }
        try {
            val player = exoPlayer ?: ExoPlayer.Builder(this).build().also { created ->
                exoPlayer = created
                playerView.player = created
                created.addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        if (playbackState == Player.STATE_ENDED) {
                            val endedId = playingItemId
                            if (endedId != null) {
                                videoPositions.remove(endedId)
                                releaseVideoAtFrame(endedId, 0L)
                            }
                            status.text = "Vidéo terminée · aperçu de départ restauré."
                        }
                    }
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        if (isPlaying) {
                            pauseReleaseRunnable?.let { pauseReleaseHandler.removeCallbacks(it) }
                            pauseReleaseRunnable = null
                        } else if (!suppressPauseCapture && created.playbackState == Player.STATE_READY && !created.playWhenReady) {
                            playingItemId?.let { pausedId ->
                                videoPositions[pausedId] = created.currentPosition
                                status.text = "Vidéo en pause · libération automatique après 30 s"
                                pauseReleaseRunnable?.let { pauseReleaseHandler.removeCallbacks(it) }
                                val release = Runnable {
                                    if (playingItemId == pausedId && !created.isPlaying) releaseVideoAtFrame(pausedId, created.currentPosition)
                                }
                                pauseReleaseRunnable = release
                                pauseReleaseHandler.postDelayed(release, 30_000L)
                            }
                        }
                    }
                    override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                        status.text = "Lecture vidéo impossible : ${error.message ?: "format non pris en charge"}"
                        releaseVideoAtFrame(playingItemId, 0L)
                    }
                })
            }
            if (playingItemId == item.id) {
                if (player.isPlaying) player.pause() else player.play()
                playerView.showController()
                return
            }
            if (playingItemId != null && playingItemId != item.id) {
                releaseVideoAtFrame(playingItemId, player.currentPosition)
            }
            playingItemId = item.id
            player.volume = item.volume.coerceIn(0f, 1f)
            playerClipFrame.visibility = View.VISIBLE
            updateInlinePlayerOverlay()
            playerView.useController = true
            playerView.showController()
            suppressPauseCapture = true
            player.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)), videoPositions[item.id] ?: 0L)
            player.prepare()
            player.playWhenReady = true
            suppressPauseCapture = false
            status.text = "Lecture intégrée · contrôles sur la vidéo"
        } catch (e: Exception) {
            stopInlineVideo()
            status.text = "Lecture vidéo impossible : ${e.message}"
        }
    }

    private fun updateInlinePlayerOverlay() {
        if (!::playerClipFrame.isInitialized || playerClipFrame.visibility != View.VISIBLE) return
        val currentId = playingItemId
        val item = doc.items.firstOrNull { it.id == currentId && it.visible }
        if (item == null || editMode || selectedId != currentId) {
            if (currentId != null) releaseVideoAtFrame(currentId, exoPlayer?.currentPosition ?: 0L)
            return
        }
        val geometry = canvasView.videoOverlayGeometry(item) ?: return
        val rect = geometry.first
        val params = FrameLayout.LayoutParams(
            rect.width().toInt().coerceAtLeast(1),
            rect.height().toInt().coerceAtLeast(1)
        )
        params.leftMargin = rect.left.toInt()
        params.topMargin = rect.top.toInt()
        playerClipFrame.layoutParams = params
        playerClipFrame.pivotX = rect.width() / 2f; playerClipFrame.pivotY = rect.height() / 2f
        playerClipFrame.rotation = geometry.second
        playerClipFrame.clipChildren = true; playerClipFrame.clipToPadding = true
        val cropW = (item.cropRight - item.cropLeft).coerceIn(0.05f, 1f)
        val cropH = (item.cropBottom - item.cropTop).coerceIn(0.05f, 1f)
        playerView.pivotX = 0f; playerView.pivotY = 0f
        playerView.scaleX = (if(item.flipHorizontal) -1f else 1f) / cropW
        playerView.scaleY = (if(item.flipVertical) -1f else 1f) / cropH
        playerView.translationX = if(item.flipHorizontal) rect.width() * item.cropRight / cropW else -rect.width() * item.cropLeft / cropW
        playerView.translationY = if(item.flipVertical) rect.height() * item.cropBottom / cropH else -rect.height() * item.cropTop / cropH
        occlusionView.invalidate()
    }

    private fun releaseVideoAtFrame(itemId: String?, positionMs: Long) {
        if (itemId == null) return
        pauseReleaseRunnable?.let { pauseReleaseHandler.removeCallbacks(it) }; pauseReleaseRunnable = null
        videoPositions[itemId] = positionMs.coerceAtLeast(0L)
        val file = mediaFiles[itemId]
        val videoItem = doc.items.firstOrNull { it.id == itemId }
        val expectedWidth = videoItem?.sourceWidth ?: 0
        val expectedHeight = videoItem?.sourceHeight ?: 0
        val activePlayer = exoPlayer
        suppressPauseCapture = true
        activePlayer?.pause()
        suppressPauseCapture = false
        if (playingItemId == itemId) {
            playerClipFrame.visibility = View.GONE
            playerClipFrame.rotation = 0f
            playerView.scaleX = 1f; playerView.scaleY = 1f
            playerView.translationX = 0f; playerView.translationY = 0f
            playingItemId = null
            activePlayer?.clearMediaItems()
        }
        if (file != null && file.isFile) {
            thumbnailExecutor.execute {
                ThumbnailCache.generateVideoFrameAt(itemId, file, positionMs, expectedWidth, expectedHeight)
                runOnUiThread { canvasView.invalidate(); if (::occlusionView.isInitialized) occlusionView.invalidate() }
            }
        }
    }

    private fun stopInlineVideo() {
        pauseReleaseRunnable?.let { pauseReleaseHandler.removeCallbacks(it) }; pauseReleaseRunnable = null
        val currentId = playingItemId
        if (currentId != null) {
            val position = exoPlayer?.currentPosition ?: videoPositions[currentId] ?: 0L
            videoPositions[currentId] = position
            releaseVideoAtFrame(currentId, position)
        } else {
            suppressPauseCapture = true
            exoPlayer?.pause()
            exoPlayer?.clearMediaItems()
            suppressPauseCapture = false
            if (::playerClipFrame.isInitialized) playerClipFrame.visibility = View.GONE
        }
    }

    override fun onPause() {
        val current = playingItemId
        if (current != null) releaseVideoAtFrame(current, exoPlayer?.currentPosition ?: 0L)
        super.onPause()
    }

    override fun onDestroy() {
        pauseReleaseRunnable?.let { pauseReleaseHandler.removeCallbacks(it) }; pauseReleaseRunnable = null
        suppressPauseCapture = true
        exoPlayer?.release()
        exoPlayer = null
        thumbnailExecutor.shutdownNow()
        super.onDestroy()
    }

    private fun deleteSelected() {
        recordUndo()
        val ids = if (selectedIds.isNotEmpty()) selectedIds.toSet() else (selectedId?.let { setOf(it) } ?: emptySet())
        playingItemId?.let { if (it in ids) stopInlineVideo() }
        if (ids.isEmpty()) { status.text = "Sélectionne d'abord un calque."; return }
        val referenced = doc.items.filter { it.id !in ids && it.visible }.flatMap { it.sourceItemIds }.toSet()
        if (ids.any { it in referenced }) {
            status.text = "Ce média est conservé comme source d'une fusion. Supprime d'abord la fusion."
            return
        }
        val restoreIds = doc.items.filter { it.id in ids }.flatMap { it.sourceItemIds }.toSet()
        doc.items.filter { it.id in ids }.forEach { item ->
            val file = mediaFiles.remove(item.id)
            ThumbnailCache.remove(item.id, file)
            file?.delete()
        }
        doc.items.removeAll { it.id in ids }
        doc.items.filter { it.id in restoreIds }.forEach { it.visible = true }
        selectedIds.clear()
        selectedId = null
        canvasView.invalidate(); refreshLayerStrip()
        status.text = "Calque(s) supprimé(s). Les sources d'une fusion ont été restaurées."
    }

    private fun restoreSelectedSources() {
        recordUndo()
        val selectedComposites = doc.items.filter { it.id in selectedIds && it.visible && it.sourceItemIds.isNotEmpty() }
        val hiddenSelected = doc.items.filter { it.id in selectedIds && !it.visible }
        val sourceIds = (hiddenSelected.map { it.id } + selectedComposites.flatMap { it.sourceItemIds }).toSet()
        if (sourceIds.isEmpty()) { status.text = "Sélectionne une fusion ou l'un de ses calques sources."; return }
        val composites = (selectedComposites + doc.items.filter { it.visible && it.sourceItemIds.any { sourceId -> sourceId in sourceIds } }).distinctBy { it.id }
        if (composites.isEmpty()) {
            hiddenSelected.forEach { it.visible = true }
        } else {
            composites.forEach { composite ->
                doc.items.filter { it.id in composite.sourceItemIds }.forEach { source -> source.visible = true; source.groupId = composite.groupId }
                val compositeFile = mediaFiles.remove(composite.id)
                ThumbnailCache.remove(composite.id, compositeFile)
                compositeFile?.delete()
                doc.items.remove(composite)
            }
        }
        selectedIds.clear()
        val restored = doc.items.filter { it.visible && (it.id in sourceIds || composites.any { c -> it.id in c.sourceItemIds }) }
        restored.forEach { selectedIds.add(it.id) }
        selectedId = restored.lastOrNull()?.id
        canvasView.invalidate()
        refreshLayerStrip()
        status.text = "Fusion dissociée : les calques sources sont de nouveau accessibles."
    }

    private fun mergeSelectedLayers() {
        recordUndo()
        val selected = doc.items.filter { it.id in selectedIds && it.visible }
        if (selected.size < 2) {
            status.text = "Sélectionne au moins deux calques avec un appui long dans la liste."
            return
        }
        playingItemId?.let { if (it in selectedIds) stopInlineVideo() }
        val snapshot = selected.map { it.copy(sourceItemIds = it.sourceItemIds.toMutableList()) }
        val files = snapshot.associate { it.id to mediaFiles[it.id] }
        val canvasWidth = doc.canvasWidth
        val canvasHeight = doc.canvasHeight
        val selectedTopIndex = snapshot.map { original -> doc.items.indexOfFirst { it.id == original.id } }.filter { it >= 0 }.maxOrNull() ?: doc.items.size
        progress.visibility = View.VISIBLE
        progress.isIndeterminate = true
        status.text = "Fusion des calques…"
        thread {
            var output: File? = null
            try {
                val bounds = snapshot.map { item ->
                    val cx = item.x * canvasWidth
                    val cy = item.y * canvasHeight
                    val w = item.width * canvasWidth
                    val h = item.height * canvasHeight
                    val r = Math.toRadians(item.rotation.toDouble())
                    val ex = (kotlin.math.abs(kotlin.math.cos(r)) * w + kotlin.math.abs(kotlin.math.sin(r)) * h) / 2.0
                    val ey = (kotlin.math.abs(kotlin.math.sin(r)) * w + kotlin.math.abs(kotlin.math.cos(r)) * h) / 2.0
                    floatArrayOf((cx - ex).toFloat(), (cy - ey).toFloat(), (cx + ex).toFloat(), (cy + ey).toFloat())
                }
                val left = bounds.minOf { it[0] }.coerceAtLeast(0f)
                val top = bounds.minOf { it[1] }.coerceAtLeast(0f)
                val right = bounds.maxOf { it[2] }.coerceAtMost(canvasWidth.toFloat())
                val bottom = bounds.maxOf { it[3] }.coerceAtMost(canvasHeight.toFloat())
                val logicalW = (right - left).coerceAtLeast(1f)
                val logicalH = (bottom - top).coerceAtLeast(1f)
                val scale = minOf(1f, 2560f / max(logicalW, logicalH))
                val outW = (logicalW * scale).toInt().coerceAtLeast(1)
                val outH = (logicalH * scale).toInt().coerceAtLeast(1)
                val bitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)
                canvas.scale(scale, scale)
                canvas.translate(-left, -top)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                snapshot.forEach { item ->
                    val source = files[item.id] ?: throw IOException("Média absent : ${item.displayName}")
                    val mergeBitmap = decodeMergeBitmap(source, item.kind)
                        ?: throw IOException("Média illisible pour la fusion : ${item.displayName}")
                    val cx = item.x * canvasWidth
                    val cy = item.y * canvasHeight
                    val w = item.width * canvasWidth
                    val h = item.height * canvasHeight
                    val rect = RectF(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)
                    canvas.save()
                    canvas.rotate(item.rotation, cx, cy)
                    canvas.scale(if(item.flipHorizontal) -1f else 1f, if(item.flipVertical) -1f else 1f, cx, cy)
                    if (item.cropLeft > 0f || item.cropTop > 0f || item.cropRight < 1f || item.cropBottom < 1f) {
                        val src = Rect((mergeBitmap.width*item.cropLeft).toInt().coerceIn(0,mergeBitmap.width-1), (mergeBitmap.height*item.cropTop).toInt().coerceIn(0,mergeBitmap.height-1), (mergeBitmap.width*item.cropRight).toInt().coerceIn(1,mergeBitmap.width), (mergeBitmap.height*item.cropBottom).toInt().coerceIn(1,mergeBitmap.height))
                        canvas.drawBitmap(mergeBitmap, src, rect, paint)
                    } else drawFittedBitmap(canvas, mergeBitmap, rect, paint, item.fitMode)
                    canvas.restore()
                    mergeBitmap.recycle()
                }
                output = File(filesDir, "project-media/imports/${UUID.randomUUID()}_fusion.png")
                output!!.parentFile?.mkdirs()
                FileOutputStream(output!!).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
                bitmap.recycle()
                val mergedId = UUID.randomUUID().toString()
                val originalSourceCount = snapshot.sumOf { item ->
                    if (item.sourceItemIds.isEmpty()) 1 else item.sourceItemIds.distinct().size
                }
                val merged = ProjectItem(
                    id = mergedId,
                    mediaPath = "media/${mergedId}_fusion.png",
                    displayName = "Fusion $originalSourceCount calques",
                    mimeType = "image/png",
                    kind = "image",
                    x = (left + right) / (2f * canvasWidth),
                    y = (top + bottom) / (2f * canvasHeight),
                    width = logicalW / canvasWidth,
                    height = logicalH / canvasHeight,
                    sha256 = ProjectArchive.sha256(output!!),
                    sourceWidth = outW,
                    sourceHeight = outH,
                    fitMode = "contain",
                    sourceItemIds = snapshot.flatMap { if (it.sourceItemIds.isEmpty()) listOf(it.id) else it.sourceItemIds }.distinct().toMutableList(),
                    groupId = snapshot.map { it.groupId }.distinct().singleOrNull() ?: ""
                )
                runOnUiThread {
                    if (doc.canvasWidth != canvasWidth || doc.canvasHeight != canvasHeight || snapshot.any { original ->
                        val current = doc.items.firstOrNull { it.id == original.id }
                        current == null || current.x != original.x || current.y != original.y || current.width != original.width || current.height != original.height || current.rotation != original.rotation
                    }) {
                        output?.delete(); progress.visibility = View.GONE
                        status.text = "Fusion annulée · le projet a changé pendant le calcul."
                        return@runOnUiThread
                    }
                    snapshot.forEach { original ->
                        val current = doc.items.firstOrNull { it.id == original.id } ?: return@forEach
                        if (current.sourceItemIds.isNotEmpty()) {
                            // A previous flattened bitmap is an intermediate derivative:
                            // discard it and keep only its original source assets.
                            doc.items.remove(current)
                            val intermediateFile = mediaFiles.remove(current.id)
                            ThumbnailCache.remove(current.id, intermediateFile)
                            intermediateFile?.delete()
                        } else {
                            current.visible = false
                            current.groupId = ""
                        }
                    }
                    pruneEmptyGroups()
                    doc.items.add(selectedTopIndex.coerceIn(0, doc.items.size), merged)
                    mediaFiles[merged.id] = output!!
                    selectedIds.clear(); selectedIds.add(merged.id); selectedId = merged.id
                    canvasView.invalidate(); refreshLayerStrip()
                    progress.visibility = View.GONE
                    status.text = "Fusion créée. Originaux conservés dans le projet et référencés."
                }
            } catch (e: Exception) {
                output?.delete()
                runOnUiThread {
                    progress.visibility = View.GONE
                    status.text = "Fusion impossible : ${e.message}"
                }
            }
        }
    }

    private fun decodeMergeBitmap(file: File, kind: String): Bitmap? {
        return try {
            if (kind == "image") {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.absolutePath, bounds)
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
                var sample = 1
                while (max(bounds.outWidth, bounds.outHeight) / sample > 2560) sample *= 2
                var bitmap = BitmapFactory.decodeFile(
                    file.absolutePath,
                    BitmapFactory.Options().apply { inSampleSize = sample }
                ) ?: return null
                val maxSide = max(bitmap.width, bitmap.height)
                if (maxSide > 2560) {
                    val ratio = 2560f / maxSide
                    val scaled = Bitmap.createScaledBitmap(
                        bitmap,
                        (bitmap.width * ratio).toInt().coerceAtLeast(1),
                        (bitmap.height * ratio).toInt().coerceAtLeast(1),
                        true
                    )
                    if (scaled !== bitmap) { bitmap.recycle(); bitmap = scaled }
                }
                val orientation = try {
                    ExifInterface(file.absolutePath).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                    )
                } catch (_: Exception) { ExifInterface.ORIENTATION_NORMAL }
                val matrix = Matrix()
                when (orientation) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                    ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                    ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                    ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
                    ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
                    ExifInterface.ORIENTATION_TRANSPOSE -> { matrix.postScale(-1f, 1f); matrix.postRotate(90f) }
                    ExifInterface.ORIENTATION_TRANSVERSE -> { matrix.postScale(-1f, 1f); matrix.postRotate(270f) }
                }
                if (matrix.isIdentity()) bitmap else {
                    val oriented = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
                    if (oriented !== bitmap) bitmap.recycle()
                    oriented
                }
            } else if (kind == "video") {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(file.absolutePath)
                    var frame = retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: return null
                    val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                    if (rotation % 360 != 0) {
                        val rotated = Bitmap.createBitmap(
                            frame, 0, 0, frame.width, frame.height,
                            Matrix().apply { postRotate(rotation.toFloat()) }, true
                        )
                        if (rotated !== frame) { frame.recycle(); frame = rotated }
                    }
                    val maxSide = max(frame.width, frame.height)
                    if (maxSide <= 2560) frame else {
                        val ratio = 2560f / maxSide
                        Bitmap.createScaledBitmap(
                            frame,
                            (frame.width * ratio).toInt().coerceAtLeast(1),
                            (frame.height * ratio).toInt().coerceAtLeast(1),
                            true
                        ).also { if (it !== frame) frame.recycle() }
                    }
                } finally {
                    retriever.release()
                }
            } else null
        } catch (_: OutOfMemoryError) {
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun drawFittedBitmap(canvas: Canvas, bitmap: Bitmap, target: RectF, paint: Paint, mode: String) {
        if (mode == "stretch") {
            canvas.drawBitmap(bitmap, null, target, paint)
            return
        }
        val sourceAspect = bitmap.width.toFloat() / bitmap.height.coerceAtLeast(1)
        val targetAspect = target.width() / target.height().coerceAtLeast(1f)
        if (mode == "cover") {
            val src = if (sourceAspect > targetAspect) {
                val cropWidth = (bitmap.height * targetAspect).toInt().coerceIn(1, bitmap.width)
                val left = (bitmap.width - cropWidth) / 2
                Rect(left, 0, left + cropWidth, bitmap.height)
            } else {
                val cropHeight = (bitmap.width / targetAspect).toInt().coerceIn(1, bitmap.height)
                val top = (bitmap.height - cropHeight) / 2
                Rect(0, top, bitmap.width, top + cropHeight)
            }
            canvas.drawBitmap(bitmap, src, target, paint)
        } else {
            val fittedW: Float
            val fittedH: Float
            if (sourceAspect > targetAspect) {
                fittedW = target.width()
                fittedH = fittedW / sourceAspect
            } else {
                fittedH = target.height()
                fittedW = fittedH * sourceAspect
            }
            val dst = RectF(target.centerX() - fittedW / 2f, target.centerY() - fittedH / 2f,
                target.centerX() + fittedW / 2f, target.centerY() + fittedH / 2f)
            canvas.drawBitmap(bitmap, null, dst, paint)
        }
    }

    private fun exportCanvasPng(uri: Uri) {
        status.text = "Rendu de l'aperçu PNG…"
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        thread {
            var bitmap: Bitmap? = null
            try {
                // PNG export is intentionally an editor-preview export, not the
                // final-resolution renderer. It uses cached, bounded thumbnails.
                val exportScale = minOf(1f, 2560f / doc.canvasWidth.coerceAtLeast(1), 2560f / doc.canvasHeight.coerceAtLeast(1))
                val outW = (doc.canvasWidth * exportScale).toInt().coerceAtLeast(1)
                val outH = (doc.canvasHeight * exportScale).toInt().coerceAtLeast(1)
                val outputBitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
                bitmap = outputBitmap
                val canvas = Canvas(outputBitmap)
                canvas.drawColor(Color.WHITE)
                val snapshot = doc.items.filter { it.visible }.toList()
                // Try to prepare missing previews off the UI thread before rendering.
                snapshot.forEach { item ->
                    val file = mediaFiles[item.id]
                    if (file != null && ThumbnailCache.get(item.id) == null) ThumbnailCache.generate(item.id, file, item.kind)
                }
                val localPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                snapshot.forEach { item ->
                    val cx = item.x * outW; val cy = item.y * outH
                    val w = item.width * outW; val h = item.height * outH
                    val rect = RectF(cx-w/2, cy-h/2, cx+w/2, cy+h/2)
                    val thumb = ThumbnailCache.get(item.id)
                    if (thumb != null) {
                        canvas.save()
                        canvas.rotate(item.rotation, cx, cy)
                        if (item.cropLeft > 0f || item.cropTop > 0f || item.cropRight < 1f || item.cropBottom < 1f) {
                            val src = Rect((thumb.width*item.cropLeft).toInt().coerceIn(0,thumb.width-1), (thumb.height*item.cropTop).toInt().coerceIn(0,thumb.height-1), (thumb.width*item.cropRight).toInt().coerceIn(1,thumb.width), (thumb.height*item.cropBottom).toInt().coerceIn(1,thumb.height))
                            canvas.drawBitmap(thumb, src, rect, localPaint)
                        } else drawFittedBitmap(canvas, thumb, rect, localPaint, item.fitMode)
                        canvas.restore()
                    }
                    else {
                        localPaint.color = Color.LTGRAY
                        canvas.drawRoundRect(rect, 8f, 8f, localPaint)
                        localPaint.color = Color.DKGRAY; localPaint.textSize = 22f
                        canvas.drawText(item.displayName.take(30), rect.left+8f, rect.centerY(), localPaint)
                    }
                }
                contentResolver.openOutputStream(uri)?.use { out ->
                    if (!outputBitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) throw IOException("La compression PNG a échoué.")
                } ?: throw IOException("Impossible d'écrire le PNG choisi.")
                runOnUiThread { status.text = "PNG d’aperçu exporté en ${outW} × ${outH} px (limité à 2560 px par côté, vignettes utilisées)." }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Export PNG échoué : ${e.message}" }
            } finally {
                bitmap?.recycle()
                runOnUiThread { progress.visibility = View.GONE }
            }
        }
    }

    private fun exportInteractivePackage(uri: Uri, profile: HtmlExportProfile) {
        if (isImporting || isOpeningProject) { status.text = "Attends la fin de l'importation ou de l'ouverture avant d'exporter."; return }
        val exportDoc = ProjectDocument.fromJson(doc.toJson())
        val exportFiles = mediaFiles.toMap()
        status.text = "Préparation du HTML autonome…"
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        thread {
            val prepared = mutableListOf<File>()
            val tempHtml = File(cacheDir, "studio_export_${UUID.randomUUID()}.html")
            try {
                val manifest = exportDoc.toJson().toString().replace("</", "<\\/")
                // Build and close the complete HTML locally before touching the
                // Android document provider. This prevents a half-written file
                // from being reported as a successful export if media encoding
                // fails or the destination provider interrupts a long write.
                FileOutputStream(tempHtml).buffered(64 * 1024).use { raw ->
                    fun write(value: String) { raw.write(value.toByteArray(Charsets.UTF_8)) }
                    write("""<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,user-scalable=no">
<title>Studio Mobile — ${safeDocName(exportDoc.name)}</title><style>
:root{--bg:#182225;--panel:#1f2b2f;--panel2:#233036;--line:#324046;--ink:#EDEEE9;--dim:#9AACB0;--accent:#E3A857}
*{box-sizing:border-box}html,body{margin:0;height:100%;font:14px system-ui,sans-serif;background:var(--bg);color:var(--ink)}body{display:flex;flex-direction:column;overflow:hidden}
header{display:flex;align-items:center;gap:10px;padding:10px 12px;background:var(--panel);border-bottom:1px solid var(--line);flex-shrink:0}header strong{letter-spacing:.04em}#menuToggle{background:var(--panel2);border:1px solid var(--line);color:var(--ink);border-radius:9px;padding:8px 11px}#dim{margin-left:auto;color:var(--dim);font-size:11px;white-space:nowrap}
.toolbar{display:flex;gap:6px;overflow-x:auto;padding:8px;background:var(--panel2);border-bottom:1px solid var(--line);flex-shrink:0}.toolbar button{background:var(--panel);border:1px solid var(--line);color:var(--ink);border-radius:7px;padding:7px 10px;white-space:nowrap;font-size:12px}
body.view-mode .toolbar,body.view-mode aside{display:none}main{display:flex;flex:1;min-height:0}.zone{flex:1;min-width:0;display:flex;align-items:center;justify-content:center;overflow:auto;padding:12px;background-color:var(--bg);background-image:linear-gradient(45deg,var(--panel2) 25%,transparent 25%),linear-gradient(-45deg,var(--panel2) 25%,transparent 25%),linear-gradient(45deg,transparent 75%,var(--panel2) 75%),linear-gradient(-45deg,transparent 75%,var(--panel2) 75%);background-size:16px 16px;background-position:0 0,0 8px,8px -8px,-8px 0}
#stage{position:relative;flex-shrink:0;transform-origin:center center;touch-action:none;background:#0f1517;border:1px solid var(--line);box-shadow:0 8px 30px #0007;overflow:hidden}.item{position:absolute;transform:translate(-50%,-50%) rotate(var(--rotation,0deg));overflow:hidden;background:transparent;outline:1px solid #324046;touch-action:none}.item.active{outline:2px solid var(--accent);z-index:999!important}.item img,.item video{width:100%;height:100%;object-fit:contain;display:block}.handle{position:absolute;right:0;bottom:0;width:20px;height:20px;background:var(--accent);border:2px solid #182225;border-radius:50%;touch-action:none}.rotate-handle{position:absolute;right:0;top:0;width:20px;height:20px;background:#75c5b4;border:2px solid #182225;border-radius:50%;touch-action:none}body.view-mode .item{outline:none}body.view-mode .handle,body.view-mode .rotate-handle{display:none}
aside{width:88px;flex-shrink:0;overflow:auto;padding:7px;background:var(--panel);border-left:1px solid var(--line)}.layer{width:100%;min-height:48px;margin-bottom:7px;border:2px solid transparent;border-radius:8px;background:#0f1517;color:var(--ink);font-size:10px;padding:6px;overflow:hidden}.layer.active{border-color:var(--accent)}footer{padding:7px 10px;background:var(--panel);border-top:1px solid var(--line);font-size:11px;color:var(--dim);flex-shrink:0}#diag{position:fixed;right:8px;bottom:8px;z-index:9999;max-width:70vw;padding:4px 7px;border-radius:5px;background:#0009;color:#b9c7c8;font:10px system-ui;pointer-events:none}button:active{transform:translateY(1px)}
</style></head><body><header><strong>STUDIO · MOBILE</strong><button id="playMain" aria-label="Lire les vidéos">▶</button><button id="pauseMain" aria-label="Pause">Ⅱ</button><button id="recenterMain" aria-label="Recentrer la vue">◎</button><button id="fullscreen" aria-label="Plein écran">⛶</button><button id="menuToggle" aria-expanded="false">☰ Menu</button><span id="dim"></span></header>
<div class="toolbar"><button id="up">Calque ↑</button><button id="down">Calque ↓</button><button id="bigger">Taille +</button><button id="smaller">Taille −</button><button id="reset">Centrer</button><button id="zoomOut">Vue −</button><button id="zoomIn">Vue +</button><button id="rotateView">Tourner vue</button><button id="resetView">Réinitialiser vue</button><button id="playAll">▶ Lire / Stop</button><button id="pauseAll">Ⅱ Pause</button></div>
<main><section class="zone"><div id="stage"></div></section><aside id="layers"></aside></main><footer id="status">Projet autonome · profil ${profile.label}. Photos optimisées ; vidéos conservées dans leur format source et chargées à la demande.</footer><div id="diag">Diagnostic temporaire · aperçu et chargement</div>
<script>
const doc = $manifest;
const mediaSources = {
""")
                    val exportItems = exportDoc.items.filter { it.visible }
                    exportItems.forEachIndexed { index, item ->
                        val source = exportFiles[item.id] ?: throw IOException("Média absent : ${item.displayName}")
                        val fileToEmbed = if (item.kind == "image") prepareHtmlImage(source, item.mimeType, profile).also { if (it != source) prepared.add(it) } else source
                        val mime = if (item.kind == "image" && fileToEmbed != source && item.mimeType != "image/png") "image/jpeg" else item.mimeType
                        write(JSONObjectQuote(item.id) + ":\"data:$mime;base64,")
                        val expectedBytes = fileToEmbed.length()
                        val nonClosing = object : java.io.FilterOutputStream(raw) { override fun close() { flush() } }
                        val encodedInputBytes = java.util.Base64.getEncoder().wrap(nonClosing).use { encoded ->
                            fileToEmbed.inputStream().buffered().use { input -> input.copyTo(encoded, 64 * 1024) }
                        }
                        if (encodedInputBytes != expectedBytes) throw IOException("Média intégré partiellement : ${item.displayName} ($encodedInputBytes / $expectedBytes octets).")
                        write("\"")
                        if (index < exportItems.lastIndex) write(",")
                        val pct = ((index + 1) * 100) / exportItems.size.coerceAtLeast(1)
                        runOnUiThread { progress.isIndeterminate = false; progress.progress = pct; status.text = "Intégration des médias : $pct%" }
                    }
                    write("""
};
const posterSources={
""")
                    val videoItems = exportItems.filter { it.kind == "video" }
                    var firstPosterWritten = true
                    videoItems.forEach { item ->
                        val source = exportFiles[item.id] ?: throw IOException("Vidéo absente : ${item.displayName}")
                        val posterTask = java.util.concurrent.FutureTask<Bitmap?> {
                            ThumbnailCache.generateVideoFrameAt(item.id, source, item.posterTimeMs, item.sourceWidth, item.sourceHeight)
                                ?: ThumbnailCache.generate(item.id, source, "video")
                        }
                        thumbnailExecutor.execute(posterTask)
                        val poster = posterTask.get()
                        if (poster != null) {
                            val posterFile = File(cacheDir, "poster_${UUID.randomUUID()}.jpg")
                            FileOutputStream(posterFile).use { out -> poster.compress(Bitmap.CompressFormat.JPEG, 82, out) }
                            prepared.add(posterFile)
                            if (!firstPosterWritten) write(",")
                            write(JSONObjectQuote(item.id) + ":\"data:image/jpeg;base64,")
                            firstPosterWritten = false
                            val nonClosingPoster = object : java.io.FilterOutputStream(raw) { override fun close() { flush() } }
                            java.util.Base64.getEncoder().wrap(nonClosingPoster).use { encoded ->
                                posterFile.inputStream().buffered().use { input -> input.copyTo(encoded, 16 * 1024) }
                            }
                            write("\"")
                        }
                    }
                    write("""
};
const stage=document.getElementById('stage'),rail=document.getElementById('layers'),status=document.getElementById('status');
const visibleItems=doc.items.filter(x=>x.visible!==false);let selected=visibleItems.length?visibleItems[visibleItems.length-1].id:null;
document.body.classList.add('view-mode');const menuToggle=document.getElementById('menuToggle');menuToggle.onclick=()=>{const viewing=document.body.classList.toggle('view-mode');menuToggle.setAttribute('aria-expanded',String(!viewing));menuToggle.textContent=viewing?'☰ Menu':'✕ Fermer';};
let camera={scale:1,rotation:0,x:0,y:0};function applyCamera(){stage.style.transform='translate('+camera.x+'px,'+camera.y+'px) scale('+camera.scale+') rotate('+camera.rotation+'deg)';stage.querySelectorAll('.handle,.rotate-handle').forEach(h=>h.style.transform='scale('+(1/Math.max(.2,camera.scale))+')');status.textContent='Vue '+Math.round(camera.scale*100)+' % · gestes à deux doigts pour déplacer, zoomer et tourner la vue';document.getElementById('diag').textContent='Diagnostic · caméra '+Math.round(camera.scale*100)+' %';}function fitStage(){const zone=document.querySelector('.zone');const scale=Math.min(1,(zone.clientWidth-24)/doc.canvas.width,(zone.clientHeight-24)/doc.canvas.height);stage.style.width=Math.max(1,doc.canvas.width*scale)+'px';stage.style.height=Math.max(1,doc.canvas.height*scale)+'px';applyCamera()}fitStage();window.addEventListener('resize',fitStage);document.getElementById('dim').textContent=doc.canvas.width+' × '+doc.canvas.height+' px';document.getElementById('zoomIn').onclick=()=>{camera.scale=Math.min(32,camera.scale*1.25);applyCamera()};document.getElementById('zoomOut').onclick=()=>{camera.scale=Math.max(.05,camera.scale/1.25);applyCamera()};document.getElementById('rotateView').onclick=()=>{camera.rotation=(camera.rotation+90)%360;applyCamera()};document.getElementById('resetView').onclick=()=>{camera={scale:1,rotation:0,x:0,y:0};applyCamera()};document.getElementById('fullscreen').onclick=async()=>{try{if(!document.fullscreenElement)await document.documentElement.requestFullscreen();else await document.exitFullscreen()}catch(e){status.textContent='Plein écran non pris en charge par ce navigateur.'}};
function byId(id){return visibleItems.find(x=>x.id===id)}function sourceFor(item){return mediaSources[item.id]}
function screenToStage(x,y){const z=document.querySelector('.zone').getBoundingClientRect(),cx=z.left+z.width/2+camera.x,cy=z.top+z.height/2+camera.y,dx=(x-cx)/camera.scale,dy=(y-cy)/camera.scale,a=-camera.rotation*Math.PI/180;return{x:stage.clientWidth/2+dx*Math.cos(a)-dy*Math.sin(a),y:stage.clientHeight/2+dx*Math.sin(a)+dy*Math.cos(a)}}
let cameraGesture=null;stage.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'&&e.button!==0)return;if(!cameraGesture)cameraGesture={points:new Map(),start:{...camera},pointerType:e.pointerType,panAllowed:(document.body.classList.contains('view-mode')&&!e.target.closest('video'))||e.target===stage,origin:{x:e.clientX,y:e.clientY}};cameraGesture.points.set(e.pointerId,{x:e.clientX,y:e.clientY});});window.addEventListener('pointermove',e=>{if(!cameraGesture||!cameraGesture.points.has(e.pointerId))return;cameraGesture.points.set(e.pointerId,{x:e.clientX,y:e.clientY});if(cameraGesture.points.size===1&&cameraGesture.panAllowed&&Math.hypot(e.clientX-cameraGesture.origin.x,e.clientY-cameraGesture.origin.y)>4){camera.x=cameraGesture.start.x+e.clientX-cameraGesture.origin.x;camera.y=cameraGesture.start.y+e.clientY-cameraGesture.origin.y;applyCamera()}if(cameraGesture.points.size>=2){const pts=[...cameraGesture.points.values()],a=pts[0],b=pts[1],span=Math.hypot(b.x-a.x,b.y-a.y),ang=Math.atan2(b.y-a.y,b.x-a.x)*180/Math.PI;if(!cameraGesture.initial){cameraGesture.initial={span,ang,mid:{x:(a.x+b.x)/2,y:(a.y+b.y)/2},camera:{...camera}}}const z=cameraGesture.initial;camera.scale=Math.max(.05,Math.min(32,z.camera.scale*span/Math.max(1,z.span)));camera.rotation=z.camera.rotation+(ang-z.ang);camera.x=z.camera.x+((a.x+b.x)/2-z.mid.x);camera.y=z.camera.y+((a.y+b.y)/2-z.mid.y);applyCamera()}});function endCameraPointer(e){if(cameraGesture){cameraGesture.points.delete(e.pointerId);if(cameraGesture.points.size===0)cameraGesture=null;else{const p=[...cameraGesture.points.values()][0];cameraGesture.start={...camera};cameraGesture.origin={x:p.x,y:p.y};cameraGesture.initial=null}}}window.addEventListener('pointerup',endCameraPointer);window.addEventListener('pointercancel',endCameraPointer);
const iosVideoUrls=new Map();async function resolveVideoSource(item){const source=sourceFor(item);const ios=/iPhone|iPad|iPod/i.test(navigator.userAgent);if(!ios||!source.startsWith('data:video/'))return source;if(iosVideoUrls.has(item.id))return iosVideoUrls.get(item.id);const blob=await (await fetch(source)).blob();const url=URL.createObjectURL(blob);iosVideoUrls.set(item.id,url);return url;}function loadVideo(video,item){if(video.dataset.ready==='1')return Promise.resolve(video);if(video._loadPromise)return video._loadPromise;video.dataset.loading='1';video._loadPromise=(async()=>{const src=await resolveVideoSource(item);return new Promise((resolve,reject)=>{const ready=()=>{video.dataset.ready='1';video.dataset.loading='';resolve(video)};const failed=()=>{video.dataset.loading='';reject(new Error('Lecture du média impossible'))};video.addEventListener('loadeddata',ready,{once:true});video.addEventListener('error',failed,{once:true});video.src=src;video.load()})})().catch(err=>{status.textContent='Vidéo illisible : '+err.message;throw err});return video._loadPromise;}
function select(id){selected=id;renderSelection()}
function renderSelection(){document.querySelectorAll('.item').forEach(e=>e.classList.toggle('active',e.dataset.id===selected));document.querySelectorAll('.layer').forEach(e=>e.classList.toggle('active',e.dataset.id===selected))}
function render(){stage.innerHTML='';rail.innerHTML='';visibleItems.forEach((item,index)=>{const box=document.createElement('div');box.className='item';box.dataset.id=item.id;box.style.left=(item.x*100)+'%';box.style.top=(item.y*100)+'%';box.style.width=(item.width*100)+'%';box.style.height=(item.height*100)+'%';box.style.setProperty('--rotation',(item.rotation||0)+'deg');box.style.zIndex=String(index+1);let media;if(item.kind==='video'){media=document.createElement('video');media.controls=true;media.preload='none';media.playsInline=true;media.poster=posterSources[item.id]||'';media.volume=Math.max(0,Math.min(1,Number(item.volume??1)));media.setAttribute('webkit-playsinline','');media.style.objectFit=item.fitMode||'cover';media.addEventListener('play',()=>{if(media.dataset.ready!=='1'){media.pause();loadVideo(media,item).then(()=>{const ios=/iPhone|iPad|iPod/i.test(navigator.userAgent);status.textContent=ios?'Vidéo préparée pour Safari · touchez à nouveau ▶ pour lancer la lecture.':'Vidéo prête · lancement…';if(!ios)media.play();}).catch(()=>{});return;}stage.querySelectorAll('video').forEach(other=>{if(other!==media)other.pause()});});media.addEventListener('error',()=>{status.textContent='Vidéo illisible dans ce navigateur ou format non pris en charge.'},{once:true});media.addEventListener('ended',()=>{const u=iosVideoUrls.get(item.id);if(u){URL.revokeObjectURL(u);iosVideoUrls.delete(item.id);media.dataset.ready='';media.removeAttribute('src');media.load()}},{once:true})}else if(item.kind==='image'){media=document.createElement('img');media.loading='lazy';media.decoding='async';media.src=sourceFor(item);media.alt=item.displayName;media.style.objectFit=item.fitMode||'cover' }else{media=document.createElement('div');media.textContent=item.displayName}const cropW=Math.max(.05,Number(item.cropRight??1)-Number(item.cropLeft??0)),cropH=Math.max(.05,Number(item.cropBottom??1)-Number(item.cropTop??0));media.style.position='absolute';media.style.width=(100/cropW)+'%';media.style.height=(100/cropH)+'%';media.style.left=(-Number(item.cropLeft??0)/cropW*100)+'%';media.style.top=(-Number(item.cropTop??0)/cropH*100)+'%';media.style.objectFit='fill';if(item.flipHorizontal||item.flipVertical)media.style.transform='scale('+(item.flipHorizontal?-1:1)+','+(item.flipVertical?-1:1)+')';box.appendChild(media);const handle=document.createElement('div');handle.className='handle';box.appendChild(handle);const rotateHandle=document.createElement('div');rotateHandle.className='rotate-handle';box.appendChild(rotateHandle);box.addEventListener('pointerdown',e=>{if(document.body.classList.contains('view-mode'))return;if(e.target===media&&item.kind==='video')return;e.preventDefault();select(item.id);box.setPointerCapture(e.pointerId);const p0=screenToStage(e.clientX,e.clientY);const sx=doc.canvas.width/stage.clientWidth,sy=doc.canvas.height/stage.clientHeight;const x0=p0.x,y0=p0.y,ox=item.x,oy=item.y,ow=item.width,oh=item.height;const mode=e.target===handle?'resize':e.target===rotateHandle?'rotate':'move';const cx=item.x*stage.clientWidth,cy=item.y*stage.clientHeight;const a0=Math.atan2(y0-cy,x0-cx),rot0=item.rotation||0;function move(ev){if(cameraGesture&&cameraGesture.points.size>=2)return;const pp=screenToStage(ev.clientX,ev.clientY);if(mode==='rotate'){const a=Math.atan2(pp.y-cy,pp.x-cx);item.rotation=rot0+(a-a0)*180/Math.PI;box.style.setProperty('--rotation',item.rotation+'deg')}else if(mode==='resize'){const dx=pp.x-x0,dy=pp.y-y0,rad=-(item.rotation||0)*Math.PI/180,lx=dx*Math.cos(rad)-dy*Math.sin(rad),ly=dx*Math.sin(rad)+dy*Math.cos(rad);item.width=Math.max(.02,Math.min(2,ow+lx*sx/doc.canvas.width*2));item.height=Math.max(.02,Math.min(2,oh+ly*sy/doc.canvas.height*2));box.style.width=(item.width*100)+'%';box.style.height=(item.height*100)+'%'}else{item.x=Math.max(-.5,Math.min(1.5,ox+(pp.x-x0)*sx/doc.canvas.width));item.y=Math.max(-.5,Math.min(1.5,oy+(pp.y-y0)*sy/doc.canvas.height));box.style.left=(item.x*100)+'%';box.style.top=(item.y*100)+'%'}}function end(){box.removeEventListener('pointermove',move);box.removeEventListener('pointerup',end);box.removeEventListener('pointercancel',end)}box.addEventListener('pointermove',move);box.addEventListener('pointerup',end);box.addEventListener('pointercancel',end)});stage.appendChild(box);
const tile=document.createElement('button');tile.className='layer';tile.dataset.id=item.id;tile.textContent=(index+1)+'. '+(item.kind==='video'?'▶ ':'▧ ')+item.displayName;tile.onclick=()=>select(item.id);rail.prepend(tile)});renderSelection();if(!visibleItems.length){stage.innerHTML='<div style="color:#9AACB0;padding:20px">Projet vide</div>'}}
function moveLayer(d){const i=visibleItems.findIndex(x=>x.id===selected);if(i<0)return;const j=Math.max(0,Math.min(visibleItems.length-1,i+d));if(i!==j){const a=visibleItems.splice(i,1)[0];visibleItems.splice(j,0,a);render()}}
function scaleItem(f){const x=byId(selected);if(!x)return;x.width=Math.max(.04,Math.min(1.8,x.width*f));x.height=Math.max(.04,Math.min(1.8,x.height*f));render()}
document.getElementById('up').onclick=()=>moveLayer(1);document.getElementById('down').onclick=()=>moveLayer(-1);document.getElementById('bigger').onclick=()=>scaleItem(1.1);document.getElementById('smaller').onclick=()=>scaleItem(.9);document.getElementById('reset').onclick=()=>{const x=byId(selected);if(x){x.x=.5;x.y=.5;render()}};let playlistActive=false,playlistPaused=false,playlistCurrent=null,stopResolve=null;const playAllButton=document.getElementById('playAll'),playMainButton=document.getElementById('playMain');function syncPlaylistButton(){const label=playlistActive&&!playlistPaused?'■ Stop':'▶ Lire';playAllButton.textContent=label;playMainButton.textContent=playlistActive&&!playlistPaused?'■':'▶';playMainButton.setAttribute('aria-label',playlistActive&&!playlistPaused?'Arrêter la séquence':'Lire les vidéos')}document.getElementById('pauseAll').onclick=()=>{if(!playlistActive)return;playlistPaused=true;if(playlistCurrent)playlistCurrent.pause();syncPlaylistButton();status.textContent='Séquence en pause'};playAllButton.onclick=async()=>{if(playlistActive&&!playlistPaused){playlistActive=false;playlistPaused=false;if(playlistCurrent){playlistCurrent.pause();playlistCurrent.currentTime=0;}if(stopResolve)stopResolve();syncPlaylistButton();status.textContent='Séquence arrêtée · retour au début';return;}if(playlistActive&&playlistPaused){playlistPaused=false;if(playlistCurrent)await playlistCurrent.play();syncPlaylistButton();status.textContent='Séquence reprise';return;}playlistActive=true;playlistPaused=false;syncPlaylistButton();let resolveStop;const stopPromise=new Promise(resolve=>resolveStop=resolve);stopResolve=resolveStop;for(const item of visibleItems.filter(x=>x.kind==='video').sort((a,b)=>(a.videoOrder??0)-(b.videoOrder??0))){if(!playlistActive)break;const v=[...stage.querySelectorAll('.item')].find(e=>e.dataset.id===item.id)?.querySelector('video');if(!v)continue;try{await loadVideo(v,item);if(!playlistActive)break;playlistCurrent=v;v.currentTime=Math.max(0,Number(item.trimStartMs||0)/1000);await v.play();await Promise.race([new Promise(resolve=>{const done=()=>{v.removeEventListener('timeupdate',check);resolve()};const check=()=>{const end=Number(item.trimEndMs||0)/1000;if(end>0&&v.currentTime>=end){v.pause();done()}};v.addEventListener('ended',done,{once:true});v.addEventListener('timeupdate',check)}),stopPromise]);v.pause();}catch(e){status.textContent='Lecture vidéo impossible : '+e.message;break;}}playlistActive=false;playlistPaused=false;playlistCurrent=null;stopResolve=null;syncPlaylistButton();};playMainButton.onclick=()=>playAllButton.click();document.getElementById('pauseMain').onclick=()=>document.getElementById('pauseAll').click();document.getElementById('recenterMain').onclick=()=>document.getElementById('resetView').click();syncPlaylistButton();render();
</script></body></html>""")
                }
                if (tempHtml.length() < 1000L) throw IOException("Le HTML généré est anormalement petit.")
                val tail = ByteArray(14)
                tempHtml.inputStream().use { input ->
                    var skipped = 0L
                    while (skipped < tempHtml.length() - tail.size) {
                        val n = input.skip(tempHtml.length() - tail.size - skipped)
                        if (n <= 0) break
                        skipped += n
                    }
                    var offset = 0
                    while (offset < tail.size) {
                        val n = input.read(tail, offset, tail.size - offset)
                        if (n < 0) break
                        offset += n
                    }
                    if (offset != tail.size || String(tail, Charsets.UTF_8) != "</body></html>") {
                        throw IOException("Le HTML temporaire est incomplet : fermeture du document absente.")
                    }
                }
                val copied = tempHtml.inputStream().buffered(64 * 1024).use { input ->
                    contentResolver.openOutputStream(uri, "wt")?.use { output -> input.copyTo(output, 64 * 1024) }
                        ?: throw IOException("Impossible d'écrire le fichier HTML.")
                }
                if (copied != tempHtml.length()) throw IOException("Copie HTML incomplète : $copied / ${tempHtml.length()} octets.")
                runOnUiThread { status.text = "HTML autonome créé et vérifié : ${tempHtml.length() / 1024} Ko. Médias intégrés." }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Export HTML échoué : ${e.message}" }
            } finally {
                prepared.forEach { it.delete() }
                tempHtml.delete()
                runOnUiThread { progress.visibility = View.GONE }
            }
        }
    }

    private fun JSONObjectQuote(value: String): String = org.json.JSONObject.quote(value)

    private fun prepareHtmlImage(source: File, mimeType: String, profile: HtmlExportProfile): File {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(source.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IOException("Image illisible : ${source.name}")
        val maxSide = profile.photoMaxSide
        val largest = max(bounds.outWidth, bounds.outHeight)
        if (largest <= maxSide) return source
        var sample = 1
        while (largest / sample > maxSide * 1.5f) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
        var bitmap = BitmapFactory.decodeFile(source.absolutePath, options) ?: throw IOException("Impossible de réduire : ${source.name}")
        try {
            val maxSide = max(bitmap.width, bitmap.height)
            if (maxSide > profile.photoMaxSide) {
                val scale = profile.photoMaxSide.toFloat() / maxSide
                val scaled = Bitmap.createScaledBitmap(bitmap, (bitmap.width * scale).toInt().coerceAtLeast(1), (bitmap.height * scale).toInt().coerceAtLeast(1), true)
                if (scaled !== bitmap) { bitmap.recycle(); bitmap = scaled }
            }
            val orientation = try { ExifInterface(source.absolutePath).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) } catch (_: Exception) { ExifInterface.ORIENTATION_NORMAL }
            val matrix = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
                ExifInterface.ORIENTATION_TRANSPOSE -> { matrix.postScale(-1f, 1f); matrix.postRotate(90f) }
                ExifInterface.ORIENTATION_TRANSVERSE -> { matrix.postScale(-1f, 1f); matrix.postRotate(270f) }
            }
            if (!matrix.isIdentity()) {
                val oriented = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
                if (oriented !== bitmap) { bitmap.recycle(); bitmap = oriented }
            }
            val output = File(cacheDir, "html_${UUID.randomUUID()}.media")
            FileOutputStream(output).buffered().use { stream ->
                // Keep PNG lossless to preserve transparency; JPEG is quality-tuned per profile.
                val format = if (mimeType == "image/png") Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
                if (!bitmap.compress(format, profile.jpegQuality, stream)) throw IOException("Compression image échouée : ${source.name}")
            }
            return output
        } finally { bitmap.recycle() }
    }

    private fun importedSafeName(uri: Uri) = uri.lastPathSegment?.takeLast(28) ?: "média"
    private fun queryDisplayName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (_: Exception) { null }

    private fun safeDocName(s: String) = s.replace(Regex("[^A-Za-z0-9_-]"), "_").ifBlank { "MonProjet" }

    private inner class ProjectCanvasView : View(this@MainActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var active: ProjectItem? = null
        private var lastProjectX = 0f
        private var lastProjectY = 0f
        private var moveOriginX = 0f
        private var moveOriginY = 0f
        private var touchMoved = false
        private var touchDownX = 0f
        private var touchDownY = 0f
        private var resizeActive = false
        private var rotationActive = false
        private var resizeStartWidth = 0f
        private var resizeStartHeight = 0f
        private var resizeStartX = 0f
        private var resizeStartY = 0f
        private var rotateStartAngle = 0f
        private var rotateStartRotation = 0f
        private var zoom = 1f
        private var panX = 0f
        private var panY = 0f
        private var viewRotation = 0f
        private var gestureSpan = 0f
        private var gestureAngle = 0f
        private var gestureMidX = 0f
        private var gestureMidY = 0f
        private var gestureZoom = 1f
        private var gestureRotation = 0f
        private var gesturePanX = 0f
        private var gesturePanY = 0f
        private val viewMatrix = Matrix()
        private val inverseMatrix = Matrix()
        var onViewportChanged: (() -> Unit)? = null
        private var groupStart = emptyMap<String, FloatArray>()
        private var groupPivotX = 0f
        private var groupPivotY = 0f
        private var resizeStartDistance = 1f
        private var resizePivotX = 0f
        private var resizePivotY = 0f
        private var resizeCornerAnchor = false
        private var groupFrameResize = false

        fun setEditMode(enabled: Boolean) { editMode = enabled; invalidate(); onViewportChanged?.invoke() }
        fun cameraZoom(): Float = zoom

        fun adjustZoom(factor: Float) { zoom = (zoom * factor).coerceIn(0.2f, 8f); invalidate(); onViewportChanged?.invoke(); status.text = "Zoom de la vue : ${(zoom * 100).toInt()} %" }
        fun rotateViewport(degrees: Float) { viewRotation = (viewRotation + degrees) % 360f; invalidate(); onViewportChanged?.invoke() }
        fun resetViewport() { zoom = 1f; panX = 0f; panY = 0f; viewRotation = 0f; invalidate(); onViewportChanged?.invoke(); status.text = "Vue réinitialisée · contenu inchangé" }

        fun videoOverlayGeometry(item: ProjectItem): Pair<RectF, Float>? {
            if (width <= 0 || height <= 0) return null
            updateMatrix()
            val center = itemCenter(item)
            val point = floatArrayOf(center.first, center.second)
            viewMatrix.mapPoints(point)
            val w = item.width * doc.canvasWidth * baseScale() * zoom
            val h = item.height * doc.canvasHeight * baseScale() * zoom
            val rect = RectF(point[0] - w / 2f, point[1] - h / 2f, point[0] + w / 2f, point[1] + h / 2f)
            return rect to (item.rotation + viewRotation)
        }

        private fun rectLeft(item: ProjectItem): Float = itemCenter(item).first - item.width * doc.canvasWidth * baseScale() / 2f
        private fun baseScale(): Float = min(width.toFloat() / doc.canvasWidth.coerceAtLeast(1), height.toFloat() / doc.canvasHeight.coerceAtLeast(1)).coerceAtLeast(0.0001f)
        private fun baseLeft(): Float = (width - doc.canvasWidth * baseScale()) / 2f
        private fun baseTop(): Float = (height - doc.canvasHeight * baseScale()) / 2f
        private fun updateMatrix() {
            val cx = width / 2f; val cy = height / 2f
            val radians = Math.toRadians(viewRotation.toDouble())
            val a = zoom * kotlin.math.cos(radians).toFloat()
            val b = -zoom * kotlin.math.sin(radians).toFloat()
            val d = zoom * kotlin.math.sin(radians).toFloat()
            val e = zoom * kotlin.math.cos(radians).toFloat()
            viewMatrix.setValues(floatArrayOf(a, b, cx + panX - a * cx - b * cy, d, e, cy + panY - d * cx - e * cy, 0f, 0f, 1f))
            viewMatrix.invert(inverseMatrix)
        }
        private fun toProjectSpace(x: Float, y: Float): Pair<Float, Float> {
            updateMatrix()
            val pts = floatArrayOf(x, y); inverseMatrix.mapPoints(pts)
            return pts[0] to pts[1]
        }
        private fun itemCenter(item: ProjectItem): Pair<Float, Float> {
            val scale = baseScale()
            return (baseLeft() + item.x * doc.canvasWidth * scale) to (baseTop() + item.y * doc.canvasHeight * scale)
        }
        private fun localPoint(x: Float, y: Float, item: ProjectItem): Pair<Float, Float> {
            val (px, py) = toProjectSpace(x, y)
            val (cx, cy) = itemCenter(item)
            val radians = Math.toRadians((-item.rotation).toDouble())
            val dx = px - cx; val dy = py - cy
            return (dx * kotlin.math.cos(radians).toFloat() - dy * kotlin.math.sin(radians).toFloat() + cx) to
                (dx * kotlin.math.sin(radians).toFloat() + dy * kotlin.math.cos(radians).toFloat() + cy)
        }
        private fun midpoint(event: MotionEvent): Pair<Float, Float> =
            ((event.getX(0) + event.getX(1)) / 2f) to ((event.getY(0) + event.getY(1)) / 2f)
        private fun span(event: MotionEvent): Float = hypot((event.getX(1)-event.getX(0)).toDouble(), (event.getY(1)-event.getY(0)).toDouble()).toFloat().coerceAtLeast(1f)
        private fun angle(event: MotionEvent): Float = Math.toDegrees(atan2((event.getY(1)-event.getY(0)).toDouble(), (event.getX(1)-event.getX(0)).toDouble())).toFloat()
        private fun angleDelta(now: Float, before: Float): Float { var d = now-before; if (d > 180f) d-=360f; if (d < -180f) d+=360f; return d }

        fun drawLayersAbove(canvas: Canvas, videoId: String) {
            val index = doc.items.indexOfFirst { it.id == videoId }
            if (index < 0 || width <= 0 || height <= 0) return
            updateMatrix()
            canvas.save(); canvas.concat(viewMatrix)
            for (item in doc.items.drop(index + 1).filter { it.visible }) {
                val (cx, cy) = itemCenter(item)
                val w = item.width * doc.canvasWidth * baseScale()
                val h = item.height * doc.canvasHeight * baseScale()
                val rect = RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
                canvas.save(); canvas.rotate(item.rotation, cx, cy); canvas.scale(if(item.flipHorizontal) -1f else 1f, if(item.flipVertical) -1f else 1f, cx, cy)
                val bitmap = ThumbnailCache.get(item.id)
                if (bitmap == null) {
                    // Do not let the playing video shine through an upper layer
                    // while that layer's preview is still being decoded.
                    val file = mediaFiles[item.id]
                    if (file != null && !ThumbnailCache.isPending(item.id)) requestThumbnail(item.id, file, item.kind)
                    paint.color = Color.rgb(24, 34, 37)
                    canvas.drawRoundRect(rect, 8f, 8f, paint)
                    canvas.restore()
                    continue
                }
                if (item.cropLeft > 0f || item.cropTop > 0f || item.cropRight < 1f || item.cropBottom < 1f) {
                    val src = Rect(
                        (bitmap.width * item.cropLeft).toInt().coerceIn(0, bitmap.width - 1),
                        (bitmap.height * item.cropTop).toInt().coerceIn(0, bitmap.height - 1),
                        (bitmap.width * item.cropRight).toInt().coerceIn(1, bitmap.width),
                        (bitmap.height * item.cropBottom).toInt().coerceIn(1, bitmap.height)
                    )
                    canvas.drawBitmap(bitmap, src, rect, paint)
                } else drawFittedBitmap(canvas, bitmap, rect, paint, item.fitMode)
                canvas.restore()
            }
            canvas.restore()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.rgb(24, 34, 37))
            val scale = baseScale()
            val left = baseLeft(); val top = baseTop()
            updateMatrix()
            canvas.save(); canvas.concat(viewMatrix)
            val projectRect = RectF(left, top, left + doc.canvasWidth * scale, top + doc.canvasHeight * scale)
            paint.color = Color.rgb(15, 21, 23); canvas.drawRect(projectRect, paint)
            doc.items.filter { it.visible }.forEach { item ->
                val (cx, cy) = itemCenter(item)
                // x/y/width/height are normalized against the PROJECT dimensions, never the phone View dimensions.
                val w = item.width * doc.canvasWidth * scale
                val h = item.height * doc.canvasHeight * scale
                val rect = RectF(cx-w/2, cy-h/2, cx+w/2, cy+h/2)
                canvas.save(); canvas.rotate(item.rotation, cx, cy); canvas.scale(if(item.flipHorizontal) -1f else 1f, if(item.flipVertical) -1f else 1f, cx, cy)
                val file = mediaFiles[item.id]
                if (file == null || item.kind != "image") {
                    paint.color = if (item.id in selectedIds || item.id == selectedId) Color.rgb(35, 48, 54) else Color.rgb(31, 43, 47)
                    canvas.drawRoundRect(rect, 8f, 8f, paint)
                }
                if (file != null && (item.kind == "image" || item.kind == "video")) {
                    val thumb = ThumbnailCache.get(item.id)
                    if (thumb != null) {
                        paint.color = Color.WHITE
                        if (item.cropLeft > 0f || item.cropTop > 0f || item.cropRight < 1f || item.cropBottom < 1f) {
                            val src = Rect((thumb.width*item.cropLeft).toInt().coerceIn(0,thumb.width-1), (thumb.height*item.cropTop).toInt().coerceIn(0,thumb.height-1), (thumb.width*item.cropRight).toInt().coerceIn(1,thumb.width), (thumb.height*item.cropBottom).toInt().coerceIn(1,thumb.height))
                            canvas.drawBitmap(thumb, src, rect, paint)
                        } else drawFittedBitmap(canvas, thumb, rect, paint, item.fitMode)
                    } else {
                        if (!ThumbnailCache.isPending(item.id)) requestThumbnail(item.id, file, item.kind)
                        paint.color = Color.rgb(34, 48, 52)
                        canvas.drawRoundRect(rect, 8f, 8f, paint)
                        paint.color = Color.rgb(135, 159, 157); paint.textSize = 12f
                        canvas.drawText("Préparation…", rect.left + 8f, rect.centerY(), paint)
                    }
                } else drawLabel(canvas, item, rect)
                val isSelected = item.id in selectedIds || item.id == selectedId
                paint.style = Paint.Style.STROKE; paint.strokeWidth = if (isSelected) 4f else 1.5f
                paint.color = if (isSelected) Color.rgb(227, 168, 87) else Color.rgb(50, 64, 70)
                canvas.drawRoundRect(rect, 8f, 8f, paint); paint.style = Paint.Style.FILL
                if (item.id == selectedId && editMode && !cropMode) {
                    paint.color = Color.rgb(227, 168, 87)
                    listOf(rect.left to rect.top, rect.right to rect.top, rect.left to rect.bottom, rect.right to rect.bottom).forEach { canvas.drawCircle(it.first, it.second, 9f / zoom, paint) }
                    canvas.drawCircle(rect.left, rect.centerY(), 8f / zoom, paint); canvas.drawCircle(rect.right, rect.centerY(), 8f / zoom, paint)
                    canvas.drawCircle(rect.centerX(), rect.top, 8f / zoom, paint); canvas.drawCircle(rect.centerX(), rect.bottom, 8f / zoom, paint)
                    paint.color = Color.rgb(117, 197, 180)
                    canvas.drawLine(rect.right, rect.top, rect.right+24f, rect.top-24f, paint)
                    canvas.drawCircle(rect.right+32f/zoom, rect.top-32f/zoom, 12f/zoom, paint)
                    paint.color = Color.rgb(24, 34, 37); canvas.drawCircle(rect.right+32f/zoom, rect.top-32f/zoom, 4f/zoom, paint)
                }
                if (cropMode && item.id == selectedId) {
                    val cropRect = RectF(rect.left + rect.width()*item.cropLeft, rect.top + rect.height()*item.cropTop,
                        rect.left + rect.width()*item.cropRight, rect.top + rect.height()*item.cropBottom)
                    paint.color = Color.argb(145, 8, 13, 15)
                    canvas.drawRect(rect.left, rect.top, cropRect.left, rect.bottom, paint)
                    canvas.drawRect(cropRect.right, rect.top, rect.right, rect.bottom, paint)
                    canvas.drawRect(cropRect.left, rect.top, cropRect.right, cropRect.top, paint)
                    canvas.drawRect(cropRect.left, cropRect.bottom, cropRect.right, rect.bottom, paint)
                    paint.color = Color.rgb(240, 190, 104); paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f
                    canvas.drawRect(cropRect, paint)
                    paint.strokeWidth = 1.2f
                    for (i in 1..2) {
                        val gx = cropRect.left + cropRect.width()*i/3f; val gy = cropRect.top + cropRect.height()*i/3f
                        canvas.drawLine(gx, cropRect.top, gx, cropRect.bottom, paint)
                        canvas.drawLine(cropRect.left, gy, cropRect.right, gy, paint)
                    }
                    paint.style = Paint.Style.FILL
                    listOf(cropRect.left to cropRect.top, cropRect.right to cropRect.top, cropRect.left to cropRect.bottom, cropRect.right to cropRect.bottom).forEach { canvas.drawCircle(it.first,it.second,9f,paint) }
                }
                canvas.restore()
            }
            val selectedVisible = doc.items.filter { it.visible && it.id in selectedIds }
            if (editMode && selectedVisible.size > 1 && !cropMode) {
                val bounds=RectF(); var first=true
                selectedVisible.forEach { itx ->
                    val (gx,gy)=itemCenter(itx); val gw=itx.width*doc.canvasWidth*scale; val gh=itx.height*doc.canvasHeight*scale
                    val r=RectF(gx-gw/2f,gy-gh/2f,gx+gw/2f,gy+gh/2f)
                    if(first){bounds.set(r);first=false}else bounds.union(r)
                }
                paint.style=Paint.Style.STROKE; paint.strokeWidth=2f/zoom; paint.color=Color.rgb(117,197,180)
                canvas.drawRect(bounds,paint); paint.style=Paint.Style.FILL
                paint.color=Color.rgb(117,197,180)
                listOf(bounds.left to bounds.top,bounds.right to bounds.top,bounds.left to bounds.bottom,bounds.right to bounds.bottom).forEach { canvas.drawCircle(it.first,it.second,9f/zoom,paint) }
            }
            if (doc.items.none { it.visible }) {
                paint.color = Color.rgb(154, 172, 176); paint.textSize = 18f
                canvas.drawText("Espace de composition", projectRect.left + 24f, projectRect.centerY(), paint)
                paint.textSize = 13f; canvas.drawText("Utilise « Importer » pour ajouter des médias", projectRect.left + 24f, projectRect.centerY()+26f, paint)
            }
            canvas.restore()
            paint.color = Color.rgb(154, 172, 176); paint.textSize = 11f
            canvas.drawText("${(zoom*100).toInt()} % · vue indépendante du projet", 12f, height-12f, paint)
        }
        private fun requestThumbnail(itemId: String, file: File, kind: String) {
            if (isOpeningProject || !queuedThumbnailIds.add(itemId)) return
            val item = doc.items.firstOrNull { it.id == itemId }
            val posterTime = item?.posterTimeMs ?: 0L
            val expectedWidth = item?.sourceWidth ?: 0
            val expectedHeight = item?.sourceHeight ?: 0
            thumbnailExecutor.execute {
                try {
                    if (kind == "video") {
                        ThumbnailCache.generateVideoFrameAt(itemId, file, posterTime, expectedWidth, expectedHeight) ?: ThumbnailCache.generate(itemId, file, kind)
                    } else ThumbnailCache.generate(itemId, file, kind)
                } finally {
                    queuedThumbnailIds.remove(itemId)
                    post { invalidate(); if (::occlusionView.isInitialized) occlusionView.invalidate() }
                }
            }
        }
        private fun coverSourceRect(bitmap: Bitmap, destination: RectF): Rect {
            val sourceAspect = bitmap.width.toFloat() / bitmap.height.coerceAtLeast(1)
            val targetAspect = destination.width() / destination.height().coerceAtLeast(1f)
            return if (sourceAspect > targetAspect) {
                val cropWidth = (bitmap.height * targetAspect).toInt().coerceIn(1, bitmap.width)
                val left = (bitmap.width - cropWidth) / 2
                Rect(left, 0, left + cropWidth, bitmap.height)
            } else {
                val cropHeight = (bitmap.width / targetAspect).toInt().coerceIn(1, bitmap.height)
                val top = (bitmap.height - cropHeight) / 2
                Rect(0, top, bitmap.width, top + cropHeight)
            }
        }
        private fun drawLabel(canvas: Canvas, item: ProjectItem, rect: RectF) {
            paint.color = Color.rgb(154, 172, 176); paint.textSize = 15f
            val label = (if (item.kind == "video") "▶ " else if (item.kind == "image") "▧ " else "▤ ") + item.displayName
            canvas.drawText(if (label.length > 22) label.take(19)+"…" else label, rect.left+8f, rect.centerY(), paint)
        }
        private fun handleCropTouch(event: MotionEvent): Boolean {
            val item = doc.items.firstOrNull { it.id == selectedId && it.visible } ?: return true
            val local = localPoint(event.x, event.y, item)
            val center = itemCenter(item)
            val w = item.width * doc.canvasWidth * baseScale()
            val h = item.height * doc.canvasHeight * baseScale()
            val left = center.first - w / 2f; val top = center.second - h / 2f
            val right = center.first + w / 2f; val bottom = center.second + h / 2f
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    gestureHistoryBefore = doc.toJson().toString()
                    val x = ((local.first - left) / w).coerceIn(0f, 1f)
                    val y = ((local.second - top) / h).coerceIn(0f, 1f)
                    val edge = 0.07f
                    cropDragMode = when {
                        kotlin.math.abs(x-item.cropLeft) < edge && kotlin.math.abs(y-item.cropTop) < edge -> "topLeft"
                        kotlin.math.abs(x-item.cropRight) < edge && kotlin.math.abs(y-item.cropTop) < edge -> "topRight"
                        kotlin.math.abs(x-item.cropLeft) < edge && kotlin.math.abs(y-item.cropBottom) < edge -> "bottomLeft"
                        kotlin.math.abs(x-item.cropRight) < edge && kotlin.math.abs(y-item.cropBottom) < edge -> "bottomRight"
                        kotlin.math.abs(x-item.cropLeft) < edge && y in item.cropTop..item.cropBottom -> "stretchLeft"
                        kotlin.math.abs(x-item.cropRight) < edge && y in item.cropTop..item.cropBottom -> "stretchRight"
                        kotlin.math.abs(y-item.cropTop) < edge && x in item.cropLeft..item.cropRight -> "stretchTop"
                        kotlin.math.abs(y-item.cropBottom) < edge && x in item.cropLeft..item.cropRight -> "stretchBottom"
                        x in item.cropLeft..item.cropRight && y in item.cropTop..item.cropBottom -> "move"
                        else -> "move"
                    }
                    cropLastX = x; cropLastY = y; cropStartX=x; cropStartY=y; return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val x = ((local.first - left) / w).coerceIn(0f, 1f)
                    val y = ((local.second - top) / h).coerceIn(0f, 1f)
                    val dx = x - cropLastX; val dy = y - cropLastY
                    when (cropDragMode) {
                        "stretchLeft", "stretchRight" -> {
                            val original=cropOriginal ?: floatArrayOf(item.cropLeft,item.cropTop,item.cropRight,item.cropBottom,item.width,item.height,item.x,item.y)
                            val totalDx=x-cropStartX; val sign=if(cropDragMode=="stretchRight") 1f else -1f
                            val delta=totalDx*original[4]; val newWidth=(original[4]+sign*delta).coerceAtLeast(0.01f)
                            item.width=newWidth; item.x=original[6]+delta/2f
                        }
                        "stretchTop", "stretchBottom" -> {
                            val original=cropOriginal ?: floatArrayOf(item.cropLeft,item.cropTop,item.cropRight,item.cropBottom,item.width,item.height,item.x,item.y)
                            val totalDy=y-cropStartY; val sign=if(cropDragMode=="stretchBottom") 1f else -1f
                            val delta=totalDy*original[5]; val newHeight=(original[5]+sign*delta).coerceAtLeast(0.01f)
                            item.height=newHeight; item.y=original[7]+delta/2f
                        }
                        "topLeft" -> { item.cropLeft = (item.cropLeft + dx).coerceIn(0f,item.cropRight-.05f); item.cropTop = (item.cropTop + dy).coerceIn(0f,item.cropBottom-.05f) }
                        "topRight" -> { item.cropRight = (item.cropRight + dx).coerceIn(item.cropLeft+.05f,1f); item.cropTop = (item.cropTop + dy).coerceIn(0f,item.cropBottom-.05f) }
                        "bottomLeft" -> { item.cropLeft = (item.cropLeft + dx).coerceIn(0f,item.cropRight-.05f); item.cropBottom = (item.cropBottom + dy).coerceIn(item.cropTop+.05f,1f) }
                        "bottomRight" -> { item.cropRight = (item.cropRight + dx).coerceIn(item.cropLeft+.05f,1f); item.cropBottom = (item.cropBottom + dy).coerceIn(item.cropTop+.05f,1f) }
                        "left" -> item.cropLeft = (item.cropLeft + dx).coerceIn(0f, item.cropRight - .05f)
                        "right" -> item.cropRight = (item.cropRight + dx).coerceIn(item.cropLeft + .05f, 1f)
                        "top" -> item.cropTop = (item.cropTop + dy).coerceIn(0f, item.cropBottom - .05f)
                        "bottom" -> item.cropBottom = (item.cropBottom + dy).coerceIn(item.cropTop + .05f, 1f)
                        else -> {
                            val width = item.cropRight - item.cropLeft; val height = item.cropBottom - item.cropTop
                            val newLeft = (item.cropLeft + dx).coerceIn(0f, 1f-width)
                            val newTop = (item.cropTop + dy).coerceIn(0f, 1f-height)
                            item.cropLeft = newLeft; item.cropRight = newLeft + width
                            item.cropTop = newTop; item.cropBottom = newTop + height
                        }
                    }
                    cropLastX = x; cropLastY = y; invalidate(); onViewportChanged?.invoke(); return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    gestureHistoryBefore?.let { before -> if(before!=doc.toJson().toString()) { if(undoStates.lastOrNull()!=before) undoStates.addLast(before); while(undoStates.size>40) undoStates.removeFirst(); redoStates.clear() } }
                    gestureHistoryBefore=null; cropDragMode = ""; return true
                }
            }
            return true
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (cropMode) return handleCropTouch(event)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    gestureHistoryBefore = doc.toJson().toString()
                    active = null; resizeActive = false; rotationActive = false; groupFrameResize=false; touchMoved = false
                    touchDownX = event.x; touchDownY = event.y
                    val (px, py) = toProjectSpace(event.x, event.y)
                    active = doc.items.asReversed().firstOrNull { item ->
                        if (!item.visible) return@firstOrNull false
                        val (lx, ly) = localPoint(event.x, event.y, item)
                        val (cx, cy) = itemCenter(item)
                        val w = item.width * doc.canvasWidth * baseScale(); val h = item.height * doc.canvasHeight * baseScale()
                        val inside = lx in (cx-w/2)..(cx+w/2) && ly in (cy-h/2)..(cy+h/2)
                        val handles = editMode && (
                            hypot(lx-(cx+w/2+32f/zoom), ly-(cy-h/2-32f/zoom)) <= 32f / zoom ||
                            listOf(cx-w/2 to cy-h/2, cx+w/2 to cy-h/2, cx-w/2 to cy+h/2, cx+w/2 to cy+h/2).any { hypot(lx-it.first, ly-it.second) <= 28f / zoom } ||
                            hypot(lx-(cx-w/2), ly-cy) <= 28f / zoom || hypot(lx-(cx+w/2), ly-cy) <= 28f / zoom ||
                            hypot(lx-cx, ly-(cy-h/2)) <= 28f / zoom || hypot(lx-cx, ly-(cy+h/2)) <= 28f / zoom
                        )
                        inside || handles
                    }
                    if(active==null && editMode && selectedIds.size>1) {
                        val groupItems=doc.items.filter { it.visible && it.id in selectedIds }
                        if(groupItems.isNotEmpty()) {
                            var l=Float.POSITIVE_INFINITY; var t=Float.POSITIVE_INFINITY; var r=Float.NEGATIVE_INFINITY; var b=Float.NEGATIVE_INFINITY
                            groupItems.forEach { gi -> val (gx,gy)=itemCenter(gi); val gw=gi.width*doc.canvasWidth*baseScale(); val gh=gi.height*doc.canvasHeight*baseScale(); l=min(l,gx-gw/2); r=max(r,gx+gw/2); t=min(t,gy-gh/2); b=max(b,gy+gh/2) }
                            val (gpX,gpY)=toProjectSpace(event.x,event.y)
                            val inside=gpX in l..r && gpY in t..b
                            val rotateHit=hypot(gpX-(r+32f/zoom),gpY-(t-32f/zoom))<=30f/zoom
                            val corner= listOf(l to t,r to t,l to b,r to b).firstOrNull { hypot(gpX-it.first,gpY-it.second)<=26f/zoom }
                            if(inside || rotateHit || corner!=null) {
                                active=doc.items.firstOrNull { it.id==selectedId } ?: groupItems.last()
                                groupFrameResize=corner!=null
                                if(corner!=null) {
                                    resizeActive=true; resizeAxis="both"; resizeCornerAnchor=true
                                    resizePivotX=if(corner.first==l) r else l; resizePivotY=if(corner.second==t) b else t
                                    resizeStartDistance=hypot(gpX-resizePivotX,gpY-resizePivotY).coerceAtLeast(1f)
                                } else if(rotateHit) {
                                    rotationActive=true
                                    groupPivotX=groupItems.map { itemCenter(it).first }.average().toFloat()
                                    groupPivotY=groupItems.map { itemCenter(it).second }.average().toFloat()
                                    rotateStartAngle=Math.toDegrees(atan2((gpY-groupPivotY).toDouble(),(gpX-groupPivotX).toDouble())).toFloat()
                                }
                            }
                        }
                    }
                    active?.let { item ->
                        // In Modifier, touching another layer once must not steal the current selection.
                        // A second tap on that layer changes the target while staying in Modifier.
                        if (editMode && item.id in selectedIds) selectedId = item.id
                    }
                    refreshLayerStrip()
                    onViewportChanged?.invoke()
                    val groupItems = doc.items.filter { it.visible && it.id in selectedIds }
                    groupStart = groupItems.associate { it.id to floatArrayOf(it.x, it.y, it.width, it.height, it.rotation) }
                    groupPivotX = if (groupItems.isNotEmpty()) groupItems.map { itemCenter(it).first }.average().toFloat() else 0f
                    groupPivotY = if (groupItems.isNotEmpty()) groupItems.map { itemCenter(it).second }.average().toFloat() else 0f
                    active?.let { item ->
                        if(groupFrameResize || rotationActive || resizeActive) { /* global group frame already selected */ } else {
                        val (lx, ly) = localPoint(event.x, event.y, item); val (cx, cy) = itemCenter(item)
                        val w = item.width * doc.canvasWidth * baseScale(); val h = item.height * doc.canvasHeight * baseScale()
                        val right = cx+w/2; val bottom = cy+h/2; val top = cy-h/2
                        val (pointerX, pointerY) = toProjectSpace(event.x, event.y)
                        if (editMode && item.id in selectedIds && hypot(lx-(right+32f/zoom), ly-(top-32f/zoom)) <= 30f / zoom) {
                            rotationActive = true; rotateStartRotation = item.rotation
                            val pivotX = if (commonPivot) groupPivotX else cx
                            val pivotY = if (commonPivot) groupPivotY else cy
                            rotateStartAngle = Math.toDegrees(atan2((pointerY-pivotY).toDouble(), (pointerX-pivotX).toDouble())).toFloat()
                        } else if (editMode && item.id in selectedIds && listOf(cx-w/2 to cy-h/2, cx+w/2 to cy-h/2, cx-w/2 to cy+h/2, cx+w/2 to cy+h/2).any { hypot(lx-it.first,ly-it.second) <= 26f / zoom }) {
                            resizeActive=true; resizeAxis="both"; resizeStartWidth=item.width; resizeStartHeight=item.height
                            resizeStartX=pointerX; resizeStartY=pointerY
                            resizeCornerAnchor = selectedIds.size <= 1
                            if(resizeCornerAnchor) {
                                val leftSide = lx < cx; val topSide = ly < cy
                                val localAnchorX = cx + if(leftSide) w/2f else -w/2f
                                val localAnchorY = cy + if(topSide) h/2f else -h/2f
                                val rad=Math.toRadians(item.rotation.toDouble())
                                val ax=localAnchorX-cx; val ay=localAnchorY-cy
                                resizePivotX=cx+(ax*kotlin.math.cos(rad)-ay*kotlin.math.sin(rad)).toFloat()
                                resizePivotY=cy+(ax*kotlin.math.sin(rad)+ay*kotlin.math.cos(rad)).toFloat()
                            } else { resizePivotX=groupPivotX; resizePivotY=groupPivotY }
                            resizeStartDistance = hypot(pointerX-resizePivotX,pointerY-resizePivotY).coerceAtLeast(1f)
                        } else if (editMode && item.id in selectedIds && (hypot(lx-(cx-w/2),ly-cy) <= 24f / zoom || hypot(lx-(cx+w/2),ly-cy) <= 24f / zoom)) {
                            resizeActive=true; resizeAxis="x"; resizeStartWidth=item.width; resizeStartHeight=item.height
                            resizeStartX=pointerX; resizeStartY=pointerY
                            resizeSignX = if (hypot(lx-(cx-w/2),ly-cy) <= 24f / zoom) -1f else 1f
                        } else if (editMode && item.id in selectedIds && (hypot(lx-cx,ly-top) <= 24f / zoom || hypot(lx-cx,ly-bottom) <= 24f / zoom)) {
                            resizeActive=true; resizeAxis="y"; resizeStartWidth=item.width; resizeStartHeight=item.height
                            resizeStartX=pointerX; resizeStartY=pointerY
                            resizeSignY = if (hypot(lx-cx,ly-top) <= 24f / zoom) -1f else 1f
                        }
                        }
                    }
                    val (sx, sy) = toProjectSpace(event.x,event.y); lastProjectX=sx; lastProjectY=sy; moveOriginX=sx; moveOriginY=sy
                    invalidate(); return true
                }
                MotionEvent.ACTION_POINTER_DOWN -> {
                    if (event.pointerCount >= 2) {
                        resizeActive = false; rotationActive = false
                        gestureSpan=span(event); gestureAngle=angle(event); val (mx,my)=midpoint(event)
                        gestureMidX=mx; gestureMidY=my; gestureZoom=zoom; gestureRotation=viewRotation; gesturePanX=panX; gesturePanY=panY
                        val groupItems = doc.items.filter { it.visible && it.id in selectedIds }
                        groupStart = groupItems.associate { it.id to floatArrayOf(it.x,it.y,it.width,it.height,it.rotation) }
                        groupPivotX = if (groupItems.isNotEmpty()) groupItems.map { itemCenter(it).first }.average().toFloat() else 0f
                        groupPivotY = if (groupItems.isNotEmpty()) groupItems.map { itemCenter(it).second }.average().toFloat() else 0f
                    }
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (event.pointerCount >= 2) {
                        val (mx,my)=midpoint(event)
                        if (editMode && active != null && active!!.id in selectedIds) {
                            val targets = doc.items.filter { it.visible && it.id in selectedIds }
                            val factor = (span(event) / gestureSpan).coerceIn(0.1f, 10f)
                            val delta = angleDelta(angle(event), gestureAngle)
                            val pivotX = if (commonPivot) groupPivotX else itemCenter(active!!).first
                            val pivotY = if (commonPivot) groupPivotY else itemCenter(active!!).second
                            targets.forEach { target ->
                                val start = groupStart[target.id] ?: return@forEach
                                val sx = baseLeft() + start[0] * doc.canvasWidth * baseScale()
                                val sy = baseTop() + start[1] * doc.canvasHeight * baseScale()
                                if (commonPivot) {
                                    val dx=sx-pivotX; val dy=sy-pivotY; val rad=Math.toRadians(delta.toDouble())
                                    val nx=pivotX+(dx*kotlin.math.cos(rad)-dy*kotlin.math.sin(rad))*factor
                                    val ny=pivotY+(dx*kotlin.math.sin(rad)+dy*kotlin.math.cos(rad))*factor
                                    target.x=((nx-baseLeft())/(doc.canvasWidth*baseScale())).toFloat().coerceIn(-0.5f,1.5f)
                                    target.y=((ny-baseTop())/(doc.canvasHeight*baseScale())).toFloat().coerceIn(-0.5f,1.5f)
                                }
                                target.width=(start[2]*factor).coerceIn(0.02f,2f); target.height=(start[3]*factor).coerceIn(0.02f,2f)
                                target.rotation=start[4]+delta
                            }
                        } else {
                            zoom=(gestureZoom*span(event)/gestureSpan).coerceIn(0.2f,8f)
                            viewRotation=gestureRotation+angleDelta(angle(event),gestureAngle)
                            panX=gesturePanX+(mx-gestureMidX); panY=gesturePanY+(my-gestureMidY)
                        }
                        touchMoved=true; invalidate(); onViewportChanged?.invoke(); return true
                    }
                    if (hypot(event.x-touchDownX,event.y-touchDownY)>8f) touchMoved=true
                    val item=active
                    if (item == null || !editMode || item.id !in selectedIds) {
                        panX += event.x-touchDownX; panY += event.y-touchDownY
                        touchDownX=event.x; touchDownY=event.y
                    } else {
                        val (px,py)=toProjectSpace(event.x,event.y)
                        val group = doc.items.filter { it.visible && it.id in selectedIds }
                        if (rotationActive) {
                            val (itemCenterX, itemCenterY) = itemCenter(item)
                            val pivotX = if (commonPivot) groupPivotX else itemCenterX
                            val pivotY = if (commonPivot) groupPivotY else itemCenterY
                            val a = Math.toDegrees(atan2((py-pivotY).toDouble(),(px-pivotX).toDouble())).toFloat()
                            var delta = angleDelta(a, rotateStartAngle)
                            if (incrementEnabled) { val step = if (zoom >= 1.8f) 1f else 5f; delta = kotlin.math.round(delta / step) * step }
                            group.forEach { target ->
                                val start = groupStart[target.id] ?: return@forEach
                                if (commonPivot) {
                                    val startX = baseLeft() + start[0] * doc.canvasWidth * baseScale()
                                    val startY = baseTop() + start[1] * doc.canvasHeight * baseScale()
                                    val dx = startX - groupPivotX
                                    val dy = startY - groupPivotY
                                    val radians = Math.toRadians(delta.toDouble())
                                    val nx = groupPivotX + dx * kotlin.math.cos(radians).toFloat() - dy * kotlin.math.sin(radians).toFloat()
                                    val ny = groupPivotY + dx * kotlin.math.sin(radians).toFloat() + dy * kotlin.math.cos(radians).toFloat()
                                    target.x = ((nx - baseLeft()) / (doc.canvasWidth * baseScale())).coerceIn(-0.5f, 1.5f)
                                    target.y = ((ny - baseTop()) / (doc.canvasHeight * baseScale())).coerceIn(-0.5f, 1.5f)
                                }
                                target.rotation = start[4] + delta
                            }
                        } else if (resizeActive) {
                            val (itemCenterX, itemCenterY) = itemCenter(item)
                            val pivotX = if (commonPivot) groupPivotX else itemCenterX
                            val pivotY = if (commonPivot) groupPivotY else itemCenterY
                            val local = localPoint(event.x,event.y,item)
                            val factor = when (resizeAxis) {
                                "x" -> ((resizeStartWidth * doc.canvasWidth * baseScale() + (px-resizeStartX)*2f*resizeSignX) / (resizeStartWidth * doc.canvasWidth * baseScale()).coerceAtLeast(1f)).coerceIn(0.05f,10f)
                                "y" -> ((resizeStartHeight * doc.canvasHeight * baseScale() + (py-resizeStartY)*2f*resizeSignY) / (resizeStartHeight * doc.canvasHeight * baseScale()).coerceAtLeast(1f)).coerceIn(0.05f,10f)
                                else -> (hypot(px-resizePivotX, py-resizePivotY) / resizeStartDistance).coerceIn(0.1f, 10f)
                            }
                            group.forEach { target ->
                                val start = groupStart[target.id] ?: return@forEach
                                target.width = (start[2] * if (resizeAxis == "y") 1f else factor).coerceIn(0.01f, 4f)
                                target.height = (start[3] * if (resizeAxis == "x") 1f else factor).coerceIn(0.01f, 4f)
                                if (resizeAxis == "x" && target.id == item.id) {
                                    target.x = (start[0] + (px-resizeStartX)/(doc.canvasWidth*baseScale())).coerceIn(-0.5f,1.5f)
                                } else if (resizeAxis == "y" && target.id == item.id) {
                                    target.y = (start[1] + (py-resizeStartY)/(doc.canvasHeight*baseScale())).coerceIn(-0.5f,1.5f)
                                } else if (resizeAxis == "both" && (commonPivot || resizeCornerAnchor)) {
                                    val startX = baseLeft() + start[0] * doc.canvasWidth * baseScale()
                                    val startY = baseTop() + start[1] * doc.canvasHeight * baseScale()
                                    val pivotX = if(resizeCornerAnchor) resizePivotX else groupPivotX
                                    val pivotY = if(resizeCornerAnchor) resizePivotY else groupPivotY
                                    val newX = pivotX + (startX - pivotX) * factor
                                    val newY = pivotY + (startY - pivotY) * factor
                                    target.x = ((newX - baseLeft()) / (doc.canvasWidth * baseScale())).coerceIn(-0.5f, 1.5f)
                                    target.y = ((newY - baseTop()) / (doc.canvasHeight * baseScale())).coerceIn(-0.5f, 1.5f)
                                }
                            }
                        } else {
                            var dx = (px-moveOriginX) / (doc.canvasWidth * baseScale())
                            var dy = (py-moveOriginY) / (doc.canvasHeight * baseScale())
                            if (incrementEnabled) {
                                val stepPx = dp(6).toFloat() / zoom.coerceAtLeast(.2f)
                                val snapDx = stepPx / (doc.canvasWidth * baseScale())
                                val snapDy = stepPx / (doc.canvasHeight * baseScale())
                                dx = kotlin.math.round(dx / snapDx) * snapDx
                                dy = kotlin.math.round(dy / snapDy) * snapDy
                            }
                            group.forEach { target ->
                                val start=groupStart[target.id] ?: return@forEach
                                target.x = (start[0] + dx).coerceIn(-0.5f, 1.5f)
                                target.y = (start[1] + dy).coerceIn(-0.5f, 1.5f)
                            }
                        }
                        lastProjectX=px; lastProjectY=py
                    }
                    invalidate(); onViewportChanged?.invoke(); return true
                }
                MotionEvent.ACTION_POINTER_UP -> { active=null; if(event.pointerCount>1){val remaining=if(event.actionIndex==0)1 else 0;touchDownX=event.getX(remaining);touchDownY=event.getY(remaining)}; return true }
                MotionEvent.ACTION_UP -> {
                    gestureHistoryBefore?.let { before -> if (touchMoved && before != doc.toJson().toString()) { if (undoStates.lastOrNull()!=before) undoStates.addLast(before); while(undoStates.size>40) undoStates.removeFirst(); redoStates.clear() } }; gestureHistoryBefore=null
                    val tapped = active
                    val wasTap = !touchMoved && !resizeActive && !rotationActive
                    if (wasTap && tapped != null && !editMode) {
                        val now = System.currentTimeMillis()
                        val secondTap = lastViewTapId == tapped.id && now - lastViewTapAt < 550L
                        if (tapped.kind == "video") {
                            selectedId = tapped.id; selectedIds.clear(); selectedIds.add(tapped.id)
                            if (secondTap) { playSelectedVideo(); lastViewTapId = null; lastViewTapAt = 0L }
                            else { lastViewTapId = tapped.id; lastViewTapAt = now; status.text = "Vidéo sélectionnée · toucher à nouveau pour lire" }
                        } else if (secondTap) {
                            selectedId = tapped.id; selectedIds.clear(); selectedIds.add(tapped.id)
                            selectedGroupId = tapped.groupId.takeIf { it.isNotBlank() }
                            if (selectedGroupId != null) { selectedIds.clear(); selectedIds.addAll(descendantGroupIds(selectedGroupId!!)) }
                            activateMainMode("edit"); status.text = "Mode Modifier · ${tapped.displayName}"
                            lastViewTapId = null; lastViewTapAt = 0L
                        } else {
                            lastViewTapId = tapped.id; lastViewTapAt = now
                            status.text = "Double toucher un média pour passer en mode Modifier"
                        }
                        refreshLayerStrip(); invalidate(); updateInlinePlayerOverlay()
                    } else if (wasTap && tapped != null && editMode) {
                        val now = System.currentTimeMillis()
                        val secondTap = lastViewTapId == tapped.id && now-lastViewTapAt < 550L
                        if (tapped.id != selectedId) {
                            if (secondTap) {
                                selectedId = tapped.id; selectedIds.clear(); selectedIds.add(tapped.id)
                                selectedGroupId = null; status.text = "Calque actif en mode Modifier · ${tapped.displayName}"
                                refreshLayerStrip(); invalidate(); updateInlinePlayerOverlay()
                                lastViewTapId = null; lastViewTapAt = 0L
                            } else {
                                status.text = "Double toucher pour modifier ce calque sans quitter le mode Modifier"
                                lastViewTapId = tapped.id; lastViewTapAt = now
                            }
                        } else if (secondTap) {
                            selectedIds.clear(); selectedId=null; selectedGroupId=null; editMode=false; setEditMode(false); refreshModeButtons()
                            status.text = "Mode Vue · calque désélectionné"
                            lastViewTapId = null; lastViewTapAt = 0L
                            refreshLayerStrip()
                        } else {
                            lastViewTapId=tapped.id; lastViewTapAt=now
                        }
                    } else if (wasTap && tapped == null && editMode) {
                        val now = System.currentTimeMillis()
                        if (lastViewTapId == "__blank__" && now-lastViewTapAt < 550L) {
                            selectedIds.clear(); selectedId=null; selectedGroupId=null; editMode=false; setEditMode(false); refreshModeButtons(); refreshLayerStrip()
                            status.text = "Mode Vue · sélection effacée"
                            lastViewTapId=null; lastViewTapAt=0L
                        } else { lastViewTapId="__blank__"; lastViewTapAt=now }
                    }
                    active=null; resizeActive=false; rotationActive=false
                    return true
                }
                MotionEvent.ACTION_CANCEL -> { active=null; resizeActive=false; rotationActive=false; return true }
            }
            return true
        }
    }
}
