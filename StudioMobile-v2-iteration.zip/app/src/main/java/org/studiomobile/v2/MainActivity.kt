package org.studiomobile.v2

import android.app.Activity
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.UUID
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var canvasView: ProjectCanvasView
    private val doc = ProjectDocument()
    private val mediaFiles = mutableMapOf<String, File>()
    private var selectedId: String? = null
    private var resizeActive = false
    private var resizeStartWidth = 0f
    private var resizeStartHeight = 0f
    private var resizeStartX = 0f
    private var resizeStartY = 0f

    private val exportPng = registerForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null) exportCanvasPng(uri)
    }
    private val exportHtmlPackage = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) exportInteractivePackage(uri)
    }

    private val importPicker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        status.text = "Importation de ${uris.size} fichier(s)…"
        thread {
            var done = 0
            val errors = mutableListOf<String>()
            uris.forEach { uri ->
                try {
                    val imported = ProjectArchive.importMedia(this, uri, contentResolver) { bytes ->
                        runOnUiThread { status.text = "Import : ${importedSafeName(uri)} — ${bytes / 1024} Ko" }
                    }
                    val duplicate = doc.items.firstOrNull { it.sha256 == imported.item.sha256 }
                    if (duplicate == null) {
                        val item = imported.item
                        item.x = (0.18f + (doc.items.size % 4) * 0.2f).coerceIn(0.1f, 0.9f)
                        item.y = (0.22f + (doc.items.size % 3) * 0.25f).coerceIn(0.1f, 0.9f)
                        doc.items.add(item); mediaFiles[item.id] = imported.cachedFile
                    } else imported.cachedFile.delete()
                } catch (e: Exception) { errors.add("${uri.lastPathSegment}: ${e.message}") }
                done++
                runOnUiThread { status.text = "Importation : $done/${uris.size}" }
            }
            runOnUiThread {
                progress.visibility = View.GONE
                status.text = if (errors.isEmpty()) "Import terminé : ${doc.items.size} élément(s). Doublons ignorés." else "Import terminé avec ${errors.size} erreur(s) : ${errors.first()}"
                canvasView.invalidate()
            }
        }
    }

    private val openProject = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) openProjectUri(uri)
    }
    private val saveProject = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) saveProjectUri(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 12, 16, 8) }
        val title = TextView(this).apply { text = "Studio Mobile v2"; textSize = 22f; setTypeface(null, Typeface.BOLD) }
        root.addView(title)
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(makeButton("Importer", 0) { importPicker.launch(arrayOf("image/*", "video/*")) })
        buttons.addView(makeButton("Ouvrir .studio", 1) { openProject.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) })
        buttons.addView(makeButton("Enregistrer", 2) { saveProject.launch("${safeDocName(doc.name)}.studio") })
        buttons.addView(makeButton("Aperçu PNG", 3) { exportPng.launch("${safeDocName(doc.name)}-apercu.png") })
        buttons.addView(makeButton("HTML ZIP", 9) { exportHtmlPackage.launch("${safeDocName(doc.name)}-html.zip") })
        root.addView(buttons)

        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tools.addView(makeButton("Calque ↑", 4) { moveSelectedLayer(1) })
        tools.addView(makeButton("Calque ↓", 5) { moveSelectedLayer(-1) })
        tools.addView(makeButton("Taille +", 6) { resizeSelected(1.1f) })
        tools.addView(makeButton("Taille −", 7) { resizeSelected(0.9f) })
        tools.addView(makeButton("Supprimer", 8) { deleteSelected() })
        root.addView(tools)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        root.addView(progress, LinearLayout.LayoutParams(-1, 12))
        status = TextView(this).apply { text = "Prêt. Importe des images ou vidéos pour commencer."; textSize = 12f; setPadding(0, 6, 0, 6) }
        root.addView(status)
        canvasView = ProjectCanvasView()
        root.addView(canvasView, LinearLayout.LayoutParams(-1, 0, 1f))
        val hint = TextView(this).apply { text = "Touchez un calque pour le sélectionner, glissez-le pour le déplacer et tirez sa poignée bleue en bas à droite pour le redimensionner. Les flèches changent l'ordre des calques. Export PNG = aperçu composite."; textSize = 12f }
        root.addView(hint)
        setContentView(root)
    }

    private fun makeButton(label: String, id: Int, action: () -> Unit): Button = Button(this).apply {
        text = label; textSize = 11f; isAllCaps = false; setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = 4 }
    }

    private fun saveProjectUri(uri: Uri) {
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        status.text = "Préparation de l'archive…"
        thread {
            try {
                contentResolver.openOutputStream(uri, "wt")?.use { out ->
                    ProjectArchive.save(this, doc, mediaFiles, out) { p ->
                        runOnUiThread { progress.isIndeterminate = false; progress.progress = p; status.text = "Enregistrement : $p%" }
                    }
                } ?: throw Exception("Impossible d'écrire le fichier choisi.")
                runOnUiThread { progress.visibility = View.GONE; status.text = "Projet enregistré : ${doc.items.size} élément(s)." }
            } catch (e: Exception) {
                runOnUiThread { progress.visibility = View.GONE; status.text = "Échec de sauvegarde : ${e.message}" }
            }
        }
    }

    private fun openProjectUri(uri: Uri) {
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        status.text = "Ouverture et vérification du projet…"
        thread {
            try {
                val (loaded, loadedFiles) = contentResolver.openInputStream(uri)?.use { input ->
                    ProjectArchive.open(this, input) { p -> runOnUiThread { status.text = "Lecture de l'archive…"; progress.progress = p } }
                } ?: throw Exception("Impossible de lire ce fichier.")
                runOnUiThread {
                    ThumbnailCache.clear()
                    doc.name = loaded.name; doc.canvasWidth = loaded.canvasWidth; doc.canvasHeight = loaded.canvasHeight
                    doc.items.clear(); doc.items.addAll(loaded.items)
                    mediaFiles.clear(); mediaFiles.putAll(loadedFiles)
                    progress.visibility = View.GONE
                    status.text = "Projet ouvert et vérifié : ${doc.items.size} élément(s)."
                    canvasView.invalidate()
                }
            } catch (e: Exception) {
                runOnUiThread { progress.visibility = View.GONE; status.text = "Ouverture impossible : ${e.message}" }
            }
        }
    }

    private fun moveSelectedLayer(direction: Int) {
        val index = doc.items.indexOfFirst { it.id == selectedId }
        if (index < 0) { status.text = "Sélectionne d'abord un calque."; return }
        val target = (index + direction).coerceIn(0, doc.items.lastIndex)
        if (target != index) {
            val item = doc.items.removeAt(index)
            doc.items.add(target, item)
            canvasView.invalidate()
        }
    }

    private fun resizeSelected(factor: Float) {
        val item = doc.items.firstOrNull { it.id == selectedId }
        if (item == null) { status.text = "Sélectionne d'abord un calque."; return }
        item.width = (item.width * factor).coerceIn(0.04f, 1.8f)
        item.height = (item.height * factor).coerceIn(0.04f, 1.8f)
        canvasView.invalidate()
    }

    private fun deleteSelected() {
        val id = selectedId ?: run { status.text = "Sélectionne d'abord un calque."; return }
        doc.items.removeAll { it.id == id }
        mediaFiles.remove(id)?.let { it.delete() }
        ThumbnailCache.remove(id)
        selectedId = null
        canvasView.invalidate()
        status.text = "Calque supprimé. Enregistre le projet pour conserver ce changement."
    }

    private fun exportCanvasPng(uri: Uri) {
        status.text = "Rendu de l'aperçu PNG…"
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        thread {
            var bitmap: Bitmap? = null
            try {
                // PNG export is intentionally an editor-preview export, not the
                // final-resolution renderer. It uses cached, bounded thumbnails.
                val exportScale = minOf(1f, 2560f / doc.canvasWidth.coerceAtLeast(1), 2560f / doc.canvasHeight.coerceAtLeast(1))
                val outW = (doc.canvasWidth * exportScale).toInt().coerceAtLeast(1)
                val outH = (doc.canvasHeight * exportScale).toInt().coerceAtLeast(1)
                val outputBitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
                bitmap = outputBitmap
                val canvas = Canvas(outputBitmap)
                canvas.drawColor(Color.WHITE)
                val snapshot = doc.items.toList()
                // Try to prepare missing previews off the UI thread before rendering.
                snapshot.forEach { item ->
                    val file = mediaFiles[item.id]
                    if (file != null && ThumbnailCache.get(item.id) == null) ThumbnailCache.generate(item.id, file, item.kind)
                }
                val localPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                snapshot.forEach { item ->
                    val cx = item.x * outW; val cy = item.y * outH
                    val w = item.width * outW; val h = item.height * outH
                    val rect = RectF(cx-w/2, cy-h/2, cx+w/2, cy+h/2)
                    val thumb = ThumbnailCache.get(item.id)
                    if (thumb != null) canvas.drawBitmap(thumb, null, rect, localPaint)
                    else {
                        localPaint.color = Color.LTGRAY
                        canvas.drawRoundRect(rect, 8f, 8f, localPaint)
                        localPaint.color = Color.DKGRAY; localPaint.textSize = 22f
                        canvas.drawText(item.displayName.take(30), rect.left+8f, rect.centerY(), localPaint)
                    }
                }
                contentResolver.openOutputStream(uri)?.use { out ->
                    if (!outputBitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) throw IOException("La compression PNG a échoué.")
                } ?: throw IOException("Impossible d'écrire le PNG choisi.")
                runOnUiThread { status.text = "Aperçu PNG exporté. Pour l'instant, les médias utilisent les vignettes du canvas." }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Export PNG échoué : ${e.message}" }
            } finally {
                bitmap?.recycle()
                runOnUiThread { progress.visibility = View.GONE }
            }
        }
    }

    private fun exportInteractivePackage(uri: Uri) {
        status.text = "Préparation du paquet HTML interactif…"
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        thread {
            try {
                val manifest = doc.toJson().toString()
                val html = """<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>Studio Mobile — ${safeDocName(doc.name)}</title><style>
*{box-sizing:border-box}body{margin:0;background:#17191d;color:#eee;font:14px system-ui,sans-serif;display:flex;flex-direction:column;height:100dvh}
header{padding:10px 14px;background:#242830;display:flex;justify-content:space-between;gap:10px;align-items:center}#stageWrap{flex:1;min-height:0;display:grid;place-items:center;overflow:auto;padding:12px}
#stage{position:relative;background:#fff;overflow:hidden;max-width:100%;max-height:100%;box-shadow:0 5px 25px #0008} .item{position:absolute;transform:translate(-50%,-50%);overflow:hidden;background:#ddd;display:grid;place-items:center}
.item img,.item video{width:100%;height:100%;object-fit:fill;background:#111}.item video{cursor:pointer}footer{padding:8px 12px;background:#242830;color:#aeb5c1;font-size:12px}
</style></head><body><header><strong>Studio Mobile — ${safeDocName(doc.name)}</strong><span id="dim"></span></header><div id="stageWrap"><main id="stage"></main></div><footer>Paquet autonome · Images et vidéos incluses · Touchez une vidéo pour la lire.</footer>
<script>const doc = $manifest;
const stage=document.getElementById('stage');stage.style.width=doc.canvas.width+'px';stage.style.height=doc.canvas.height+'px';document.getElementById('dim').textContent=doc.canvas.width+' × '+doc.canvas.height+' px';
for(const item of doc.items){const box=document.createElement('div');box.className='item';box.style.left=(item.x*100)+'%';box.style.top=(item.y*100)+'%';box.style.width=(item.width*100)+'%';box.style.height=(item.height*100)+'%';
const path=item.mediaPath.split('/').map(encodeURIComponent).join('/');let media;if(item.kind==='video'){media=document.createElement('video');media.src=path;media.controls=true;media.preload='metadata';media.playsInline=true;}else if(item.kind==='image'){media=document.createElement('img');media.src=path;media.alt=item.displayName;}else{media=document.createElement('a');media.href=path;media.textContent=item.displayName;media.style.color='#222';}
box.appendChild(media);stage.appendChild(box);}
</script></body></html>""".replace("$manifest", manifest)
                contentResolver.openOutputStream(uri, "wt")?.use { raw ->
                    java.util.zip.ZipOutputStream(java.io.BufferedOutputStream(raw)).use { zip ->
                        fun putText(path: String, text: String) {
                            zip.putNextEntry(java.util.zip.ZipEntry(path)); zip.write(text.toByteArray(Charsets.UTF_8)); zip.closeEntry()
                        }
                        putText("index.html", html)
                        putText("project.json", manifest)
                        doc.items.forEachIndexed { index, item ->
                            val file = mediaFiles[item.id] ?: throw IOException("Média absent : ${item.displayName}")
                            zip.putNextEntry(java.util.zip.ZipEntry(item.mediaPath))
                            file.inputStream().buffered().use { it.copyTo(zip, 64 * 1024) }
                            zip.closeEntry()
                            val pct = ((index + 1) * 100) / doc.items.size.coerceAtLeast(1)
                            runOnUiThread { progress.isIndeterminate = false; progress.progress = pct; status.text = "Paquet HTML : $pct%" }
                        }
                    }
                } ?: throw IOException("Impossible d'écrire le paquet HTML.")
                runOnUiThread { status.text = "Paquet HTML créé. Décompresse le ZIP puis ouvre index.html dans un navigateur." }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Export HTML échoué : ${e.message}" }
            } finally { runOnUiThread { progress.visibility = View.GONE } }
        }
    }

    private fun importedSafeName(uri: Uri) = uri.lastPathSegment?.takeLast(28) ?: "média"
    private fun safeDocName(s: String) = s.replace(Regex("[^A-Za-z0-9_-]"), "_").ifBlank { "MonProjet" }

    private inner class ProjectCanvasView : View(this@MainActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var active: ProjectItem? = null
        private var lastX = 0f; private var lastY = 0f
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.rgb(245, 246, 248))
            paint.color = Color.WHITE; canvas.drawRoundRect(12f, 12f, width-12f, height-12f, 12f, 12f, paint)
            val sx = width.toFloat() / doc.canvasWidth
            val sy = height.toFloat() / doc.canvasHeight
            doc.items.forEach { item ->
                val cx = item.x * width; val cy = item.y * height
                val w = item.width * width; val h = item.height * height
                val rect = RectF(cx-w/2, cy-h/2, cx+w/2, cy+h/2)
                paint.color = if (item.id == selectedId) Color.rgb(198, 226, 255) else Color.rgb(230, 234, 239)
                canvas.drawRoundRect(rect, 8f, 8f, paint)
                val file = mediaFiles[item.id]
                if (file != null && (item.kind == "image" || item.kind == "video")) {
                    // onDraw never decodes a file itself anymore: it only ever reads
                    // ThumbnailCache, which holds a small, capped-size bitmap generated
                    // once in the background. This is what makes dragging smooth again
                    // and what finally makes huge photos (and videos) safe to preview.
                    val thumb = ThumbnailCache.get(item.id)
                    if (thumb != null) {
                        val src = Rect(0, 0, thumb.width, thumb.height)
                        paint.color = Color.WHITE
                        canvas.drawBitmap(thumb, src, rect, paint)
                    } else {
                        drawLabel(canvas, item, rect)
                        if (!ThumbnailCache.isPending(item.id)) requestThumbnail(item.id, file, item.kind)
                    }
                } else drawLabel(canvas, item, rect)
                paint.style = Paint.Style.STROKE; paint.strokeWidth = if (item.id == selectedId) 4f else 1.5f
                paint.color = if (item.id == selectedId) Color.BLUE else Color.DKGRAY
                canvas.drawRoundRect(rect, 8f, 8f, paint); paint.style = Paint.Style.FILL
                if (item.id == selectedId) {
                    paint.color = Color.BLUE
                    canvas.drawCircle(rect.right, rect.bottom, 12f, paint)
                    paint.color = Color.WHITE
                    canvas.drawCircle(rect.right, rect.bottom, 4f, paint)
                }
            }
            if (doc.items.isEmpty()) {
                paint.color = Color.DKGRAY; paint.textSize = 18f
                canvas.drawText("Espace de composition", 32f, height/2f, paint)
                paint.textSize = 13f; canvas.drawText("Utilise « Importer » pour ajouter des médias", 32f, height/2f+26f, paint)
            }
        }
        private fun requestThumbnail(itemId: String, file: File, kind: String) {
            thread {
                ThumbnailCache.generate(itemId, file, kind)
                post { invalidate() } // back to the UI thread; invalidate() triggers one more onDraw that now finds the thumbnail ready
            }
        }
        private fun drawLabel(canvas: Canvas, item: ProjectItem, rect: RectF) {
            paint.color = Color.DKGRAY; paint.textSize = 15f
            val label = (if (item.kind == "video") "▶ " else if (item.kind == "image") "▧ " else "▤ ") + item.displayName
            val clipped = if (label.length > 22) label.take(19) + "…" else label
            canvas.drawText(clipped, rect.left+8f, rect.centerY(), paint)
        }
        override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    active = doc.items.asReversed().firstOrNull { item ->
                        val cx = item.x * width; val cy = item.y * height
                        event.x in (cx-item.width*width/2)..(cx+item.width*width/2) &&
                            event.y in (cy-item.height*height/2)..(cy+item.height*height/2)
                    }
                    selectedId = active?.id
                    resizeActive = false
                    active?.let { item ->
                        val right = item.x * width + item.width * width / 2
                        val bottom = item.y * height + item.height * height / 2
                        if (event.x >= right - 26f && event.y >= bottom - 26f) {
                            resizeActive = true
                            resizeStartWidth = item.width
                            resizeStartHeight = item.height
                            resizeStartX = event.x
                            resizeStartY = event.y
                        }
                    }
                    lastX = event.x; lastY = event.y; invalidate(); return true
                }
                MotionEvent.ACTION_MOVE -> {
                    active?.let { item ->
                        if (resizeActive) {
                            item.width = (resizeStartWidth + (event.x - resizeStartX) * 2f / width).coerceIn(0.04f, 1.8f)
                            item.height = (resizeStartHeight + (event.y - resizeStartY) * 2f / height).coerceIn(0.04f, 1.8f)
                        } else {
                            item.x = (item.x + (event.x-lastX)/width).coerceIn(-0.5f, 1.5f)
                            item.y = (item.y + (event.y-lastY)/height).coerceIn(-0.5f, 1.5f)
                            lastX = event.x; lastY = event.y
                        }
                        invalidate()
                    }; return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { active = null; resizeActive = false; return true }
            }
            return true
        }
    }
}
