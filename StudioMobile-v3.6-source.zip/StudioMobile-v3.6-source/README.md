# Studio Mobile V3.6

Version Android 3.6.0 — prototype expérimental d'export vidéo du canvas.

- Package conservé : `org.studiomobile.v2`
- Version code : 13
- Export vidéo : MP4 / H.264, 24 i/s, grand côté plafonné à 1 280 px.
- **Prototype muet : aucune piste audio n'est exportée à ce stade.**
- Export HTML, PNG et sauvegarde `.studio` conservés.

Consulter `V3.6-CHANGELOG.md`, `V3.6-TESTS.md` et `V3.6-REVUE-TECHNIQUE.md` avant les essais.
