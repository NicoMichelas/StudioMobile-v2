# Studio Mobile V3.6.1

V3.6.1 améliore l'export vidéo du canvas : résolution jusqu'à 3840 px sur le grand côté, décodage photo selon la taille utile du calque et intégration audio AAC séquentielle lorsque les pistes sont compatibles.

- Package Android conservé : `org.studiomobile.v2`
- Version : `3.6.1` / code 14
- Workflow : `.github/workflows/build-android-v3.6.1.yml`
- Archive source attendue à la racine du dépôt : `StudioMobile-v3.6.1-source.zip`

Lire `V3.6.1-CHANGELOG.md`, `V3.6.1-REVUE-TECHNIQUE.md` et `V3.6.1-TESTS.md`.
