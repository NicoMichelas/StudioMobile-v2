package org.studiomobile.v2

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaExtractor
import android.media.MediaMuxer
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min

/** First V3.6 canvas-video renderer. Visual prototype: audio muxing is deliberately not claimed yet. */
internal object CanvasVideoExporter {
    data class Result(val width: Int, val height: Int, val durationMs: Long, val bytes: Long)

    fun export(doc: ProjectDocument, files: Map<String, File>, destination: File,
               maxLongEdge: Int = 3840, fps: Int = 30,
               onProgress: (Int, String) -> Unit = { _, _ -> }) : Result {
        require(fps in 12..30) { "Fréquence d'images non prise en charge." }
        val videos = doc.items.filter { it.visible && it.kind == "video" && files[it.id]?.isFile == true }
            .sortedBy { it.videoOrder }
        require(videos.isNotEmpty()) { "Le projet ne contient aucune vidéo visible à exporter." }
        // Preserve the canvas aspect ratio and use its native dimensions whenever
        // they fit the selected export ceiling. Extremely wide/tall canvases are
        // proportionally reduced to a device-friendly ceiling instead of 1280 px.
        require(doc.canvasWidth > 0 && doc.canvasHeight > 0) { "Dimensions du canvas invalides." }
        val canvasLongEdge = max(doc.canvasWidth, doc.canvasHeight)
        val scale = min(1f, maxLongEdge.toFloat() / canvasLongEdge.toFloat())
        val outW = even((doc.canvasWidth * scale).toInt().coerceAtLeast(2))
        val outH = even((doc.canvasHeight * scale).toInt().coerceAtLeast(2))
        val durations = videos.map { item ->
            val r = MediaMetadataRetriever(); r.setDataSource(files.getValue(item.id).absolutePath)
            val source = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            r.release()
            val start = item.trimStartMs.coerceAtLeast(0L).coerceAtMost(source)
            val end = if (item.trimEndMs > start) item.trimEndMs.coerceAtMost(source) else source
            (end - start).coerceAtLeast(0L)
        }
        require(durations.any { it > 0 }) { "Durée vidéo invalide." }
        val totalMs = durations.sum()
        val totalFrames = durations.sumOf { ((it * fps + 999L) / 1000L).coerceAtLeast(1L) }
        val encoder = MediaCodec.createEncoderByType("video/avc")
        val colorFormat = chooseColorFormat(encoder)
        val format = MediaFormat.createVideoFormat("video/avc", outW, outH).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, colorFormat)
            setInteger(MediaFormat.KEY_BIT_RATE, (outW.toLong() * outH * fps / 5L).coerceIn(1_500_000L, 24_000_000L).toInt())
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        }
        val muxer = MediaMuxer(destination.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var muxerStarted = false
        var track = -1
        var audioTrack = -1
        val audioClips = prepareCompatibleAudio(videos, files)
        val info = MediaCodec.BufferInfo()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val canvasBitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(canvasBitmap)
        val decodedImages = mutableMapOf<String, Bitmap>()
        val retrievers = mutableMapOf<String, MediaMetadataRetriever>()
        val activeFrame = mutableMapOf<String, Bitmap>()
        val posterFrames = mutableMapOf<String, Bitmap>()
        try {
            doc.items.filter { it.visible && it.kind == "image" }.forEach { item ->
                files[item.id]?.let { f ->
                    if (f.isFile) decodedImages[item.id] = decodeScaled(
                        f, (item.width * outW).toInt().coerceAtLeast(2),
                        (item.height * outH).toInt().coerceAtLeast(2)
                    )
                }
            }
            videos.forEach { item ->
                retrievers[item.id] = MediaMetadataRetriever().apply { setDataSource(files.getValue(item.id).absolutePath) }
                val targetW = (item.width * outW).toInt().coerceAtLeast(2)
                val targetH = (item.height * outH).toInt().coerceAtLeast(2)
                posterBitmap(item, files[item.id], targetW, targetH)?.let { posterFrames[item.id] = it }
            }
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encoder.start()
            var frameIndex = 0L
            videos.forEachIndexed { videoIndex, active ->
                val start = active.trimStartMs.coerceAtLeast(0L)
                val duration = durations[videoIndex]
                val count = ((duration * fps + 999L) / 1000L).coerceAtLeast(1L)
                for (localFrame in 0 until count) {
                    val timeMs = start + (localFrame * 1000L / fps)
                    val retriever = retrievers.getValue(active.id)
                    val frame = retriever.getFrameAtTime(timeMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST)
                    if (frame != null) { activeFrame.put(active.id, frame)?.let { if (!it.isRecycled) it.recycle() } }
                    canvas.drawColor(Color.BLACK)
                    doc.items.filter { it.visible }.forEach { item ->
                        val bitmap = when (item.kind) {
                            "image" -> decodedImages[item.id]
                            "video" -> if (item.id == active.id) activeFrame[item.id] else posterFrames[item.id]
                            else -> null
                        }
                        if (bitmap != null) drawItem(canvas, bitmap, item, outW, outH, paint)
                        else if (item.kind !in setOf("image", "video")) drawLabel(canvas, item, outW, outH, paint)
                    }
                    queueFrame(encoder, canvasBitmap, frameIndex * 1_000_000L / fps, colorFormat)
                    drain(encoder, muxer, info, false, { track }) { formatOut ->
                        if (!muxerStarted) {
                            track = muxer.addTrack(formatOut)
                            if (audioClips.isNotEmpty()) audioTrack = muxer.addTrack(audioClips.first().format)
                            muxer.start(); muxerStarted = true
                        }
                    }
                    frameIndex++
                    if (frameIndex % fps.toLong() == 0L) onProgress(((frameIndex * 100L) / totalFrames).toInt().coerceIn(0,99), "Encodage · vidéo ${videoIndex + 1}/${videos.size}")
                }
                activeFrame.remove(active.id)?.recycle()
            }
            var inputIndex = encoder.dequeueInputBuffer(10_000)
            while (inputIndex < 0) {
                drain(encoder, muxer, info, false, { track }) { formatOut ->
                    if (!muxerStarted) {
                        track = muxer.addTrack(formatOut)
                        if (audioClips.isNotEmpty()) audioTrack = muxer.addTrack(audioClips.first().format)
                        muxer.start(); muxerStarted = true
                    }
                }
                inputIndex = encoder.dequeueInputBuffer(10_000)
            }
            encoder.queueInputBuffer(inputIndex, 0, 0, frameIndex * 1_000_000L / fps, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            drain(encoder, muxer, info, true, { track }) { formatOut ->
                if (!muxerStarted) {
                    track = muxer.addTrack(formatOut)
                    if (audioClips.isNotEmpty()) audioTrack = muxer.addTrack(audioClips.first().format)
                    muxer.start(); muxerStarted = true
                }
            }
            if (muxerStarted && audioTrack >= 0) {
                copyAudioSequentially(videos, files, durations, audioTrack, muxer) { value, message -> onProgress(value, message) }
            }
            require(muxerStarted && destination.length() > 0L) { "Aucune piste vidéo n'a été produite." }
            onProgress(100, "Export vidéo terminé")
            return Result(outW, outH, totalMs, destination.length())
        } finally {
            activeFrame.values.forEach { if (!it.isRecycled) it.recycle() }
            posterFrames.values.forEach { if (!it.isRecycled) it.recycle() }
            decodedImages.values.forEach { if (!it.isRecycled) it.recycle() }
            retrievers.values.forEach { try { it.release() } catch (_: Exception) {} }
            try { encoder.stop() } catch (_: Exception) {}
            encoder.release()
            try { if (muxerStarted) muxer.stop() } catch (_: Exception) {}
            muxer.release()
            canvasBitmap.recycle()
        }
    }

    private data class AudioClip(val item: ProjectItem, val file: File, val trackIndex: Int, val format: MediaFormat)

    /**
     * Keep an AAC soundtrack when all participating clips expose compatible AAC
     * tracks. This is lossless compressed-audio passthrough; mixed codec/sample-rate
     * conversion and per-item gain are deliberately reported as unsupported rather
     * than silently producing corrupt or misleading audio.
     */
    private fun prepareCompatibleAudio(videos: List<ProjectItem>, files: Map<String, File>): List<AudioClip> {
        val clips = mutableListOf<AudioClip>()
        var reference: MediaFormat? = null
        for (item in videos) {
            val file = files[item.id] ?: continue
            val extractor = MediaExtractor()
            try {
                extractor.setDataSource(file.absolutePath)
                var found = -1
                var fmt: MediaFormat? = null
                for (i in 0 until extractor.trackCount) {
                    val candidate = extractor.getTrackFormat(i)
                    val mime = candidate.getString(MediaFormat.KEY_MIME) ?: continue
                    if (mime.startsWith("audio/")) { found = i; fmt = candidate; break }
                }
                if (found >= 0 && fmt != null) {
                    val mime = fmt.getString(MediaFormat.KEY_MIME)
                    if (mime != "audio/mp4a-latm") continue
                    val ref = reference
                    if (ref != null && (ref.getInteger(MediaFormat.KEY_SAMPLE_RATE) != fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) || ref.getInteger(MediaFormat.KEY_CHANNEL_COUNT) != fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT))) continue
                    if (ref == null) reference = fmt
                    clips.add(AudioClip(item, file, found, fmt))
                }
            } catch (_: Exception) {
                // A clip without a readable AAC track remains silent in the export.
            } finally { extractor.release() }
        }
        // Muxer requires a single audio format. If any clip with audio is incompatible,
        // avoid silently mixing only a subset of the project's soundtracks.
        val audioBearing = videos.count { item ->
            val f = files[item.id] ?: return@count false
            val ex = MediaExtractor()
            try { ex.setDataSource(f.absolutePath); (0 until ex.trackCount).any { (ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/") } }
            catch (_: Exception) { false } finally { ex.release() }
        }
        return if (clips.size == audioBearing) clips else emptyList()
    }

    private fun copyAudioSequentially(
        videos: List<ProjectItem>, files: Map<String, File>, durations: List<Long>,
        audioTrack: Int, muxer: MediaMuxer, progress: (Int, String) -> Unit
    ) {
        var timelineUs = 0L
        for ((index, item) in videos.withIndex()) {
            val file = files[item.id]
            if (file == null) { timelineUs += durations[index] * 1000L; continue }
            val extractor = MediaExtractor()
            try {
                extractor.setDataSource(file.absolutePath)
                var sourceTrack = -1
                for (i in 0 until extractor.trackCount) {
                    if ((extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: "") == "audio/mp4a-latm") { sourceTrack = i; break }
                }
                if (sourceTrack >= 0) {
                    extractor.selectTrack(sourceTrack)
                    val startUs = item.trimStartMs.coerceAtLeast(0L) * 1000L
                    val endUs = if (item.trimEndMs > item.trimStartMs) item.trimEndMs * 1000L else Long.MAX_VALUE
                    extractor.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                    val info = MediaCodec.BufferInfo()
                    val buffer = ByteBuffer.allocate(1024 * 1024)
                    while (true) {
                        buffer.clear()
                        val size = extractor.readSampleData(buffer, 0)
                        if (size < 0) break
                        val pts = extractor.sampleTime
                        if (pts < 0L || pts >= endUs) break
                        if (pts >= startUs) {
                            info.set(0, size, timelineUs + (pts - startUs), extractor.sampleFlags)
                            buffer.position(0); buffer.limit(size)
                            muxer.writeSampleData(audioTrack, buffer, info)
                        }
                        if (!extractor.advance()) break
                    }
                }
            } finally { extractor.release() }
            timelineUs += durations[index] * 1000L
            progress(95 + ((index + 1) * 4 / videos.size), "Audio · séquence ${index + 1}/${videos.size}")
        }
    }

    private fun posterBitmap(item: ProjectItem, file: File?, w: Int, h: Int): Bitmap? {
        if (file == null || !file.isFile) return null
        val r = MediaMetadataRetriever()
        return try { r.setDataSource(file.absolutePath); r.getFrameAtTime(item.posterTimeMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST)?.let { src ->
            val s = min(1f, max(w.toFloat()/src.width, h.toFloat()/src.height)); Bitmap.createScaledBitmap(src, (src.width*s).toInt().coerceAtLeast(1), (src.height*s).toInt().coerceAtLeast(1), true).also { if (it !== src) src.recycle() }
        } } catch (_: Exception) { null } finally { r.release() }
    }

    private fun decodeScaled(file: File, w: Int, h: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }; BitmapFactory.decodeFile(file.absolutePath, bounds)
        var sample = 1
        // Decode enough source pixels for the item's eventual on-canvas footprint.
        // The output canvas may be very wide; never use the old fixed 1280px limit.
        while (bounds.outWidth / (sample * 2) >= w && bounds.outHeight / (sample * 2) >= h) sample *= 2
        return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 })
            ?: throw IllegalArgumentException("Image illisible : ${file.name}")
    }

    private fun drawItem(c: Canvas, b: Bitmap, item: ProjectItem, w: Int, h: Int, p: Paint) {
        val cx = item.x * w; val cy = item.y * h; val rw = item.width * w; val rh = item.height * h
        val dst = RectF(cx-rw/2, cy-rh/2, cx+rw/2, cy+rh/2)
        val l = (item.cropLeft * b.width).toInt().coerceIn(0,b.width-1); val t = (item.cropTop * b.height).toInt().coerceIn(0,b.height-1)
        val r = (item.cropRight * b.width).toInt().coerceIn(l+1,b.width); val bt = (item.cropBottom * b.height).toInt().coerceIn(t+1,b.height)
        val src = Rect(l,t,r,bt)
        c.save(); c.rotate(item.rotation, cx, cy); c.scale(if (item.flipHorizontal) -1f else 1f, if (item.flipVertical) -1f else 1f,cx,cy)
        var source = src
        var target = dst
        val sourceAspect = (r-l).toFloat()/(bt-t).toFloat()
        val destAspect = rw/rh
        if (item.fitMode == "contain") {
            if (sourceAspect > destAspect) { val hh=rw/sourceAspect; target=RectF(dst.left,cy-hh/2,dst.right,cy+hh/2) }
            else { val ww=rh*sourceAspect; target=RectF(cx-ww/2,dst.top,cx+ww/2,dst.bottom) }
        } else if (item.fitMode == "cover") {
            if (sourceAspect > destAspect) { val sw=((bt-t)*destAspect).toInt().coerceAtLeast(1); val left=l+((r-l-sw)/2); source=Rect(left,t,left+sw,bt) }
            else { val sh=((r-l)/destAspect).toInt().coerceAtLeast(1); val top=t+((bt-t-sh)/2); source=Rect(l,top,r,top+sh) }
        }
        c.drawBitmap(b, source, target, p); c.restore()
    }
    private fun queueFrame(codec: MediaCodec, bitmap: Bitmap, pts: Long, colorFormat: Int) {
        val index = codec.dequeueInputBuffer(10_000)
        require(index >= 0) { "Encodeur vidéo saturé." }
        val input = codec.getInputBuffer(index) ?: error("Buffer encodeur indisponible")
        input.clear(); bitmapToI420(bitmap, input, colorFormat)
        codec.queueInputBuffer(index, 0, input.position(), pts, 0)
    }
    private fun bitmapToI420(b: Bitmap, out: ByteBuffer, colorFormat: Int) {
        val w=b.width; val h=b.height; val pixels=IntArray(w*h); b.getPixels(pixels,0,w,0,0,w,h)
        val ySize=w*h; val qSize=ySize/4; val yPlane=ByteArray(ySize); val uPlane=ByteArray(qSize); val vPlane=ByteArray(qSize)
        var yi=0; var ui=0; var vi=0
        for (row in 0 until h) for (col in 0 until w) {
            val c=pixels[row*w+col]; val rr=(c shr 16) and 255; val gg=(c shr 8) and 255; val bb=c and 255
            yPlane[yi++]=(((66*rr+129*gg+25*bb+128) shr 8)+16).coerceIn(0,255).toByte()
            if(row%2==0 && col%2==0) { uPlane[ui++]=(((-38*rr-74*gg+112*bb+128) shr 8)+128).coerceIn(0,255).toByte(); vPlane[vi++]=(((112*rr-94*gg-18*bb+128) shr 8)+128).coerceIn(0,255).toByte() }
        }
        out.put(yPlane)
        if (colorFormat == MediaCodecInfoColor.COLOR_FORMAT_YUV420_SEMIPLANAR) {
            for (i in 0 until qSize) { out.put(uPlane[i]); out.put(vPlane[i]) }
        } else { out.put(uPlane); out.put(vPlane) }
    }
    private fun chooseColorFormat(codec: MediaCodec): Int {
        val caps = codec.codecInfo.getCapabilitiesForType("video/avc").colorFormats.toSet()
        return when {
            MediaCodecInfoColor.COLOR_FORMAT_YUV420_SEMIPLANAR in caps -> MediaCodecInfoColor.COLOR_FORMAT_YUV420_SEMIPLANAR
            MediaCodecInfoColor.COLOR_FORMAT_YUV420_PLANAR in caps -> MediaCodecInfoColor.COLOR_FORMAT_YUV420_PLANAR
            else -> throw IllegalStateException("Encodeur H.264 sans entrée YUV420 compatible.")
        }
    }
    private fun drawLabel(c: Canvas, item: ProjectItem, w: Int, h: Int, p: Paint) {
        val cx=item.x*w; val cy=item.y*h; val rw=item.width*w; val rh=item.height*h
        c.save(); c.rotate(item.rotation,cx,cy); c.scale(if(item.flipHorizontal) -1f else 1f,if(item.flipVertical) -1f else 1f,cx,cy)
        p.color=Color.rgb(154,172,176); p.textSize=(rh*0.22f).coerceIn(12f,64f)
        val label=(if(item.kind=="video") "▶ " else if(item.kind=="image") "▧ " else "▤ ")+item.displayName
        c.drawText(if(label.length>40) label.take(37)+"…" else label,cx-rw/2+8f,cy,p); c.restore()
    }
    private fun drain(codec: MediaCodec, muxer: MediaMuxer, info: MediaCodec.BufferInfo, end: Boolean, trackIndex: () -> Int, onFormat: (MediaFormat)->Unit) {
        var done=false
        while(!done) {
            when(val index=codec.dequeueOutputBuffer(info,10_000)) {
                MediaCodec.INFO_TRY_AGAIN_LATER -> { if(!end) done=true }
                MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> onFormat(codec.outputFormat)
                else -> if(index>=0) {
                    val buffer=codec.getOutputBuffer(index) ?: error("Sortie encodeur indisponible")
                    if(info.size>0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) { check(trackIndex() >= 0) { "Piste vidéo non initialisée" }; buffer.position(info.offset); buffer.limit(info.offset+info.size); muxer.writeSampleData(trackIndex(),buffer,info) }
                    val eos=(info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0
                    codec.releaseOutputBuffer(index,false); if(eos) done=true
                }
            }
        }
    }
    private fun even(v:Int)=if(v%2==0)v else v-1
    private object MediaCodecInfoColor { const val COLOR_FORMAT_YUV420_PLANAR = 19; const val COLOR_FORMAT_YUV420_SEMIPLANAR = 21 }
}
