# Studio Mobile V3.3 — candidat Android

Studio Mobile est un éditeur de composition photo/vidéo sur canevas libre. Cette version vise d'abord la stabilité des gros projets, une interface compacte et la manipulation des calques.

## Identité et construction

- Version : `3.3.0` (`versionCode = 10`)
- Package Android conservé pour la mise à jour : `org.studiomobile.v2`
- Minimum Android : API 26 ; cible de compilation : API 35
- Java 17, Kotlin 2.1.20, AGP 8.9.1, Gradle 8.11.1
- Source livrée sous forme de ZIP plat à placer à la racine du dépôt `StudioMobile-v2`
- Workflow : `.github/workflows/build-android-v3.3.yml`

Le workflow compile exclusivement le contenu de `StudioMobile-v3.3-source.zip`. Il ne retombe jamais sur les fichiers Kotlin éventuellement présents à la racine du dépôt.

## Fonctionnalités ciblées

- Interface sombre unifiée, barre de projet compacte et barre d'outils horizontale défilante.
- Panneau droit Calques/Vidéo, repliable réellement, redimensionnable et avec taille des lignes réglable.
- Calques affichés du plus haut au plus bas ; appui long pour glisser-déposer ; cases à cocher pour la sélection multiple.
- Déplacement d'un calque dans un groupe, imbrication de groupes, regroupement d'un groupe avec un calque, dissociation d'un groupe ou sortie d'un calque seul.
- Panneau Vidéo avec ordre de lecture, volume individuel et accès au réglage du poster.
- Enregistrer : écraser le fichier courant si l'accès en écriture est accordé, créer la version X+1, ou Enregistrer sous.
- Importation atomique : les médias ne sont ajoutés au document qu'après leur copie et leur empreinte ; les aperçus sont générés en série.
- Cache de vignettes mémoire borné et cache disque ; décodage des photos et posters à taille réduite.
- Recadrage visuel non destructif par grille, bords et déplacement de la zone.
- Dimensions du canevas sans changement de taille physique des médias.
- Lecteur vidéo unique avec texture, zone de clipping, respect du recadrage et calques supérieurs dessinés au-dessus du lecteur.
- Libération du lecteur après 30 secondes de pause, à la fin, lors d'un changement de calque ou à la mise en arrière-plan.
- Vérification SHA-256 accessible depuis Outils ; l'ouverture d'un projet vérifie également les empreintes.
- Export HTML autonome avec commande Lire/Stop visuellement distincte et tentative de chargement vidéo iOS par Blob URL.

## Limites connues à ce stade

- Ce ZIP est un candidat de développement : il n'a pas été compilé dans cet environnement, faute de SDK Android/Gradle disponibles ici. Le workflow GitHub doit encore confirmer le build.
- Les comportements tactiles, le lecteur vidéo, l'orientation et l'export HTML doivent être validés sur le Redmi Note 12 Pro 5G.
- Pendant la lecture native d'une vidéo, les calques situés au-dessus sont redessinés depuis leurs aperçus ; une seconde vidéo placée au-dessus n'est donc pas composée en lecture simultanée.
- La compatibilité vidéo iPhone est améliorée par une conversion data URL → Blob à la demande, mais reste à tester sur Safari iOS.
- Pas d'annulation/rétablissement ni d'autosauvegarde avancée dans cette version.
