package org.studiomobile.v2

import org.json.JSONArray
import org.json.JSONObject

data class ProjectItem(
    val id: String,
    val mediaPath: String,
    val displayName: String,
    val mimeType: String,
    val kind: String,
    var x: Float = 0.5f,
    var y: Float = 0.5f,
    var width: Float = 0.24f,
    var height: Float = 0.24f,
    val sha256: String,
    var rotation: Float = 0f,
    var sourceWidth: Int = 0,
    var sourceHeight: Int = 0,
    var fitMode: String = "contain",
    var visible: Boolean = true,
    var sourceItemIds: MutableList<String> = mutableListOf(),
    var groupId: String = "",
    var cropLeft: Float = 0f,
    var cropTop: Float = 0f,
    var cropRight: Float = 1f,
    var cropBottom: Float = 1f,
    var posterTimeMs: Long = 0L,
    var videoOrder: Int = 0,
    var volume: Float = 1f
)

data class ProjectGroup(
    val id: String,
    var name: String,
    var collapsed: Boolean = false,
    var parentGroupId: String = ""
)

data class ProjectDocument(
    var name: String = "Sans titre",
    var canvasWidth: Int = 1920,
    var canvasHeight: Int = 1080,
    val items: MutableList<ProjectItem> = mutableListOf(),
    val schemaVersion: Int = 1,
    val groups: MutableList<ProjectGroup> = mutableListOf()
) {
    fun toJson(): JSONObject {
        val arr = JSONArray()
        items.forEach { item ->
            arr.put(JSONObject().apply {
                put("id", item.id); put("mediaPath", item.mediaPath)
                put("displayName", item.displayName); put("mimeType", item.mimeType)
                put("kind", item.kind); put("x", item.x); put("y", item.y)
                put("width", item.width); put("height", item.height)
                put("rotation", item.rotation); put("sha256", item.sha256)
                put("sourceWidth", item.sourceWidth); put("sourceHeight", item.sourceHeight)
                put("fitMode", item.fitMode); put("visible", item.visible)
                put("sourceItemIds", JSONArray(item.sourceItemIds))
                put("groupId", item.groupId)
                put("cropLeft", item.cropLeft); put("cropTop", item.cropTop)
                put("cropRight", item.cropRight); put("cropBottom", item.cropBottom)
                put("posterTimeMs", item.posterTimeMs); put("videoOrder", item.videoOrder)
                put("volume", item.volume)
            })
        }
        val groupArray = JSONArray()
        groups.forEach { group ->
            groupArray.put(JSONObject().put("id", group.id).put("name", group.name).put("collapsed", group.collapsed).put("parentGroupId", group.parentGroupId))
        }
        return JSONObject().apply {
            put("format", "studiomobile-project")
            put("schemaVersion", schemaVersion)
            put("name", name)
            put("canvas", JSONObject().put("width", canvasWidth).put("height", canvasHeight))
            put("items", arr)
            put("groups", groupArray)
        }
    }

    companion object {
        fun fromJson(json: JSONObject): ProjectDocument {
            require(json.optString("format") == "studiomobile-project") { "Format de projet non reconnu." }
            val version = json.optInt("schemaVersion", -1)
            require(version == 1) { "Version de projet non prise en charge : $version" }
            val canvas = json.getJSONObject("canvas")
            val doc = ProjectDocument(
                name = json.optString("name", "Sans titre"),
                canvasWidth = canvas.getInt("width"),
                canvasHeight = canvas.getInt("height")
            )
            json.optJSONArray("groups")?.let { ga ->
                for (i in 0 until ga.length()) {
                    val g = ga.getJSONObject(i)
                    doc.groups.add(ProjectGroup(g.getString("id"), g.optString("name", "Groupe"), g.optBoolean("collapsed", false), g.optString("parentGroupId", "")))
                }
            }
            val arr = json.getJSONArray("items")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                doc.items.add(ProjectItem(
                    id = o.getString("id"), mediaPath = o.getString("mediaPath"),
                    displayName = o.getString("displayName"), mimeType = o.getString("mimeType"),
                    kind = o.getString("kind"), x = o.getDouble("x").toFloat(),
                    y = o.getDouble("y").toFloat(), width = o.getDouble("width").toFloat(),
                    height = o.getDouble("height").toFloat(), sha256 = o.getString("sha256"),
                    rotation = o.optDouble("rotation", 0.0).toFloat(),
                    sourceWidth = o.optInt("sourceWidth", 0), sourceHeight = o.optInt("sourceHeight", 0),
                    fitMode = o.optString("fitMode", "cover").let { if (it in setOf("contain", "cover", "stretch")) it else "cover" },
                    visible = o.optBoolean("visible", true),
                    sourceItemIds = o.optJSONArray("sourceItemIds")?.let { refs -> MutableList(refs.length()) { index -> refs.getString(index) } } ?: mutableListOf(),
                    groupId = o.optString("groupId", ""),
                    cropLeft = o.optDouble("cropLeft", 0.0).toFloat(),
                    cropTop = o.optDouble("cropTop", 0.0).toFloat(),
                    cropRight = o.optDouble("cropRight", 1.0).toFloat(),
                    cropBottom = o.optDouble("cropBottom", 1.0).toFloat(),
                    posterTimeMs = o.optLong("posterTimeMs", 0L),
                    videoOrder = o.optInt("videoOrder", 0),
                    volume = o.optDouble("volume", 1.0).toFloat().coerceIn(0f, 1f)
                ))
            }
            return doc
        }
    }
}
