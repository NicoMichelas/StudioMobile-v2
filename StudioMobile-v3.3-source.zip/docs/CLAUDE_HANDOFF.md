# Handoff technique — Studio Mobile V3.3

## Dépôt et livraison

Conserver le dépôt `StudioMobile-v2`, le package `org.studiomobile.v2` et le workflow de ZIP source à la racine. L'utilisateur téléverse manuellement depuis Android :

1. `StudioMobile-v3.3-source.zip` à la racine ;
2. `build-android-v3.3.yml` dans `.github/workflows/`.

Ne pas renommer le dépôt. Ne pas compiler les anciens fichiers Kotlin éventuellement présents au root : le workflow extrait le ZIP dans un répertoire temporaire et compile uniquement celui-ci.

## Principes V3.3

- Priorité à la stabilité des imports volumineux et des aperçus : import atomique, un seul worker séquentiel de vignettes/posters, cache mémoire + disque.
- UI sombre compacte : barre projet, barre fichiers, barre outils défilante, panneau droit Calques/Vidéo repliable et redimensionnable.
- Pile de calques affichée du haut vers le bas ; appui long = drag/drop ; cases à cocher = sélection multiple.
- Groupes imbriqués via `ProjectGroup.parentGroupId`; les groupes sélectionnés peuvent être transformés ensemble.
- Fusion raster avec références aplaties vers les médias originaux ; ne jamais supprimer un média source référencé.
- Un seul lecteur Media3, TextureView, clipping du recadrage, aperçus des calques supérieurs au-dessus du lecteur.
- Pas d'Undo/Redo ni d'autosave avancé dans cette version.

## Sécurité du document

- `ProjectArchive.open` valide les chemins, les identifiants, les groupes et les références de fusion ; les SHA-256 des médias sont vérifiés à l'ouverture.
- Les groupes imbriqués doivent être acycliques.
- Les opérations asynchrones de sauvegarde et d'export travaillent sur des instantanés du document.

## À ne pas annoncer comme validé

Le code n'a pas été compilé localement avec le SDK Android dans cet environnement et n'a pas été testé sur le téléphone. Les contrôles de compilation GitHub Actions et tous les essais terrain restent à faire. En particulier : interactions tactiles, occlusion vidéo, reprise iOS, gros fichiers, rotation et stabilité après une longue session.
