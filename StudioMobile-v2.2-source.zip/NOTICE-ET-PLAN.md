# NOTICE — Studio Mobile v2.2 — export HTML autonome

## Livraison

Cette révision conserve la procédure de livraison habituelle :
- archive source `StudioMobile-v2.2-source.zip` à la racine du dépôt GitHub ;
- workflow `build-android-v2.2.yml` à remplacer dans `.github/workflows/` ;
- GitHub Actions compile l’APK debug et publie l’artefact `StudioMobile-v2.2-debug-apk`.

Aucun changement d’arborescence GitHub n’est demandé. Le ZIP doit contenir directement `settings.gradle.kts`, `build.gradle.kts` et `app/` à sa racine interne.

## Changement fonctionnel

Le bouton « Exporter HTML » crée maintenant un seul fichier `.html` (type MIME `text/html`) au lieu d’un ZIP contenant `index.html`, `project.json` et un dossier `media/`.

Les médias sont intégrés au HTML sous forme de data URI Base64. Cela répond au problème vérifié sur le Redmi : le gestionnaire de fichiers Xiaomi ouvre le document via une URI `content://`, et le navigateur ne peut pas résoudre les chemins relatifs vers les médias externes dans ce parcours.

Les photos dont le plus grand côté dépasse 2560 pixels sont réduites avant intégration. Les vidéos sont intégrées sans réencodage. Les vidéos du HTML sont créées avec `preload="none"` et leur source est affectée à la première interaction. Les images utilisent `loading="lazy"` et `decoding="async"`.

## Limites à connaître

- Base64 augmente la taille des médias d’environ un tiers.
- Le HTML contient nécessairement les données encodées de tous les médias ; le chargement/décodage vidéo est différé, mais le texte Base64 reste présent dans le document et peut consommer beaucoup de mémoire.
- Les navigateurs Android peuvent avoir des limites variables de taille de document, de mémoire et de lecture vidéo.
- Les vidéos sont intégrées sans conversion : leur lecture dépend du codec pris en charge par le navigateur.
- Les photos PNG réduites restent en PNG pour préserver la transparence ; les autres photos réduites sont encodées en JPEG.
- Le plafonnement de résolution est appliqué aux photos dépassant 2560 px ; les petites photos originales sont conservées telles quelles.

Cette livraison doit donc être considérée comme une version candidate à tester, particulièrement avec des vidéos lourdes et plusieurs médias. Aucune compatibilité universelle ni absence de plantage n’est garantie avant les tests sur l’appareil réel.

## Contrôles réalisés dans cette préparation

- structure ZIP et présence des fichiers Android vérifiées ;
- workflow configuré pour refuser un ZIP absent ou invalide ;
- workflow vérifie les marqueurs de la nouvelle implémentation avant compilation.

La compilation Android et le test sur Redmi doivent être confirmés par le résultat GitHub Actions puis par l’essai sur l’appareil.
