# Studio Mobile — première base consolidée (v0.4.0 / chantier v2.2)

## Intention
Construire un outil de composition spatiale multimédia, pas un simple éditeur vidéo. Le projet conserve les fichiers sources, décrit les éléments par des métadonnées et les affiche à travers des rendus de taille limitée. Les exports de visualisation sont séparés des fichiers sources.

## Modifications incluses dans cette base
- Stockage des médias importés et extraits de projets dans `filesDir/project-media/` plutôt que `cacheDir`, afin que le système Android ne les efface pas simplement comme du cache.
- Vignettes d'image et de vidéo à taille bornée, avec génération hors du dessin du canvas. Une photo 12 000 × 16 000 ne doit pas être décodée à pleine résolution pour déplacer son calque.
- Export PNG explicitement identifié comme aperçu : la version actuelle limite le grand côté à 2 560 px et dessine les vignettes. Le statut affiche les dimensions réelles du fichier généré.
- Export HTML : le paquet contient `index.html`, `project.json` et les médias originaux dans une archive ZIP. Le HTML s'ouvre en mode visualisation, avec un bouton Menu pour afficher les commandes d'édition.
- Aide à l'erreur de lecture vidéo si les médias ne sont pas trouvés dans le dossier extrait.

## Limites à ne pas masquer
- Je n'ai pas compilé cette source dans un environnement Android ni testé l'APK sur un appareil. Le workflow GitHub fourni compile et vérifie la présence de contrôles, mais il faut regarder le résultat du run.
- Le paquet HTML doit être **entièrement extrait** avant d'ouvrir `index.html`. Le navigateur ne sait généralement pas lire de façon fiable les médias référencés à l'intérieur d'un ZIP non extrait. Pour un partage en un seul fichier HTML, il faudra un export autonome séparé, avec une stratégie de taille et de mémoire (base64 gonfle la taille d'environ un tiers et consomme davantage de RAM).
- L'export PNG actuel est encore un aperçu, pas un rendu final à la résolution native. Un export natif très grand exige un moteur de rendu par tuiles ou une limite mémoire clairement gérée ; allouer directement un bitmap 12 000 × 16 000 peut nécessiter environ 732 MiB pour les pixels seuls.
- Le lecteur natif Android ne dispose pas encore de commandes de transport vidéo intégrées au canvas ; la lecture native et la timeline de lecture restent un chantier.
- Le recadrage avec poignées du canvas, réglage numérique des dimensions, couleur de fond, objets texte/audio, undo/redo, caméra virtuelle 2D/3D et contributions multi-auteurs ne sont pas annoncés comme terminés dans cette base.

## Architecture cible
1. **Archive projet `.studio`** : manifeste léger + originaux + identifiants stables + hashes d'intégrité + métadonnées. Les rendus et miniatures sont des caches régénérables et ne remplacent jamais les originaux.
2. **Moteur de médias** : accès par flux, copie tamponnée, empreinte en flux, déduplication par hash, décodage d'images échantillonné, image vidéo représentative, cache LRU borné par mémoire.
3. **Modèle de scène** : dimensions du canvas, fond, caméra/vue, objets (image, vidéo, texte, audio), transformées normalisées, ordre, visibilité, auteur, date, tags et identifiant stable.
4. **Rendu** : résolution d'aperçu adaptée à l'écran ; exports indépendants de la taille d'affichage ; rendu PNG par tuiles pour les très grands formats ; génération HTML dans un dossier autonome.
5. **Outils composables** : commandes séparées (sélection, déplacement, recadrage, texte, audio, caméra), même modèle de données sur téléphone et ordinateur, raccourcis clavier ajoutés côté ordinateur.
6. **Contributions** : fichier de contribution qui référence l'ID du projet et les IDs des objets d'origine ; les notes et audios d'une personne sont importés sur un calque dédié ; conflits signalés, aucune fusion silencieuse.
7. **Caméra virtuelle** : trajectoire et paramètres de caméra enregistrés comme données de scène. Une exportation vidéo 2D/3D pourra rendre la scène selon cette trajectoire sans modifier les médias d'origine.

## Ordre recommandé
A. Stabiliser import, lecture vidéo, sauvegarde et ouverture ; B. dimensions/cadrage/fond et PNG natif ; C. texte/audio/calques/annulation ; D. présentation HTML responsive et contrôles de lecture ; E. contributions et caméra virtuelle ; F. IA de classement seulement quand les métadonnées et filtres manuels sont stables.

## Contrôles manuels à faire après installation
- Importer une photo 12 000 × 16 000 et déplacer son calque pendant 30 secondes : pas de gel ni d'allocation plein format répétée.
- Importer deux vidéos de formats différents ; enregistrer, fermer, rouvrir le `.studio` et lire chacune.
- Exporter le ZIP HTML, l'extraire dans un dossier, ouvrir `index.html`, vérifier les photos et la lecture vidéo sur Android et sur ordinateur.
- Comparer les dimensions affichées dans le statut PNG avec les dimensions du PNG dans une visionneuse.
- Fermer/réouvrir l'application et vérifier que les médias importés sont encore présents dans le projet en cours.
