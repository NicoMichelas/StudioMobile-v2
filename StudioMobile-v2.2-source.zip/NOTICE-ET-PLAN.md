# NOTICE — Studio Mobile v2.2 — correctifs HTML, orientation et manipulation

## Livraison

La procédure reste strictement inchangée :
- archive source `StudioMobile-v2.2-source.zip` à la racine du dépôt GitHub ;
- workflow `build-android-v2.2.yml` à remplacer dans `.github/workflows/` ;
- GitHub Actions publie l'artefact `StudioMobile-v2.2-debug-apk`.

Aucun renommage ni déplacement du ZIP n'est demandé. Le ZIP contient directement `settings.gradle.kts`, `build.gradle.kts` et `app/` à sa racine interne.

## Diagnostic du HTML transmis le 6 novembre 2026

Le fichier reçu contient le manifeste et les données Base64 des deux images, puis s'interrompt au milieu de la donnée Base64 de la vidéo. Il ne contient ni la fermeture de la chaîne média, ni `</script>`, ni `</body></html>`. Le navigateur reçoit donc un document HTML incomplet : l'interface statique apparaît, mais le script qui construit le projet ne peut pas s'exécuter correctement.

## Correctifs apportés dans cette itération

- Génération du HTML complet dans un fichier temporaire local avant la copie vers le document Android choisi.
- Vérification du nombre d'octets lus pour chaque média intégré.
- Vérification de la fermeture `</body></html>` avant copie et comparaison du nombre d'octets copiés vers la destination.
- La génération ne doit plus afficher un succès si le document temporaire est incomplet ou si la copie est interrompue.
- Lecture de l'orientation EXIF pour les vignettes Android et pour les images réduites lors de l'export HTML.
- Ajout d'une poignée haut-droite pour tourner et d'une poignée bas-droite pour redimensionner, dans l'éditeur natif et dans le HTML.
- Ajout de la rotation dans le manifeste du projet, avec valeur par défaut 0° pour conserver la compatibilité des anciens projets `.studio`.
- Lecture vidéo native par toucher sur un calque vidéo ou via le bouton « Lire vidéo » ; le lecteur Android s'ouvre avec commandes de lecture.
- Dans le HTML, conversion différée de la data URI vidéo en Blob URL avant lecture, afin d'éviter de dépendre d'une URL `data:` directement utilisée par le lecteur média.

## Limites connues

- Les vidéos ne sont pas réencodées ; la lecture dépend des codecs pris en charge par Android ou le navigateur.
- Le HTML autonome embarque toujours les médias en Base64, avec environ 33 % de surcoût de taille. Les vidéos restent présentes dans le texte du document avant lecture.
- Les gros projets peuvent encore rencontrer des limites de stockage ou de mémoire dans le navigateur Android.
- Le lecteur vidéo natif est une fenêtre de lecture superposée au projet, pas encore un lecteur intégré dans le rectangle du calque sur le canevas.

## Niveau de validation

Le HTML reçu a été inspecté octet par octet et son interruption pendant la vidéo est confirmée. Les correctifs source et le workflow doivent encore passer la compilation GitHub Actions puis les tests sur Redmi. Aucun APK compilé ni test physique n'est revendiqué à ce stade.
