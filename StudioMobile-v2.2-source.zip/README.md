# Studio Mobile v2 — fondation portable

**État : prototype de fondation, pas encore une version de production.** Cette livraison vise un premier socle Android compilable : canevas 2D, import de médias, sauvegarde/ouverture d'un projet `.studio` autonome. L'export vidéo composé et l'export HTML interactif ne sont pas encore implémentés dans cette version ; ils sont documentés comme étapes suivantes et ne doivent pas être présentés comme fonctionnels.

## Architecture
- `app`: interface Android native Kotlin.
- `ProjectDocument`: modèle indépendant de l'interface.
- `.studio`: archive ZIP contenant `manifest.json` et les médias embarqués.
- Import via Storage Access Framework (SAF), sans permission globale de stockage.
- Détection des doublons à l'import par SHA-256 au sein du projet.
- Ouverture contrôlée du manifeste et résolution des médias intégrés.
- GitHub Actions compile l'APK debug et publie l'APK comme artifact.

## Prérequis
- Android Studio récent, JDK 17, Android SDK.
- Android 8.0+ (API 26), testé par compilation CI uniquement lorsqu'un workflow est vert.
- L'APK debug n'est pas signée pour une distribution Play Store.

## Fonctions dans ce socle
- Créer un canevas.
- Importer images et vidéos.
- Afficher et déplacer les éléments sur le canevas.
- Enregistrer un fichier `.studio`.
- Ouvrir un fichier `.studio` sur un autre appareil sans fichiers source.
- Afficher une progression de l'import, de la sauvegarde et de l'ouverture.

## Limites connues
- Les vidéos sont représentées par une vignette de remplacement dans le canevas ; la lecture interactive complète est à ajouter.
- L'export MP4 avec composition de plusieurs éléments n'est pas encore livré.
- L'export HTML ZIP autonome et l'export PNG d'aperçu sont disponibles dans cette itération ; voir `docs/NOTICE_CHATGPT_ITERATION.md` pour leurs limites.
- Pas encore de bibliothèque globale partagée entre projets, historique de versions ou collaboration.
- L'import d'un projet extrait temporairement les médias dans le cache applicatif ; Android peut supprimer ce cache. Le projet `.studio` reste la source durable.
- Le format `.studio` est versionné (`schemaVersion`), mais la migration automatique de versions n'est pas encore implémentée.

## Format `.studio`
Archive ZIP :
- `manifest.json`: dimensions du canevas, liste d'entités, coordonnées normalisées, ordre, type et SHA-256.
- `media/<id>_<nom>`: octets originaux des médias.

Les coordonnées sont normalisées entre 0 et 1, afin de conserver la composition entre tailles d'écran différentes.

## Compiler sur GitHub depuis un téléphone — méthode recommandée

Cette méthode évite d'extraire le projet manuellement dans GitHub et évite qu'anciens fichiers restent mélangés avec les nouveaux. L'archive source est la seule source de vérité pour la compilation.

**Prérequis unique :** le dépôt GitHub doit déjà contenir le workflow actif `.github/workflows/build-android.yml`. GitHub ne peut pas exécuter un workflow qui se trouve uniquement à l'intérieur d'une archive ZIP.

1. Dans le dépôt, vérifie que `.github/workflows/build-android.yml` existe. Si nécessaire, crée ce fichier et colle le workflow fourni avec cette livraison.
2. Téléverse `StudioMobile-v2-iteration-fixed.zip` à la racine du dépôt, sans le décompresser dans GitHub. Le fichier doit porter exactement ce nom.
3. Ouvre **Actions → Build Studio Mobile Android APK**. Tu peux aussi lancer le workflow avec **Run workflow**.
4. Le workflow teste l'archive ZIP, l'extrait dans un répertoire propre, vérifie les fichiers Android requis, puis compile le projet extrait. Il ne mélange pas le contenu avec d'anciens fichiers du dépôt.
5. En cas de réussite, télécharge l'artefact `StudioMobile-debug-apk` depuis l'exécution. En cas d'échec, ouvre l'étape rouge et copie les premières lignes de l'erreur.

**Pourquoi ne pas extraire l'archive dans le dépôt ?** GitHub ne décompresse pas les ZIP comme un gestionnaire de fichiers ; une extraction manuelle depuis le téléphone est source d'oublis et de fichiers obsolètes. Le workflow extrait donc l'archive sur le runner GitHub, dans un dossier neuf.

## Tests minimums avant usage réel
- Importer une image et une vidéo.
- Déplacer les éléments, enregistrer `test.studio`.
- Fermer l'application, puis rouvrir `test.studio`.
- Copier le fichier vers un autre téléphone où les médias sources ne sont pas présents.
- Vérifier les dimensions, positions et le nombre d'entités.
- Ne pas utiliser cette version comme unique copie d'un projet important.

## Justificatif technique
Voir `docs/ARCHITECTURE.md`, `docs/ROADMAP.md` et `docs/CLAUDE_HANDOFF.md`.


## Iteration 0.3.0 — interface et export HTML

Cette itération restaure une présentation inspirée de Studio 26 : fond sombre vert/bleu, accent ambre, barres d’outils horizontales adaptées au téléphone, bandeau de calques sélectionnables et aperçu média léger. Les actions de calque, le déplacement et le redimensionnement sont accessibles dans l’éditeur natif.

**Export HTML** produit un ZIP autonome contenant `index.html`, `project.json` et les médias originaux. Pour l’ouvrir, extraire le ZIP dans un dossier puis ouvrir `index.html` dans un navigateur. Ce format évite de convertir les vidéos en chaînes base64 dans une énorme page HTML, ce qui peut provoquer des erreurs mémoire sur Android. L’export PNG reste un aperçu composite basse résolution et ne doit pas être considéré comme un rendu final haute résolution.

Validation : archive et structure vérifiées, JavaScript de l’export vérifié statiquement. La compilation Android et le test sur appareil doivent encore être confirmés par GitHub Actions et sur le téléphone ; aucune exécution sur appareil n’est prétendue ici.
