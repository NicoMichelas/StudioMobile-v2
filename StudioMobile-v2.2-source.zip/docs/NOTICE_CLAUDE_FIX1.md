# Notice — correctif Claude #1 : rendu du canvas (jalon A, partie 1)

Ce document explique ce qui a été modifié, pourquoi, comment l'installer, et ce qui reste à faire. Il s'adresse autant à toi qu'à ChatGPT à sa reprise — tout ce qui suit découle directement de la revue déjà validée ensemble (voir `CLAUDE_HANDOFF.md` et `ARCHITECTURE.md`).

## Ce qui a changé

**Nouveau fichier** : `app/src/main/java/org/studiomobile/v2/ThumbnailCache.kt`
**Fichier modifié** : `app/src/main/java/org/studiomobile/v2/MainActivity.kt` (uniquement la classe `ProjectCanvasView`, rien d'autre)

Aucun autre fichier n'a été touché : `ProjectDocument.kt`, `ProjectArchive.kt`, le format `.studio`, le manifeste Android, les scripts Gradle sont strictement identiques à la version précédente.

## Pourquoi (diagnostic confirmé dans le code)

`ProjectCanvasView.onDraw()` appelait `BitmapFactory.decodeFile()` directement, à la résolution native du fichier, sans aucun cache, à chaque image redessinée — c'est-à-dire à chaque mouvement du doigt, pour chaque élément du projet. Pour une photo de 12000×16000 pixels, cela représente environ 768 Mo à décoder, potentiellement plusieurs fois par seconde. C'est la cause unique des trois problèmes remontés : absence de prévisualisation sur les grandes images, lenteur du déplacement, instabilité à l'import d'images extrêmes.

## Ce que fait le correctif

1. **`ThumbnailCache`** décode chaque image une seule fois, à une taille plafonnée (512 px de long côté), via la technique standard Android en deux passes : lecture des dimensions seules (`inJustDecodeBounds`), calcul d'un facteur de sous-échantillonnage, puis décodage direct à cette taille réduite. Le fichier source n'est jamais chargé en entier, quelle que soit sa résolution.
2. Le cache est **borné en mémoire** (`LruCache`, limité à un huitième du tas disponible de l'application) : il ne peut pas grossir indéfiniment et s'auto-régule.
3. La génération se fait **en arrière-plan** (thread dédié), jamais dans `onDraw()`. Pendant la génération, le nom du fichier reste affiché (comme avant) ; dès que la vignette est prête, l'affichage se met à jour automatiquement.
4. **Nouveauté** : les vidéos ont désormais une vraie vignette, extraite via `MediaMetadataRetriever` (API native Android dédiée à cet usage), avec le même mécanisme de cache et de génération en arrière-plan que les photos. Jusqu'ici, aucune prévisualisation vidéo n'existait dans le code.
5. `onDraw()` ne contient plus aucun appel direct à `BitmapFactory` ni aucune lecture de fichier : il lit uniquement le cache.

## Comment installer cette version

Procédure identique à la première fois :
1. Remplace le contenu de ton dépôt GitHub par celui de cette archive (ou copie simplement les deux fichiers Kotlin ci-dessus si tu préfères ne pas tout réimporter).
2. Laisse GitHub Actions compiler (même workflow qu'avant, rien n'a changé dans la configuration de build).
3. Télécharge l'artefact `StudioMobile-debug-apk`, installe-le sur ton téléphone comme précédemment.

Je n'ai pas pu compiler ni exécuter ce code moi-même dans cet environnement (pas de SDK Android ici) — la vérification se fait, comme convenu, via GitHub Actions puis un test réel sur ton appareil.

## Ce qu'il faut tester pour confirmer

- Importer à nouveau l'image 12000×16000 : une vignette doit apparaître après un court délai, sans blocage de l'application.
- Importer une vidéo : une image fixe représentative doit apparaître (plus seulement le nom).
- Déplacer plusieurs éléments à la suite : le glissement doit être net, sans saccade, même avec la grande image dans le projet.

## Ce qui n'est volontairement pas inclus dans ce correctif

Pour rester concentré sur le point bloquant, ce correctif ne touche pas : le multi-touch réel (toujours un seul doigt suivi), la lecture vidéo au clic, l'autosave, Undo/Redo, les groupes. Ces points restent au plan du jalon A tel que discuté, et peuvent être enchaînés dans un prochain correctif une fois celui-ci validé sur appareil.
