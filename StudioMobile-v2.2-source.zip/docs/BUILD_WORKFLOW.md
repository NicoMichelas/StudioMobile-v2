# GitHub Actions — méthode de compilation

Le dépôt doit contenir un workflow actif à `.github/workflows/build-android.yml`. Un YAML situé seulement dans un ZIP n'est pas visible par GitHub Actions.

Le workflow fourni attend `StudioMobile-v2-iteration-fixed.zip` à la racine du dépôt. Il vérifie l'intégrité ZIP, extrait le projet dans `_studio_mobile_src` (dossier neuf), vérifie les fichiers indispensables, utilise JDK 17 et Gradle 8.11.1, puis compile `:app:assembleDebug`. Il publie l'APK debug comme artefact pendant 14 jours.

Le build CI confirme la compilation, pas le fonctionnement réel sur un téléphone. Après une compilation verte, il faut encore tester import d'une grande image, déplacement/redimensionnement, sauvegarde/réouverture et export PNG/HTML.
