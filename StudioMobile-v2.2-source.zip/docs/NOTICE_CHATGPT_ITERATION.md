# Iteration — grandes images, calques et exports initiaux

Cette itération part de l'archive `V2-fixed` fournie par l'utilisateur.

## Modifications apportées

- Le sous-échantillonnage des images est calculé à partir du plus grand côté. Cela évite notamment qu'une image panoramique ou très large soit décodée à pleine résolution parce que son petit côté est inférieur à la cible.
- Ajout d'une poignée de redimensionnement en bas à droite de l'objet sélectionné, plus des commandes Taille + / Taille −.
- Ajout de commandes pour modifier l'ordre des calques et supprimer l'objet sélectionné.
- Ajout d'un export PNG du composite d'aperçu, limité à 2560 px par dimension et basé sur les vignettes en cache. Ce n'est pas encore un export maître haute résolution.
- Ajout d'un export HTML ZIP autonome contenant `index.html`, `project.json` et les médias intégrés. Pour le consulter, extraire le ZIP et ouvrir `index.html` dans un navigateur. Les vidéos sont incluses et peuvent être lues dans ce navigateur.
- Le cache des vignettes est vidé à l'ouverture d'un autre projet afin d'éviter de réutiliser une ancienne vignette portant le même identifiant.

## Limites connues

- L'export MP4 natif n'est pas encore implémenté. Il nécessite un moteur de composition et d'encodage, ainsi qu'une définition des règles temporelles (ordre des vidéos, durée d'affichage des images, audio et transitions). Le bouton HTML ZIP ne doit pas être confondu avec un export MP4.
- L'export PNG est un aperçu et peut utiliser des vignettes ; il ne garantit pas la pleine résolution des originaux.
- Les groupes, Undo/Redo, zoom/panoramique du canvas, opacité, modes de fusion et lecture vidéo directement dans l'éditeur ne sont pas encore inclus dans cette itération.
- Le test de compilation Android et le test sur appareil doivent être effectués via GitHub Actions et le téléphone de l'utilisateur. Aucun résultat de compilation n'est revendiqué ici.
