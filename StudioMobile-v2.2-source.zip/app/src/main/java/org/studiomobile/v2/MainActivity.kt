package org.studiomobile.v2

import android.app.Activity
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.UUID
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var canvasView: ProjectCanvasView
    private val doc = ProjectDocument()
    private val mediaFiles = mutableMapOf<String, File>()
    private var selectedId: String? = null
    private var resizeActive = false
    private var resizeStartWidth = 0f
    private var resizeStartHeight = 0f
    private var resizeStartX = 0f
    private var resizeStartY = 0f

    private val exportPng = registerForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null) exportCanvasPng(uri)
    }
    private val exportHtmlPackage = registerForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { uri ->
        if (uri != null) exportInteractivePackage(uri)
    }

    private val importPicker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        status.text = "Importation de ${uris.size} fichier(s)…"
        thread {
            var done = 0
            val errors = mutableListOf<String>()
            uris.forEach { uri ->
                try {
                    val imported = ProjectArchive.importMedia(this, uri, contentResolver) { bytes ->
                        runOnUiThread { status.text = "Import : ${importedSafeName(uri)} — ${bytes / 1024} Ko" }
                    }
                    val duplicate = doc.items.firstOrNull { it.sha256 == imported.item.sha256 }
                    if (duplicate == null) {
                        val item = imported.item
                        item.x = (0.18f + (doc.items.size % 4) * 0.2f).coerceIn(0.1f, 0.9f)
                        item.y = (0.22f + (doc.items.size % 3) * 0.25f).coerceIn(0.1f, 0.9f)
                        doc.items.add(item); mediaFiles[item.id] = imported.cachedFile
                    } else imported.cachedFile.delete()
                } catch (e: Exception) { errors.add("${uri.lastPathSegment}: ${e.message}") }
                done++
                runOnUiThread { status.text = "Importation : $done/${uris.size}" }
            }
            runOnUiThread {
                progress.visibility = View.GONE
                status.text = if (errors.isEmpty()) "Import terminé : ${doc.items.size} élément(s). Doublons ignorés." else "Import terminé avec ${errors.size} erreur(s) : ${errors.first()}"
                canvasView.invalidate(); refreshLayerStrip()
            }
        }
    }

    private val openProject = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) openProjectUri(uri)
    }
    private val saveProject = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) saveProjectUri(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 6)
            setBackgroundColor(Color.rgb(24, 34, 37))
        }
        val title = TextView(this).apply {
            text = "STUDIO  ·  MOBILE"
            textSize = 20f
            setTextColor(Color.rgb(237, 238, 233))
            setTypeface(null, Typeface.BOLD)
            setPadding(8, 4, 8, 8)
        }
        root.addView(title)

        // Horizontal tool strips keep every action reachable on narrow phone screens.
        fun toolStrip(): Pair<HorizontalScrollView, LinearLayout> {
            val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            scroll.addView(row)
            root.addView(scroll, LinearLayout.LayoutParams(-1, -2))
            return scroll to row
        }
        val (_, actions) = toolStrip()
        actions.addView(makeButton("＋ Importer", 0) { importPicker.launch(arrayOf("image/*", "video/*")) })
        actions.addView(makeButton("Ouvrir .studio", 1) { openProject.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) })
        actions.addView(makeButton("Enregistrer", 2) { saveProject.launch("${safeDocName(doc.name)}.studio") })
        actions.addView(makeButton("Exporter HTML", 9) { exportHtmlPackage.launch("${safeDocName(doc.name)}-studio.html") })
        actions.addView(makeButton("Aperçu PNG", 3) { exportPng.launch("${safeDocName(doc.name)}-apercu.png") })

        val (_, tools) = toolStrip()
        tools.addView(makeButton("Calque ↑", 4) { moveSelectedLayer(1); refreshLayerStrip() })
        tools.addView(makeButton("Calque ↓", 5) { moveSelectedLayer(-1); refreshLayerStrip() })
        tools.addView(makeButton("Taille +", 6) { resizeSelected(1.1f) })
        tools.addView(makeButton("Taille −", 7) { resizeSelected(0.9f) })
        tools.addView(makeButton("Supprimer", 8) { deleteSelected(); refreshLayerStrip() })

        layerStrip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(2, 5, 2, 5)
            setBackgroundColor(Color.rgb(31, 43, 47))
        }
        val layerScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(layerStrip)
        }
        root.addView(layerScroll, LinearLayout.LayoutParams(-1, 58))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        root.addView(progress, LinearLayout.LayoutParams(-1, 8))
        status = TextView(this).apply {
            text = "Prêt · importe des images ou vidéos pour composer"
            textSize = 12f
            setTextColor(Color.rgb(154, 172, 176))
            setPadding(8, 5, 8, 5)
        }
        root.addView(status)
        canvasView = ProjectCanvasView()
        root.addView(canvasView, LinearLayout.LayoutParams(-1, 0, 1f))
        val hint = TextView(this).apply {
            text = "Touchez un calque pour le sélectionner · glissez pour déplacer · poignée orange pour redimensionner"
            textSize = 11f
            setTextColor(Color.rgb(154, 172, 176))
            setPadding(6, 6, 6, 2)
        }
        root.addView(hint)
        setContentView(root)
        refreshLayerStrip()
    }

    private lateinit var layerStrip: LinearLayout

    private fun refreshLayerStrip() {
        if (!::layerStrip.isInitialized) return
        layerStrip.removeAllViews()
        if (doc.items.isEmpty()) {
            layerStrip.addView(TextView(this).apply {
                text = "CALQUES  ·  aucun média"
                textSize = 12f; setTextColor(Color.rgb(154, 172, 176)); setPadding(10, 10, 10, 10)
            })
            return
        }
        doc.items.forEachIndexed { index, item ->
            val selected = item.id == selectedId
            val button = TextView(this).apply {
                text = "${if (item.kind == "video") "▶" else "▧"} ${index + 1}. ${item.displayName}"
                textSize = 11f
                maxWidth = 220
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
                gravity = Gravity.CENTER_VERTICAL
                setPadding(10, 6, 10, 6)
                setTextColor(if (selected) Color.rgb(24, 34, 37) else Color.rgb(237, 238, 233))
                setBackgroundColor(if (selected) Color.rgb(227, 168, 87) else Color.rgb(35, 48, 54))
                setOnClickListener { selectedId = item.id; canvasView.invalidate(); refreshLayerStrip() }
                layoutParams = LinearLayout.LayoutParams(-2, -1).apply { marginEnd = 5 }
            }
            layerStrip.addView(button)
        }
    }

    private fun makeButton(label: String, id: Int, action: () -> Unit): Button = Button(this).apply {
        text = label; textSize = 11f; isAllCaps = false; setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginEnd = 4 }
        setTextColor(Color.rgb(237, 238, 233))
        setBackgroundColor(Color.rgb(46, 111, 104))
        minWidth = 0
    }

    private fun saveProjectUri(uri: Uri) {
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        status.text = "Préparation de l'archive…"
        thread {
            try {
                contentResolver.openOutputStream(uri, "wt")?.use { out ->
                    ProjectArchive.save(this, doc, mediaFiles, out) { p ->
                        runOnUiThread { progress.isIndeterminate = false; progress.progress = p; status.text = "Enregistrement : $p%" }
                    }
                } ?: throw Exception("Impossible d'écrire le fichier choisi.")
                runOnUiThread { progress.visibility = View.GONE; status.text = "Projet enregistré : ${doc.items.size} élément(s)." }
            } catch (e: Exception) {
                runOnUiThread { progress.visibility = View.GONE; status.text = "Échec de sauvegarde : ${e.message}" }
            }
        }
    }

    private fun openProjectUri(uri: Uri) {
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        status.text = "Ouverture et vérification du projet…"
        thread {
            try {
                val (loaded, loadedFiles) = contentResolver.openInputStream(uri)?.use { input ->
                    ProjectArchive.open(this, input) { p -> runOnUiThread { status.text = "Lecture de l'archive…"; progress.progress = p } }
                } ?: throw Exception("Impossible de lire ce fichier.")
                runOnUiThread {
                    ThumbnailCache.clear()
                    doc.name = loaded.name; doc.canvasWidth = loaded.canvasWidth; doc.canvasHeight = loaded.canvasHeight
                    doc.items.clear(); doc.items.addAll(loaded.items)
                    mediaFiles.clear(); mediaFiles.putAll(loadedFiles)
                    progress.visibility = View.GONE
                    status.text = "Projet ouvert et vérifié : ${doc.items.size} élément(s)."
                    canvasView.invalidate(); refreshLayerStrip()
                }
            } catch (e: Exception) {
                runOnUiThread { progress.visibility = View.GONE; status.text = "Ouverture impossible : ${e.message}" }
            }
        }
    }

    private fun moveSelectedLayer(direction: Int) {
        val index = doc.items.indexOfFirst { it.id == selectedId }
        if (index < 0) { status.text = "Sélectionne d'abord un calque."; return }
        val target = (index + direction).coerceIn(0, doc.items.lastIndex)
        if (target != index) {
            val item = doc.items.removeAt(index)
            doc.items.add(target, item)
            canvasView.invalidate(); refreshLayerStrip()
        }
    }

    private fun resizeSelected(factor: Float) {
        val item = doc.items.firstOrNull { it.id == selectedId }
        if (item == null) { status.text = "Sélectionne d'abord un calque."; return }
        item.width = (item.width * factor).coerceIn(0.04f, 1.8f)
        item.height = (item.height * factor).coerceIn(0.04f, 1.8f)
        canvasView.invalidate()
    }

    private fun deleteSelected() {
        val id = selectedId ?: run { status.text = "Sélectionne d'abord un calque."; return }
        doc.items.removeAll { it.id == id }
        mediaFiles.remove(id)?.let { it.delete() }
        ThumbnailCache.remove(id)
        selectedId = null
        canvasView.invalidate(); refreshLayerStrip()
        status.text = "Calque supprimé. Enregistre le projet pour conserver ce changement."
    }

    private fun exportCanvasPng(uri: Uri) {
        status.text = "Rendu de l'aperçu PNG…"
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        thread {
            var bitmap: Bitmap? = null
            try {
                // PNG export is intentionally an editor-preview export, not the
                // final-resolution renderer. It uses cached, bounded thumbnails.
                val exportScale = minOf(1f, 2560f / doc.canvasWidth.coerceAtLeast(1), 2560f / doc.canvasHeight.coerceAtLeast(1))
                val outW = (doc.canvasWidth * exportScale).toInt().coerceAtLeast(1)
                val outH = (doc.canvasHeight * exportScale).toInt().coerceAtLeast(1)
                val outputBitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
                bitmap = outputBitmap
                val canvas = Canvas(outputBitmap)
                canvas.drawColor(Color.WHITE)
                val snapshot = doc.items.toList()
                // Try to prepare missing previews off the UI thread before rendering.
                snapshot.forEach { item ->
                    val file = mediaFiles[item.id]
                    if (file != null && ThumbnailCache.get(item.id) == null) ThumbnailCache.generate(item.id, file, item.kind)
                }
                val localPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                snapshot.forEach { item ->
                    val cx = item.x * outW; val cy = item.y * outH
                    val w = item.width * outW; val h = item.height * outH
                    val rect = RectF(cx-w/2, cy-h/2, cx+w/2, cy+h/2)
                    val thumb = ThumbnailCache.get(item.id)
                    if (thumb != null) canvas.drawBitmap(thumb, null, rect, localPaint)
                    else {
                        localPaint.color = Color.LTGRAY
                        canvas.drawRoundRect(rect, 8f, 8f, localPaint)
                        localPaint.color = Color.DKGRAY; localPaint.textSize = 22f
                        canvas.drawText(item.displayName.take(30), rect.left+8f, rect.centerY(), localPaint)
                    }
                }
                contentResolver.openOutputStream(uri)?.use { out ->
                    if (!outputBitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) throw IOException("La compression PNG a échoué.")
                } ?: throw IOException("Impossible d'écrire le PNG choisi.")
                runOnUiThread { status.text = "PNG d’aperçu exporté en ${outW} × ${outH} px (limité à 2560 px par côté, vignettes utilisées)." }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Export PNG échoué : ${e.message}" }
            } finally {
                bitmap?.recycle()
                runOnUiThread { progress.visibility = View.GONE }
            }
        }
    }

    private fun exportInteractivePackage(uri: Uri) {
        status.text = "Préparation du HTML autonome…"
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        thread {
            val prepared = mutableListOf<File>()
            try {
                val manifest = doc.toJson().toString().replace("</", "<\\/")
                contentResolver.openOutputStream(uri, "wt")?.use { raw ->
                    fun write(value: String) { raw.write(value.toByteArray(Charsets.UTF_8)) }
                    write("""<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,user-scalable=no">
<title>Studio Mobile — ${safeDocName(doc.name)}</title><style>
:root{--bg:#182225;--panel:#1f2b2f;--panel2:#233036;--line:#324046;--ink:#EDEEE9;--dim:#9AACB0;--accent:#E3A857}
*{box-sizing:border-box}html,body{margin:0;height:100%;font:14px system-ui,sans-serif;background:var(--bg);color:var(--ink)}body{display:flex;flex-direction:column;overflow:hidden}
header{display:flex;align-items:center;gap:10px;padding:10px 12px;background:var(--panel);border-bottom:1px solid var(--line);flex-shrink:0}header strong{letter-spacing:.04em}#menuToggle{background:var(--panel2);border:1px solid var(--line);color:var(--ink);border-radius:9px;padding:8px 11px}#dim{margin-left:auto;color:var(--dim);font-size:11px;white-space:nowrap}
.toolbar{display:flex;gap:6px;overflow-x:auto;padding:8px;background:var(--panel2);border-bottom:1px solid var(--line);flex-shrink:0}.toolbar button{background:var(--panel);border:1px solid var(--line);color:var(--ink);border-radius:7px;padding:7px 10px;white-space:nowrap;font-size:12px}
body.view-mode .toolbar,body.view-mode aside{display:none}main{display:flex;flex:1;min-height:0}.zone{flex:1;min-width:0;display:flex;align-items:center;justify-content:center;overflow:auto;padding:12px;background-color:var(--bg);background-image:linear-gradient(45deg,var(--panel2) 25%,transparent 25%),linear-gradient(-45deg,var(--panel2) 25%,transparent 25%),linear-gradient(45deg,transparent 75%,var(--panel2) 75%),linear-gradient(-45deg,transparent 75%,var(--panel2) 75%);background-size:16px 16px;background-position:0 0,0 8px,8px -8px,-8px 0}
#stage{position:relative;flex-shrink:0;background:#0f1517;border:1px solid var(--line);box-shadow:0 8px 30px #0007;overflow:hidden}.item{position:absolute;transform:translate(-50%,-50%);overflow:hidden;background:#233036;outline:1px solid #324046;touch-action:none}.item.active{outline:2px solid var(--accent);z-index:999!important}.item img,.item video{width:100%;height:100%;object-fit:cover;display:block}.handle{position:absolute;right:0;bottom:0;width:18px;height:18px;background:var(--accent);border:2px solid #182225;border-radius:50%;touch-action:none}body.view-mode .handle,body.view-mode .item{outline:none}
aside{width:88px;flex-shrink:0;overflow:auto;padding:7px;background:var(--panel);border-left:1px solid var(--line)}.layer{width:100%;min-height:48px;margin-bottom:7px;border:2px solid transparent;border-radius:8px;background:#0f1517;color:var(--ink);font-size:10px;padding:6px;overflow:hidden}.layer.active{border-color:var(--accent)}footer{padding:7px 10px;background:var(--panel);border-top:1px solid var(--line);font-size:11px;color:var(--dim);flex-shrink:0}button:active{transform:translateY(1px)}
</style></head><body><header><strong>STUDIO · MOBILE</strong><button id="menuToggle" aria-expanded="false">☰ Menu</button><span id="dim"></span></header>
<div class="toolbar"><button id="up">Calque ↑</button><button id="down">Calque ↓</button><button id="bigger">Taille +</button><button id="smaller">Taille −</button><button id="reset">Centrer</button><button id="playAll">Lire les vidéos</button></div>
<main><section class="zone"><div id="stage"></div></section><aside id="layers"></aside></main><footer id="status">Projet autonome · médias intégrés à ce fichier HTML. Les photos sont plafonnées à 2560 px sur leur plus grand côté. Les vidéos sont chargées à la demande.</footer>
<script>
const doc = $manifest;
const mediaSources = {
""")
                    doc.items.forEachIndexed { index, item ->
                        val source = mediaFiles[item.id] ?: throw IOException("Média absent : ${item.displayName}")
                        val fileToEmbed = if (item.kind == "image") prepareHtmlImage(source, item.mimeType).also { if (it != source) prepared.add(it) } else source
                        val mime = if (item.kind == "image" && fileToEmbed != source && item.mimeType != "image/png") "image/jpeg" else item.mimeType
                        write(JSONObjectQuote(item.id) + ":\"data:$mime;base64,")
                        val nonClosing = object : java.io.FilterOutputStream(raw) { override fun close() { flush() } }
                        java.util.Base64.getEncoder().wrap(nonClosing).use { encoded ->
                            fileToEmbed.inputStream().buffered().use { input -> input.copyTo(encoded, 64 * 1024) }
                        }
                        write("\"")
                        if (index < doc.items.lastIndex) write(",")
                        val pct = ((index + 1) * 100) / doc.items.size.coerceAtLeast(1)
                        runOnUiThread { progress.isIndeterminate = false; progress.progress = pct; status.text = "Intégration des médias : $pct%" }
                    }
                    write("""
};
const stage=document.getElementById('stage'),rail=document.getElementById('layers'),status=document.getElementById('status');
let selected=doc.items.length?doc.items[doc.items.length-1].id:null;
document.body.classList.add('view-mode');const menuToggle=document.getElementById('menuToggle');menuToggle.onclick=()=>{const viewing=document.body.classList.toggle('view-mode');menuToggle.setAttribute('aria-expanded',String(!viewing));menuToggle.textContent=viewing?'☰ Menu':'✕ Fermer';};
function fitStage(){const zone=document.querySelector('.zone');const scale=Math.min(1,(zone.clientWidth-24)/doc.canvas.width,(zone.clientHeight-24)/doc.canvas.height);stage.style.width=Math.max(1,doc.canvas.width*scale)+'px';stage.style.height=Math.max(1,doc.canvas.height*scale)+'px'}fitStage();window.addEventListener('resize',fitStage);document.getElementById('dim').textContent=doc.canvas.width+' × '+doc.canvas.height+' px';
function byId(id){return doc.items.find(x=>x.id===id)}function sourceFor(item){return mediaSources[item.id]}
function loadVideo(video,item){if(!video.src){video.src=sourceFor(item);video.load();}}
function select(id){selected=id;renderSelection()}
function renderSelection(){document.querySelectorAll('.item').forEach(e=>e.classList.toggle('active',e.dataset.id===selected));document.querySelectorAll('.layer').forEach(e=>e.classList.toggle('active',e.dataset.id===selected))}
function render(){stage.innerHTML='';rail.innerHTML='';doc.items.forEach((item,index)=>{const box=document.createElement('div');box.className='item';box.dataset.id=item.id;box.style.left=(item.x*100)+'%';box.style.top=(item.y*100)+'%';box.style.width=(item.width*100)+'%';box.style.height=(item.height*100)+'%';box.style.zIndex=String(index+1);let media;if(item.kind==='video'){media=document.createElement('video');media.controls=true;media.preload='none';media.playsInline=true;media.setAttribute('webkit-playsinline','');media.addEventListener('pointerdown',()=>loadVideo(media,item),{once:true});media.addEventListener('error',()=>{status.textContent='Vidéo illisible dans ce navigateur ou format non pris en charge.'},{once:true})}else if(item.kind==='image'){media=document.createElement('img');media.loading='lazy';media.decoding='async';media.src=sourceFor(item);media.alt=item.displayName}else{media=document.createElement('div');media.textContent=item.displayName}box.appendChild(media);const handle=document.createElement('div');handle.className='handle';box.appendChild(handle);box.addEventListener('pointerdown',e=>{if(document.body.classList.contains('view-mode'))return;if(e.target===media&&item.kind==='video')return;e.preventDefault();select(item.id);box.setPointerCapture(e.pointerId);const r=stage.getBoundingClientRect();const sx=doc.canvas.width/r.width,sy=doc.canvas.height/r.height;const x0=e.clientX,y0=e.clientY,ox=item.x,oy=item.y,ow=item.width,oh=item.height,resize=e.target===handle;function move(ev){if(resize){item.width=Math.max(.04,Math.min(1.8,ow+(ev.clientX-x0)*sx/doc.canvas.width*2));item.height=Math.max(.04,Math.min(1.8,oh+(ev.clientY-y0)*sy/doc.canvas.height*2));box.style.width=(item.width*100)+'%';box.style.height=(item.height*100)+'%'}else{item.x=Math.max(-.5,Math.min(1.5,ox+(ev.clientX-x0)*sx/doc.canvas.width));item.y=Math.max(-.5,Math.min(1.5,oy+(ev.clientY-y0)*sy/doc.canvas.height));box.style.left=(item.x*100)+'%';box.style.top=(item.y*100)+'%'}}function end(){box.removeEventListener('pointermove',move);box.removeEventListener('pointerup',end);box.removeEventListener('pointercancel',end)}box.addEventListener('pointermove',move);box.addEventListener('pointerup',end);box.addEventListener('pointercancel',end)});stage.appendChild(box);
const tile=document.createElement('button');tile.className='layer';tile.dataset.id=item.id;tile.textContent=(index+1)+'. '+(item.kind==='video'?'▶ ':'▧ ')+item.displayName;tile.onclick=()=>select(item.id);rail.prepend(tile)});renderSelection();if(!doc.items.length){stage.innerHTML='<div style="color:#9AACB0;padding:20px">Projet vide</div>'}}
function moveLayer(d){const i=doc.items.findIndex(x=>x.id===selected);if(i<0)return;const j=Math.max(0,Math.min(doc.items.length-1,i+d));if(i!==j){const a=doc.items.splice(i,1)[0];doc.items.splice(j,0,a);render()}}
function scaleItem(f){const x=byId(selected);if(!x)return;x.width=Math.max(.04,Math.min(1.8,x.width*f));x.height=Math.max(.04,Math.min(1.8,x.height*f));render()}
document.getElementById('up').onclick=()=>moveLayer(1);document.getElementById('down').onclick=()=>moveLayer(-1);document.getElementById('bigger').onclick=()=>scaleItem(1.1);document.getElementById('smaller').onclick=()=>scaleItem(.9);document.getElementById('reset').onclick=()=>{const x=byId(selected);if(x){x.x=.5;x.y=.5;render()}};document.getElementById('playAll').onclick=async()=>{for(const item of doc.items.filter(x=>x.kind==='video')){const v=[...stage.querySelectorAll('.item')].find(e=>e.dataset.id===item.id)?.querySelector('video');if(!v)continue;loadVideo(v,item);try{await v.play();await new Promise(resolve=>{v.onended=resolve;setTimeout(resolve,Math.max(1000,(v.duration||30)*1000+1000))});v.pause()}catch(e){status.textContent='Lecture automatique bloquée : touche la vidéo pour la lancer.'}}};render();
</script></body></html>
""")
                } ?: throw IOException("Impossible d'écrire le fichier HTML.")
                runOnUiThread { status.text = "HTML autonome créé. Médias intégrés ; ouvre directement ce fichier depuis le gestionnaire Android." }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Export HTML échoué : ${e.message}" }
            } finally {
                prepared.forEach { it.delete() }
                runOnUiThread { progress.visibility = View.GONE }
            }
        }
    }

    private fun JSONObjectQuote(value: String): String = org.json.JSONObject.quote(value)

    private fun prepareHtmlImage(source: File, mimeType: String): File {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(source.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IOException("Image illisible : ${source.name}")
        val largest = max(bounds.outWidth, bounds.outHeight)
        if (largest <= 2560) return source
        var sample = 1
        while (largest / (sample * 2) >= 2560) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
        var bitmap = BitmapFactory.decodeFile(source.absolutePath, options) ?: throw IOException("Impossible de réduire : ${source.name}")
        try {
            val maxSide = max(bitmap.width, bitmap.height)
            if (maxSide > 2560) {
                val scale = 2560f / maxSide
                val scaled = Bitmap.createScaledBitmap(bitmap, (bitmap.width * scale).toInt().coerceAtLeast(1), (bitmap.height * scale).toInt().coerceAtLeast(1), true)
                if (scaled !== bitmap) { bitmap.recycle(); bitmap = scaled }
            }
            val output = File(cacheDir, "html_${UUID.randomUUID()}.media")
            FileOutputStream(output).buffered().use { stream ->
                val format = if (mimeType == "image/png") Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
                if (!bitmap.compress(format, 88, stream)) throw IOException("Compression image échouée : ${source.name}")
            }
            return output
        } finally { bitmap.recycle() }
    }

    private fun importedSafeName(uri: Uri) = uri.lastPathSegment?.takeLast(28) ?: "média"
    private fun safeDocName(s: String) = s.replace(Regex("[^A-Za-z0-9_-]"), "_").ifBlank { "MonProjet" }

    private inner class ProjectCanvasView : View(this@MainActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var active: ProjectItem? = null
        private var lastX = 0f; private var lastY = 0f
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.rgb(24, 34, 37))
            paint.color = Color.rgb(15, 21, 23); canvas.drawRoundRect(12f, 12f, width-12f, height-12f, 8f, 8f, paint)
            val sx = width.toFloat() / doc.canvasWidth
            val sy = height.toFloat() / doc.canvasHeight
            doc.items.forEach { item ->
                val cx = item.x * width; val cy = item.y * height
                val w = item.width * width; val h = item.height * height
                val rect = RectF(cx-w/2, cy-h/2, cx+w/2, cy+h/2)
                paint.color = if (item.id == selectedId) Color.rgb(35, 48, 54) else Color.rgb(31, 43, 47)
                canvas.drawRoundRect(rect, 8f, 8f, paint)
                val file = mediaFiles[item.id]
                if (file != null && (item.kind == "image" || item.kind == "video")) {
                    // onDraw never decodes a file itself anymore: it only ever reads
                    // ThumbnailCache, which holds a small, capped-size bitmap generated
                    // once in the background. This is what makes dragging smooth again
                    // and what finally makes huge photos (and videos) safe to preview.
                    val thumb = ThumbnailCache.get(item.id)
                    if (thumb != null) {
                        val src = Rect(0, 0, thumb.width, thumb.height)
                        paint.color = Color.WHITE
                        canvas.drawBitmap(thumb, src, rect, paint)
                    } else {
                        drawLabel(canvas, item, rect)
                        if (!ThumbnailCache.isPending(item.id)) requestThumbnail(item.id, file, item.kind)
                    }
                } else drawLabel(canvas, item, rect)
                paint.style = Paint.Style.STROKE; paint.strokeWidth = if (item.id == selectedId) 4f else 1.5f
                paint.color = if (item.id == selectedId) Color.rgb(227, 168, 87) else Color.rgb(50, 64, 70)
                canvas.drawRoundRect(rect, 8f, 8f, paint); paint.style = Paint.Style.FILL
                if (item.id == selectedId) {
                    paint.color = Color.rgb(227, 168, 87)
                    canvas.drawCircle(rect.right, rect.bottom, 12f, paint)
                    paint.color = Color.rgb(24, 34, 37)
                    canvas.drawCircle(rect.right, rect.bottom, 4f, paint)
                }
            }
            if (doc.items.isEmpty()) {
                paint.color = Color.DKGRAY; paint.textSize = 18f
                canvas.drawText("Espace de composition", 32f, height/2f, paint)
                paint.textSize = 13f; canvas.drawText("Utilise « Importer » pour ajouter des médias", 32f, height/2f+26f, paint)
            }
        }
        private fun requestThumbnail(itemId: String, file: File, kind: String) {
            thread {
                ThumbnailCache.generate(itemId, file, kind)
                post { invalidate() } // back to the UI thread; invalidate() triggers one more onDraw that now finds the thumbnail ready
            }
        }
        private fun drawLabel(canvas: Canvas, item: ProjectItem, rect: RectF) {
            paint.color = Color.DKGRAY; paint.textSize = 15f
            val label = (if (item.kind == "video") "▶ " else if (item.kind == "image") "▧ " else "▤ ") + item.displayName
            val clipped = if (label.length > 22) label.take(19) + "…" else label
            canvas.drawText(clipped, rect.left+8f, rect.centerY(), paint)
        }
        override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    active = doc.items.asReversed().firstOrNull { item ->
                        val cx = item.x * width; val cy = item.y * height
                        event.x in (cx-item.width*width/2)..(cx+item.width*width/2) &&
                            event.y in (cy-item.height*height/2)..(cy+item.height*height/2)
                    }
                    selectedId = active?.id
                    refreshLayerStrip()
                    resizeActive = false
                    active?.let { item ->
                        val right = item.x * width + item.width * width / 2
                        val bottom = item.y * height + item.height * height / 2
                        if (event.x >= right - 26f && event.y >= bottom - 26f) {
                            resizeActive = true
                            resizeStartWidth = item.width
                            resizeStartHeight = item.height
                            resizeStartX = event.x
                            resizeStartY = event.y
                        }
                    }
                    lastX = event.x; lastY = event.y; invalidate(); return true
                }
                MotionEvent.ACTION_MOVE -> {
                    active?.let { item ->
                        if (resizeActive) {
                            item.width = (resizeStartWidth + (event.x - resizeStartX) * 2f / width).coerceIn(0.04f, 1.8f)
                            item.height = (resizeStartHeight + (event.y - resizeStartY) * 2f / height).coerceIn(0.04f, 1.8f)
                        } else {
                            item.x = (item.x + (event.x-lastX)/width).coerceIn(-0.5f, 1.5f)
                            item.y = (item.y + (event.y-lastY)/height).coerceIn(-0.5f, 1.5f)
                            lastX = event.x; lastY = event.y
                        }
                        invalidate()
                    }; return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { active = null; resizeActive = false; return true }
            }
            return true
        }
    }
}
