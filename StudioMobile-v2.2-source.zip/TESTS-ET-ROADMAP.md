# TESTS — Studio Mobile v2.2 — HTML autonome

## 1. Build GitHub Actions

1. Déposer `StudioMobile-v2.2-source.zip` à la racine du dépôt, en remplaçant l’archive précédente.
2. Remplacer `.github/workflows/build-android-v2.2.yml` par le fichier `build-android-v2.2.yml` livré séparément.
3. Lancer manuellement le workflow `Studio Mobile v2.2 - Build canonical source ZIP`.
4. Vérifier que les étapes de validation de l’archive et de compilation passent.
5. Télécharger l’artefact `StudioMobile-v2.2-debug-apk` et installer l’APK sur le Redmi.

## 2. Test HTML minimal

1. Ouvrir Studio Mobile.
2. Importer une photo JPEG de taille modérée et une courte vidéo MP4 H.264/AAC si possible.
3. Appuyer sur « Exporter HTML ».
4. Enregistrer le fichier `.html` dans Téléchargements.
5. Depuis le gestionnaire de fichiers Xiaomi, ouvrir directement ce fichier avec Chrome. Ne pas l’extraire d’une archive : il n’y a plus de ZIP pour cet export.
6. Vérifier l’affichage de la photo, l’ouverture du menu, la sélection des calques, le déplacement/redimensionnement en mode édition et la lecture vidéo après interaction.
7. Refaire le test dans Edge.

## 3. Tests progressifs de charge

Augmenter progressivement la charge, sans commencer par un projet extrême :
- 1 photo + 1 vidéo ;
- 5 photos de tailles variées + 2 vidéos courtes ;
- une photo source de 12 000 × 16 000 px ;
- une vidéo plus lourde ;
- plusieurs vidéos et photos dans un même projet.

Pour chaque essai, noter : taille du HTML, temps de génération, temps d’ouverture, mémoire/échauffement si observable, fluidité, lecture et éventuel plantage.

## 4. Résultats à rapporter

- modèle du téléphone et version Android ;
- navigateur et version ;
- taille du HTML exporté ;
- nombre, dimensions et tailles des médias sources ;
- message affiché par Studio Mobile ;
- comportement à l’ouverture ;
- comportement des photos ;
- comportement des vidéos (démarrage, son, seek, fin) ;
- éventuel crash ou ralentissement.

## 5. Limites connues

Le document HTML unique contient les médias Base64. Le chargement des vidéos est différé jusqu’à interaction, mais les données Base64 restent intégrées au document. Base64 augmente la taille d’environ 33 %. Les limites de mémoire des navigateurs Android doivent donc être mesurées empiriquement. Les vidéos ne sont pas réencodées ; la compatibilité dépend des codecs.
