# Tests et feuille de route Studio Mobile

## Contrôles automatiques visés dans GitHub Actions
- Vérifier l'archive source et sa structure Android.
- Vérifier que le code contient le stockage durable des médias, les vignettes bornées, le mode de visualisation HTML et les messages de dimensions PNG.
- Compiler un APK debug depuis les sources extraites de l'archive, jamais depuis un ancien dossier par défaut.
- Publier un seul artefact nommé `StudioMobile-v2.2-debug-apk` et inclure le SHA-256.

## Ce que ces contrôles ne prouvent pas
Une compilation ne garantit pas la lecture de tous les codecs vidéo sur chaque téléphone, ni la capacité du navigateur à accéder à un chemin de fichier. Ces points exigent un test réel sur Android et au moins un navigateur d'ordinateur.

## Gestion des versions
- Une archive de sources canonique : `StudioMobile-v2.2-source.zip` à la racine du dépôt.
- Un seul workflow actif : `.github/workflows/build-android-v2.2.yml`.
- Un seul artefact à installer : `StudioMobile-v2.2-debug-apk`.
- Chaque itération candidate doit regrouper plusieurs changements et passer les contrôles avant demande de test humain.
