# TESTS — Studio Mobile v2.2 — correctifs du 6 novembre 2026

## 1. Build GitHub Actions

1. Déposer `StudioMobile-v2.2-source.zip` à la racine du dépôt, en remplaçant l'archive précédente.
2. Remplacer `.github/workflows/build-android-v2.2.yml` par le fichier `build-android-v2.2.yml` livré séparément.
3. Lancer manuellement le workflow `Studio Mobile v2.2 - Build canonical source ZIP`.
4. Vérifier les étapes de validation et de compilation.
5. Télécharger l'artefact `StudioMobile-v2.2-debug-apk`, puis installer l'APK sur le Redmi.

## 2. Test prioritaire : HTML autonome

Le workflow vérifie aussi que le modèle Kotlin se termine exactement par `</script></body></html>` sur la même ligne que le délimiteur de chaîne, afin d’éviter le faux échec de fermeture dû à un saut de ligne final.

1. Créer un projet avec 2 photos et 1 courte vidéo MP4.
2. Exporter en HTML vers Téléchargements.
3. Attendre explicitement le message « HTML autonome créé et vérifié » avant de quitter Studio Mobile.
4. Vérifier que la taille du fichier correspond à l'ordre de grandeur attendu (Base64 ajoute environ un tiers au poids des médias intégrés).
5. Ouvrir directement le `.html` depuis le gestionnaire Xiaomi avec Chrome, sans le zipper ni l'extraire.
6. Vérifier que les deux photos et la vidéo apparaissent.
7. Toucher la vidéo : elle doit commencer à charger puis lancer la lecture ; vérifier son, pause et déplacement dans la vidéo.
8. Refaire le test dans Edge.

Si l'export signale une erreur, ne pas tester le fichier incomplet : transmettre le message exact affiché dans Studio Mobile.

## 3. Test orientation EXIF

1. Importer une photo prise verticalement avec le Redmi, sans la modifier dans une autre application.
2. Vérifier son orientation dans le canevas natif.
3. Exporter en HTML et vérifier la même orientation dans Chrome.
4. Refaire avec une photo horizontale.

## 4. Test manipulation tactile

1. Sélectionner une photo dans le canevas.
2. La déplacer en faisant glisser son centre.
3. Faire glisser la poignée orange en bas à droite : largeur et hauteur doivent changer.
4. Faire glisser la poignée verte en haut à droite : la photo doit tourner autour de son centre.
5. Enregistrer en `.studio`, fermer/réouvrir le projet et vérifier que l'angle est conservé.
6. Refaire les manipulations dans le HTML après avoir ouvert le menu d'édition.

## 5. Test vidéo natif

1. Importer une vidéo MP4.
2. Toucher son rectangle dans le canevas : le lecteur doit s'ouvrir.
3. Vérifier lecture, pause, son et déplacement dans la vidéo.
4. Si le lecteur Android refuse le format, transmettre le modèle/codec du fichier si disponible.

## 6. Résultats à rapporter

- résultat du workflow GitHub Actions (succès ou log d'erreur) ;
- taille exacte du HTML exporté ;
- message affiché à la fin de l'export ;
- Chrome ou Edge et version ;
- affichage des photos et lecture vidéo ;
- orientation des photos ;
- déplacement, redimensionnement et rotation au doigt ;
- éventuel ralentissement, fermeture ou message d'erreur.
