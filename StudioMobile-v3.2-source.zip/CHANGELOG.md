# Changelog — Studio Mobile V3.2

## Candidate V3.2.0
- Panneau de calques vertical repliable à droite.
- Groupes de calques indépendants de la fusion ; ajout et dissolution de dossiers.
- Sérialisation des groupes et champs de recadrage dans le manifeste du projet.
- Réglage des dimensions du canevas.
- Recadrage non destructif par limites relatives.
- Paramètres vidéo par élément : poster temporel, ordre de séquence et volume.
- Contrôles Play/Pause distincts dans l'export HTML ; le Play pendant lecture arrête et réinitialise la séquence.
- Posters vidéo intégrés au HTML autonome.
- Double-toucher en mode Vue pour passer en Modifier ; double-toucher en Modifier pour désélectionner et revenir en Vue (à valider sur appareil).
- Fond transparent des éléments HTML pour éviter les aplats gris dans les zones transparentes.
- Chargement des groupes à l'ouverture d'un `.studio`.

## Non inclus
Undo/Redo, autosave avancé, annotations, montage mult piste, collaboration, application iOS et application desktop complète.
