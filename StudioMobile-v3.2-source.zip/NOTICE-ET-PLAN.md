# Studio Mobile V3.2 — notice et plan

## 1. Installation et compilation
1. Conserver le dépôt `NicoMichelas/StudioMobile-v2`.
2. Ajouter `StudioMobile-v3.2-source.zip` à la racine du dépôt, sans le décompresser.
3. Ajouter `build-android-v3.2.yml` dans `.github/workflows/`.
4. Ouvrir Actions, choisir « Studio Mobile V3.2 Android », puis Run workflow.
5. Si le job réussit, télécharger l'artefact `StudioMobile-v3.2-debug-apk` et installer l'APK sur le Redmi.
6. Conserver une copie des projets `.studio` avant les essais.

Le workflow installe Java 17, Android SDK 35 et Gradle 8.11.1. Il vérifie l'existence de l'APK avant de publier l'artefact.

## 2. Modifications intégrées dans cette candidate
- Version Android `3.2.0`, versionCode 9, identifiant de package inchangé.
- Panneau de calques vertical à droite, repliable, avec groupes et sous-calques de fusion déroulables.
- Création/dissolution de groupes sans rasteriser les médias.
- Persistance des groupes et des paramètres de recadrage dans le manifeste `.studio` ; chargement des groupes lors de la réouverture.
- Réglage numérique des dimensions du canevas (64 à 16384 px), avec option de conservation du ratio.
- Recadrage non destructif par pourcentages pour images et vidéos ; les médias d'origine ne sont pas réécrits.
- Paramètres vidéo enregistrés par élément : temps de poster, ordre de lecture et volume.
- Commandes HTML séparées Play/Pause, ordre de séquence, volume et génération d'un poster à partir de l'instant choisi.
- Ajustement du comportement du double-toucher en mode Vue et de la sélection vidéo.
- Correction de l'import des groupes du manifeste lors de l'ouverture d'un projet.
- Fond transparent pour les rectangles des éléments dans le visualiseur HTML, afin de ne pas peindre les espaces transparents d'une fusion en gris.

## 3. Utilisation
### Panneau Calques
Le panneau vertical droit se replie avec le bouton « ‹ ». Appui simple : sélection d'un calque. Appui long : ajout/retrait à la sélection multiple. « Grouper » crée un dossier ; « Dégrouper » dissout le dossier sans fusionner les médias.

Les composites de fusion présentent une ligne déroulante « sources ». Dissocier depuis une source masquée restaure les originaux et retire le composite de la pile.

### Canevas
« Dimensions » ouvre les champs largeur/hauteur. Les coordonnées normalisées des calques sont conservées lors du changement de format.

« Recadrer » ouvre les limites gauche, haut, droite et bas en pourcentage. 0/100 correspond à l'image entière. Réinitialiser restaure le cadre initial. Le fichier média source reste intact.

### Vidéos et HTML
Sélectionner une vidéo puis « Aperçu vidéo » pour choisir le temps (en secondes) de l'image poster. « Ordre vidéo » permet de placer la vidéo dans la séquence. « Volume vidéo » règle son volume. À l'export, les médias visibles et les posters sont intégrés au HTML autonome.

Dans le visualiseur HTML : Play lance ou reprend la séquence ; Pause suspend ; un second Play pendant la lecture arrête et revient au début. Le bouton Pause reste distinct.

## 4. Compatibilité et limites à connaître
- Le schéma `.studio` reste en version 1 ; les nouveaux champs sont facultatifs et les anciens projets conservent leurs valeurs par défaut.
- Le recadrage est stocké non destructivement. Les tests doivent vérifier le rendu natif, la fusion et l'export HTML, en particulier les vidéos recadrées/rotées.
- Le réglage du poster dépend du décodage du fichier vidéo par Android. Certains codecs ou vidéos à durée variable peuvent ne pas fournir d'image à l'instant demandé.
- La fusion est rasterisée, limitée à 2560 px sur le plus grand côté. Les médias originaux restent dans le projet. Les composites intermédiaires sont remplacés par une référence aplatie vers les sources d'origine.
- Les annotations, Undo/Redo, autosave avancé, montage mult piste, collaboration et version desktop complète restent reportés.
- La transformation tactile avancée et les poignées latérales doivent être validées sur appareil ; ne pas considérer leur ergonomie comme validée sans essais.

## 5. Validation
Ne pas considérer V3.2 comme validée sur la seule base de la compilation. Suivre `StudioMobile-v3.2-tests.md`, notamment compatibilité `.studio`, fusion/transparence, lecture vidéo native et export HTML autonome.
