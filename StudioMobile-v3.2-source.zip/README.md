# Studio Mobile V3.2

Projet Android natif Kotlin. Identifiant conservé : `org.studiomobile.v2`.

## Livraison
- Source complète : `StudioMobile-v3.2-source.zip` (à déposer à la racine de `StudioMobile-v2`).
- Workflow séparé : `build-android-v3.2.yml` (à déposer dans `.github/workflows/`).
- Compilation : GitHub Actions > Studio Mobile V3.2 Android > Run workflow.
- Artefact attendu : `StudioMobile-v3.2-debug-apk`.

## Compilation locale
Java 17, Gradle 8.11.1, Android SDK platform 35 et build-tools 35.0.0.

## État
Cette archive est une candidate de développement V3.2. La compilation doit être confirmée par GitHub Actions, puis les tests réels sur Android doivent être effectués. Une compilation réussie ne vaut pas validation fonctionnelle.
