# Construction Android V3.2

Le workflow GitHub Actions utilise Java 17, Android SDK (platform-tools, platforms;android-35 et build-tools;35.0.0) et Gradle 8.11.1.

Important : dans `android-actions/setup-android@v4`, les paquets SDK sont fournis sur des lignes séparées dans le bloc YAML `packages: |`. Ne pas les séparer par des virgules : la virgule serait interprétée comme faisant partie du nom du paquet.

Le workflow attend `StudioMobile-v3.2-source.zip` à la racine du dépôt et produit l’artefact `StudioMobile-v3.2-debug-apk`.
