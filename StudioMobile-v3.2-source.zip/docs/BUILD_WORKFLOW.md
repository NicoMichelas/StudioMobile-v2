# Build GitHub Actions — V3.2

Le workflow `.github/workflows/build-android-v3.2.yml` cherche `StudioMobile-v3.2-source.zip` à la racine, l'extrait dans un dossier temporaire, installe Temurin Java 17, Android SDK Platform 35 / Build Tools 35.0.0 et Gradle 8.11.1, puis lance `:app:assembleDebug`.

Le workflow utilise `android-actions/setup-android@v4` et ne demande pas le paquet SDK historique `tools`.
