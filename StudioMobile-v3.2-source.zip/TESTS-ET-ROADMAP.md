# Studio Mobile V3.2 — plan de tests

Cocher et noter le résultat réel. En cas d'échec, joindre une capture ou le journal GitHub.

## 0. Compilation et installation
- [ ] ZIP source V3.2 ajouté à la racine du dépôt existant.
- [ ] Workflow V3.2 ajouté dans `.github/workflows/`.
- [ ] GitHub Actions termine sans erreur.
- [ ] Artefact `StudioMobile-v3.2-debug-apk` présent et APK non vide.
- [ ] Installation/mise à jour sur Redmi Note 12 Pro 5G Android 13.
- [ ] Copie de sauvegarde d'un ancien `.studio` conservée.

## 1. Compatibilité projet
- [ ] Ouvrir un `.studio` V2.2.
- [ ] Vérifier photos, vidéos, positions, tailles, rotations, ordre et cadrage.
- [ ] Enregistrer sous un nouveau nom, fermer et rouvrir.
- [ ] Vérifier SHA-256 et absence de médias manquants.
- [ ] Ouvrir un `.studio` V3.1 contenant une fusion.
- [ ] Créer un groupe, enregistrer, fermer, rouvrir ; vérifier son nom, ses membres et son état.

## 2. Panneau des calques et groupes
- [ ] Le panneau est vertical à droite et occupe la hauteur de la zone de travail.
- [ ] Replier/déplier le panneau ; le canevas ne doit pas être détruit ni réinitialisé.
- [ ] Appui simple sélectionne un seul calque.
- [ ] Appui long ajoute un deuxième puis un troisième calque à la sélection.
- [ ] Grouper au moins deux calques : ils apparaissent sous un dossier.
- [ ] Dérouler/replier le dossier ; les éléments restent indépendants.
- [ ] Dégrouper : tous les calques réapparaissent indépendamment.
- [ ] Enregistrer/réouvrir : structure conservée.

## 3. Dimensions et recadrage
- [ ] Ouvrir Dimensions ; modifier largeur et hauteur.
- [ ] Vérifier le verrouillage du ratio.
- [ ] Vérifier les limites (64 à 16384 px) et les valeurs invalides.
- [ ] Vérifier que les médias ne sont pas déformés après changement du canevas.
- [ ] Recadrer une photo par les quatre limites ; valider puis enregistrer/réouvrir.
- [ ] Réinitialiser le recadrage.
- [ ] Recadrer une vidéo ; vérifier le cadre pendant la lecture native.
- [ ] Exporter en HTML et vérifier que le même cadrage est respecté.

## 4. Vue et Modifier
- [ ] En Vue, glisser sur le fond déplace la caméra, pas les médias.
- [ ] En Vue, un simple toucher sélectionne-t-il involontairement un média ? Noter.
- [ ] Double-toucher un média entre en Modifier.
- [ ] En Modifier, glisser sur le média déplace le calque.
- [ ] En Modifier, glisser hors média déplace la caméra.
- [ ] Deux doigts sur un média : rotation/redimensionnement attendu ; hors média : caméra.
- [ ] Double-toucher en Modifier désélectionne et revient en Vue.
- [ ] Vérifier poignée de rotation, poignées d'angle et côtés.

## 5. Fusion et transparence
- [ ] Fusionner deux images superposées.
- [ ] Vérifier le composite à la position du calque le plus haut.
- [ ] Dérouler le composite : sources visibles dans le dossier, sans duplication du fichier source.
- [ ] Vérifier que les zones transparentes laissent voir les autres calques.
- [ ] Dissocier : le composite disparaît et les sources réapparaissent.
- [ ] Fusionner un composite avec un troisième calque.
- [ ] Vérifier absence de chaîne de composites intermédiaires inutiles.
- [ ] Fusionner une vidéo : image représentative visible.

## 6. Vidéo native
- [ ] Importer une vidéo paysage et une vidéo portrait ; vérifier orientation du poster.
- [ ] Lire, mettre en pause, reprendre, terminer.
- [ ] Vérifier absence d'écran noir prolongé et poster actualisé.
- [ ] Changer de calque pendant la lecture : lecteur fermé proprement.
- [ ] Vérifier qu'une seule vidéo est active.
- [ ] Vérifier recadrage/rotation pendant la lecture.
- [ ] Tester MP4/H.264, vidéo WhatsApp et vidéo Instagram.

## 7. Export HTML autonome
- [ ] Exporter photos + vidéos visibles.
- [ ] Vérifier poster pour chaque vidéo.
- [ ] Modifier le temps du poster et réexporter.
- [ ] Modifier l'ordre de lecture et vérifier la séquence.
- [ ] Modifier le volume d'une vidéo et vérifier le rendu.
- [ ] Vérifier Play, Pause, reprise, Play pendant lecture (arrêt/remise à zéro).
- [ ] Ouvrir depuis le gestionnaire Android (`content://`).
- [ ] Copier uniquement le HTML sur un autre téléphone et l'ouvrir sans dossier de médias.
- [ ] Vérifier Chrome et Edge Android.
- [ ] Vérifier que les zones transparentes restent transparentes.

## 8. Robustesse
- [ ] Enregistrer/réouvrir après import, déplacement, groupe, fusion et recadrage.
- [ ] Vérifier SHA-256.
- [ ] Vérifier que l'export incomplet n'est pas annoncé comme réussi.
- [ ] Vérifier les erreurs de média absent et codec non pris en charge.

## Critères de validation
Ne pas valider V3.2 tant que les sections 1, 2, 5, 6 et 7 ne sont pas satisfaisantes. Compilation seule = validation technique du build, pas validation fonctionnelle.
