# Studio Mobile 3.0

Application Android native de composition libre de photos et vidéos, avec projets `.studio` et export HTML autonome.

## Livraison GitHub Actions — méthode à conserver

Cette livraison contient deux fichiers distincts :

- `StudioMobile-v3.0-source.zip` : à déposer **à la racine** du dépôt GitHub ;
- `build-android-v3.0.yml` : à déposer dans `.github/workflows/` en remplacement du workflow de build précédent.

Ne pas extraire le ZIP dans le dépôt. Ne pas renommer le ZIP. Ne pas déplacer les autres fichiers du dépôt. Ensuite, ouvrir GitHub Actions, choisir le workflow Studio Mobile 3.0 et lancer `Run workflow`. Télécharger l'artefact `StudioMobile-v3.0-debug-apk`.

Le workflow extrait uniquement le ZIP v3.0 de la racine et refuse de compiler une autre source par défaut.

## Version 3.0

La priorité est la géométrie du canevas et une caméra de vue indépendante : zoom, pan et rotation ne doivent pas modifier la position ou la taille réelle des médias. Le format `.studio` v1 est conservé pour ouvrir les projets v2.2.

Voir `NOTICE-ET-PLAN.md`, `docs/ARCHITECTURE.md`, `docs/CLAUDE_HANDOFF.md`, `TESTS-ET-ROADMAP.md` et `CHANGELOG.md` pour les choix, limites et tests.

## Compilation et validation

La compilation Android doit être exécutée par le workflow GitHub. Cette archive n'est pas présentée comme déjà compilée ni testée sur appareil. Après compilation, installer l'APK et suivre la liste de tests avant de considérer la 3.0 comme validée.
