# Tests et feuille de route — Studio Mobile 3.0

## Tests bloquants avant validation

### A. Ouverture et conservation
- [ ] Ouvrir le projet POC v2.2 fourni.
- [ ] Vérifier que les 5 éléments sont présents et que les médias s'affichent.
- [ ] Comparer le cadrage et les positions avec l'aperçu PNG de référence ; confirmer que les images utilisent le même recadrage centré `cover` dans Android et HTML.
- [ ] Enregistrer sous un nouveau fichier `.studio`.
- [ ] Fermer puis rouvrir ce fichier ; vérifier que les 5 SHA-256 sont validés.
- [ ] Confirmer que le manifeste reste en `schemaVersion: 1`.

### B. Géométrie
- [ ] Afficher un projet 1920×1080 dans l'écran portrait du téléphone : pas de déformation du canevas.
- [ ] Afficher un projet portrait (par exemple 1080×1920) : pas de déformation.
- [ ] Vérifier qu'un élément de largeur 0,24 et hauteur 0,24 garde les proportions correspondant aux dimensions logiques du projet, et non au ratio arbitraire de la vue.
- [ ] Déplacer, redimensionner et tourner un objet.
- [ ] Zoomer, déplacer et tourner la vue ; réinitialiser : aucun objet ne doit avoir changé de coordonnées à cause de la caméra.
- [ ] Répéter les transformations d'objet lorsque la caméra est zoomée et tournée.

### C. Export HTML autonome
- [ ] Exporter le POC en un seul fichier HTML.
- [ ] Ouvrir le fichier depuis le gestionnaire Android (chemin `content://`).
- [ ] Vérifier que les médias restent intégrés et qu'aucun dossier externe n'est requis.
- [ ] Tester zoom +/−, rotation, réinitialisation et geste à deux doigts.
- [ ] Vérifier que toucher lecture/pause dans les contrôles vidéo ne relance pas le chargement de manière intempestive.
- [ ] Ouvrir le même HTML sur ordinateur avec souris et vérifier les commandes de caméra.

### D. Robustesse
- [ ] Importer une photo très haute résolution : aucun décodage de l'original dans `onDraw`.
- [ ] Tester les vidéos et vérifier que l'export HTML les charge à la demande.
- [ ] Ouvrir un ZIP contenant un chemin `../` : il doit être refusé.
- [ ] Altérer un média dans un `.studio` : l'ouverture doit échouer sur SHA-256.

## Résultat de validation connu au moment de la livraison

- [x] Inspection du code source v2.2 et du POC utilisateur.
- [x] Vérification que la source v2.2 fournie est celle associée à l'APK v2.2 selon confirmation de l'utilisateur.
- [x] Modifications 3.0 préparées dans le code source.
- [ ] Compilation réelle GitHub Actions : à effectuer par l'utilisateur.
- [ ] Installation et test physique Android : à effectuer.
- [ ] Test multi-pointeur complet du HTML : à effectuer.

## Feuille de route indicative

### 3.0 — Géométrie et caméra (présente livraison)
Stabiliser le repère du projet, conserver les anciens `.studio`, ajouter caméra de vue native et HTML, préserver l'export HTML autonome.

### 3.1 — Lecture vidéo
Remplacer le dialogue `VideoView` par un lecteur intégré basé sur AndroidX Media3/ExoPlayer ; lecteur unique, commandes play/pause/seek/vitesse/volume, playlist ordonnée indépendamment de l'ordre des calques. Pas de boucles de lecture concurrentes.

### 3.2 — Manipulation et UX
Améliorer sélection, poignées, modes main/sélection, dimensions du canevas, modes d'ajustement média (`contain`, `cover`, `stretch`), accessibilité des commandes et tests de performance.

Cette feuille de route est une proposition technique ; les périmètres 3.1 et 3.2 restent à valider avec l'utilisateur.
