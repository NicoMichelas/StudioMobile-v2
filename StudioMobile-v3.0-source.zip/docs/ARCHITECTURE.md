# Architecture — Studio Mobile 3.0

## État de l'architecture

La base 3.0 conserve temporairement la structure Kotlin v2.2 afin de limiter l'ampleur du changement et de préserver les fonctions déjà présentes. `MainActivity` reste encore trop monolithique ; sa séparation est un chantier ultérieur, pas une refactorisation risquée mêlée à la correction géométrique.

## Modèle du document

- `ProjectDocument` porte le nom, les dimensions logiques du canevas et la liste ordonnée des éléments.
- `ProjectItem` porte l'identité, le chemin média interne, les métadonnées, les coordonnées normalisées, la rotation de l'objet et le SHA-256.
- `ProjectArchive` lit et écrit le ZIP `.studio`, copie les fichiers en flux, rejette les chemins dangereux et vérifie les SHA-256 à l'ouverture.
- `ThumbnailCache` fournit des vignettes plafonnées et mises en cache ; le dessin ne doit pas décoder les originaux massifs dans `onDraw`.

## Repère géométrique

Le manifeste garde `schemaVersion: 1` et les champs normalisés :

- `x`, `y` : centre de l'élément, rapportés respectivement à la largeur et à la hauteur logiques du projet ;
- `width`, `height` : taille de l'élément, rapportée respectivement aux dimensions logiques du projet ;
- `rotation` : rotation de l'élément, en degrés.

Pour afficher le document dans une vue Android :

`baseScale = min(viewWidth / canvasWidth, viewHeight / canvasHeight)`

`projectLeft = (viewWidth - canvasWidth * baseScale) / 2`

`projectTop = (viewHeight - canvasHeight * baseScale) / 2`

Le centre d'un élément est calculé depuis `projectLeft + x * canvasWidth * baseScale` et `projectTop + y * canvasHeight * baseScale`. Sa largeur et sa hauteur sont calculées avec les dimensions logiques correspondantes. Un facteur uniforme conserve le ratio du canevas.

## Caméra de vue

La caméra est un état d'affichage temporaire : `zoom`, `panX`, `panY`, `viewRotation`. Elle est appliquée autour du centre de la vue et n'est jamais sérialisée dans `manifest.json`. Les manipulations d'objet sont effectuées après inversion de la matrice de caméra, afin de modifier les coordonnées du document et non l'écran.

L'HTML autonome utilise une transformation CSS sur `#stage`, avec ses propres commandes de caméra. Le canevas garde ses dimensions logiques et ses positions normalisées.

## Architecture cible, à atteindre progressivement

- `ProjectDocument` : modèle et migrations de format.
- `ProjectArchive` / `AssetStore` : import, stockage ZIP, intégrité et streaming.
- `CanvasRenderer` : rendu du document, indépendant des contrôles.
- `ViewportController` : zoom, pan, rotation et conversion écran/projet.
- `PlaybackController` : lecteur unique, file de lecture et état audio (prévu 3.1).
- `ExportEngine` : PNG et HTML autonome, avec paramètres d'export distincts des originaux.

Ne pas déplacer les classes dans une nouvelle architecture avant d'avoir des tests de non-régression du format `.studio` et des exports.
