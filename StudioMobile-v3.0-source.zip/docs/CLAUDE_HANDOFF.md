# Handoff Claude — Studio Mobile 3.0

## Contexte et règles de dépôt

Le dépôt GitHub existant doit rester organisé comme aujourd'hui. L'utilisateur travaille depuis Android, sans ordinateur, et remplace manuellement deux éléments :

1. `StudioMobile-v3.0-source.zip` à la racine du dépôt ;
2. `build-android-v3.0.yml` dans `.github/workflows/`.

Il lance ensuite manuellement GitHub Actions et télécharge l'artefact APK. Ne pas proposer de renommer le dépôt, de déplacer le ZIP source, de supprimer d'anciens fichiers ou de changer ce circuit sans demande explicite.

La séquence de versions reste 3.0, 3.1, 3.2… jusqu'à décision explicite de passer à 4.0. Chaque livraison doit fournir le ZIP source et le workflow YAML avec les noms exacts correspondants.

## Base technique

Le code vient de la source v2.2 qui correspond à l'APK v2.2 fourni par l'utilisateur. Package Android `org.studiomobile.v2` volontairement conservé pour éviter une migration d'identité applicative inutile. `versionName` est maintenant `3.0.0`, `versionCode` 7.

## Travail effectué en 3.0

- Correction du rendu natif : l'échelle est uniforme et tient compte des dimensions logiques du document.
- Les tailles d'objets sont calculées avec `canvasWidth` et `canvasHeight`, pas avec les dimensions arbitraires de la vue.
- Ajout d'une caméra native temporaire : zoom, pan, rotation. Deux doigts manipulent la vue ; les poignées d'objet continuent de manipuler le média.
- Ajout des commandes de caméra dans l'interface Android.
- Ajout des commandes de caméra et d'un début de gestion tactile à deux doigts dans l'export HTML.
- Conservation du manifeste `.studio` v1 et de l'export HTML autonome.
- Alignement du rendu des images natif sur le HTML : recadrage centré `cover` dans les vignettes Android.
- Le chargement vidéo HTML est déclenché par `play` puis reprend la lecture après chargement, sans intercepter `pointerdown`.

## Points à auditer impérativement

1. Compiler via le workflow fourni. Corriger toute erreur de compilation avant d'annoncer la 3.0 comme compilable.
2. Installer l'APK sur le Redmi Note 12 Pro Android 13.
3. Ouvrir le POC v2.2, vérifier positions, tailles, rotation et médias ; sauvegarder en `.studio`, fermer, rouvrir, puis comparer.
4. Tester un canevas 1920×1080 sur écran portrait : aucun étirement non voulu ; le canevas garde son ratio.
5. Tester zoom avant/arrière, pan, rotation de la vue ; vérifier que les coordonnées des objets ne changent pas après réinitialisation de la vue.
6. Tester déplacement, redimensionnement et rotation d'objet après zoom/rotation de la vue.
7. Tester l'export HTML en `content://` depuis le gestionnaire de fichiers Android, sans médias externes ; tester menu, commandes de caméra et lecteur vidéo.
8. Vérifier les gestes tactiles à deux doigts et la souris sur navigateur desktop. L'interaction HTML est un premier niveau de caméra, elle mérite un audit multi-pointeur approfondi.

## Ne pas glisser dans cette livraison

Ne pas introduire Media3/ExoPlayer ni réécrire le système de stockage dans ce patch de géométrie. La vidéo native intégrée, la playlist indépendante des calques et le contrôleur de lecture central sont prévus pour 3.1, après stabilisation de la 3.0.

## Décisions ouvertes

- Choisir explicitement les modes d'affichage média `contain`, `cover`, `stretch` et la valeur par défaut. En 3.0, Android et HTML utilisent `cover` pour cohérence ; le choix reste non configurable.
- Décider ensuite de la stratégie de lecture : lecteur intégré au canevas, lecteur unique, playlist ordonnée indépendamment des calques, volume/muet et vitesse.
- Étudier une extraction de `MainActivity` en composants seulement avec tests de non-régression.
