# Workflow de compilation GitHub Actions

Le workflow livré séparément est `build-android-v3.0.yml`. Il doit être placé dans `.github/workflows/` du dépôt existant. Le ZIP source `StudioMobile-v3.0-source.zip` doit rester à la racine du dépôt.

Le workflow vérifie l'existence et l'intégrité ZIP, extrait uniquement cette archive, contrôle des marqueurs v3.0 puis compile `:app:assembleDebug` avec Java 17 et Gradle 8.11.1. Il publie `StudioMobile-v3.0-debug.apk` dans l'artefact `StudioMobile-v3.0-debug-apk`.

Il n'utilise pas de sources Kotlin éventuellement présentes à la racine du dépôt et ne fait aucun fallback vers une ancienne version.
