# Studio Mobile 3.0 — notice de version et choix techniques

## Objectif de cette version

La 3.0 corrige d'abord le repère géométrique du canevas et introduit une caméra de vue indépendante du document. Elle ne cherche pas à ajouter toutes les fonctions futures : la priorité est de rendre la composition stable sur téléphone et cohérente avec l'export HTML autonome.

## Ce qui change

1. **Repère de projet unique.** Les positions et tailles restent stockées sous forme normalisée dans le manifeste v1, mais elles sont interprétées relativement aux dimensions logiques du projet (`canvas.width` et `canvas.height`). Elles ne sont plus multipliées directement par la largeur et la hauteur indépendantes de la vue Android.
2. **Mise à l'échelle uniforme.** Le canevas est ajusté avec un facteur commun (`min(viewWidth/canvasWidth, viewHeight/canvasHeight)`). Son rapport largeur/hauteur est conservé. Un projet 1920 × 1080 reste donc visuellement 16:9, même sur un écran portrait.
3. **Caméra indépendante.** Zoom, déplacement et rotation de la vue ne changent ni `x`, ni `y`, ni `width`, ni `height`, ni la rotation des objets. Android propose des boutons de vue et les gestes à deux doigts. L'export HTML possède les mêmes commandes et les gestes tactiles à deux doigts.
4. **Compatibilité de projet.** Le schéma `.studio` reste en version 1. Les valeurs existantes sont conservées, sans conversion destructive ni réécriture des médias. Les projets v2.2 restent donc ouvrables par cette version.
5. **Export HTML autonome conservé.** Les médias restent intégrés au HTML. Les images continuent d'être plafonnées lors de la préparation HTML et les vidéos sont chargées à la demande. Les fichiers originaux du projet `.studio` ne sont pas remplacés par les versions d'export.
6. **Contrôles vidéo HTML moins intrusifs.** Le chargement initial d'une vidéo est déclenché par son événement `play`, puis la lecture reprend après chargement ; le `pointerdown` n'intercepte plus les contrôles natifs.

## Pourquoi ne pas convertir tout le manifeste en pixels ?

Le format v2.2 stocke déjà des coordonnées normalisées. Les convertir maintenant en pixels obligerait à introduire une migration de schéma et augmenterait le risque de modifier l'apparence des anciens projets. La correction peut être obtenue en appliquant correctement les dimensions logiques du document à l'affichage, tout en gardant le manifeste v1 intact. Une migration vers un repère plus riche pourra être étudiée lorsque les fonctions temporelles/spatiales le justifieront.

## Ce qui n'est volontairement pas inclus

- Pas encore de lecteur vidéo natif intégré au canevas : le lecteur Android v2.2 en dialogue reste provisoirement en place.
- Pas encore de playlist indépendante de l'ordre des calques, de contrôleur vidéo central, ni de lecture séquentielle fiabilisée.
- Pas encore de changement interactif des dimensions du canevas.
- Pas encore de modes `contain / cover / stretch` configurables : le rendu des vignettes conserve son comportement actuel. Le recadrage observé dans le POC doit faire l'objet d'un choix UX explicite, plutôt que d'une modification silencieuse qui changerait l'apparence des projets.
- Pas de réencodage des vidéos ni de compression destructive des originaux.

## Limites de validation de cette livraison

Le code a été modifié et les archives / scripts de workflow sont préparés. L'environnement de préparation ne dispose pas d'un SDK Android/Gradle complet permettant de garantir ici une compilation APK. La compilation réelle doit être effectuée par le workflow GitHub fourni. Le test sur le Redmi Android reste à faire après installation de l'artefact. Aucune réussite de compilation ou de test sur appareil n'est revendiquée à l'avance.
