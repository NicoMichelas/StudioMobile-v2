# Changelog

## 3.0.0 — 2026-11-06

- Correction du repère de rendu Android : échelle uniforme basée sur les dimensions du projet.
- Dimensions d'objets calculées à partir de la largeur/hauteur logiques du document.
- Ajout d'une caméra de vue native (zoom, déplacement, rotation, réinitialisation), indépendante des transformations des objets.
- Ajout des commandes de caméra dans le HTML autonome et d'une première prise en charge des gestes tactiles à deux doigts.
- Conservation du format `.studio` `schemaVersion: 1` et du stockage média intégré.
- Chargement vidéo HTML déclenché par `play` puis reprise de lecture après chargement, sans intercepter `pointerdown`.
- Version Android : `versionName 3.0.0`, `versionCode 7` ; namespace et applicationId conservés.

## 2.2
- Base de départ fournie par l'utilisateur et associée à l'APK v2.2.
